/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        clinical: {
          purple: {
            DEFAULT: '#581C87',
            deep: '#340075',
            dark: '#4C1D95',
            royal: '#7C3AED',
            vibrant: '#712AE2',
            light: '#8B5CF6',
            soft: '#EDE9FE',
            surface: '#FAF8FF',
            canvas: '#F4F3FA'
          },
          optical: {
            bg: '#0B1120',
            dark: '#070B14',
            surface: '#131D33',
            border: '#1E293B',
            glow: '#38BDF8'
          },
          green: {
            DEFAULT: '#059669',
            light: '#10B981',
            soft: '#ECFDF5',
            border: '#A7F3D0'
          },
          amber: {
            DEFAULT: '#D97706',
            light: '#F59E0B',
            soft: '#FFFBEB',
            border: '#FDE68A'
          },
          red: {
            DEFAULT: '#DC2626',
            light: '#EF4444',
            soft: '#FEF2F2',
            border: '#FECACA'
          },
          blue: {
            DEFAULT: '#2563EB',
            light: '#3B82F6',
            soft: '#EFF6FF',
            border: '#BFDBFE'
          },
          charcoal: {
            DEFAULT: '#0F172A',
            dark: '#1E1B2E',
            muted: '#475569',
            light: '#64748B'
          },
          border: {
            soft: '#E2E8F0',
            purple: '#DDD6FE',
            subtle: '#F1F5F9'
          }
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Menlo', 'monospace']
      },
      boxShadow: {
        'clinical-sm': '0 1px 2px 0 rgba(15, 23, 42, 0.04)',
        'clinical': '0 1px 3px 0 rgba(76, 29, 149, 0.08), 0 1px 2px -1px rgba(76, 29, 149, 0.04)',
        'clinical-lg': '0 10px 15px -3px rgba(76, 29, 149, 0.08), 0 4px 6px -4px rgba(76, 29, 149, 0.04)',
        'optical-glow': '0 0 25px -5px rgba(124, 58, 237, 0.3)'
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'spin-slow': 'spin 12s linear infinite',
        'ping-slow': 'ping 2.5s cubic-bezier(0, 0, 0.2, 1) infinite',
      }
    },
  },
  plugins: [],
}

