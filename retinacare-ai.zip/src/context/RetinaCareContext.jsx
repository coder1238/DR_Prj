import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { sureshVerma, mockPatientList } from '../data/mockPatients';
import { initialReviewQueue, queueStats } from '../data/mockReviewQueue';
import { initialReferrals, referralStats, referralLifecycleStages } from '../data/mockReferrals';
import { phcCenters, districtMetrics, defaultSimulinkParams } from '../data/mockPHCNetwork';
import { aiClusterModels } from '../data/mockModels';

export const pageRoutes = {
  1: '/login',
  2: '/command-centre',
  3: '/registration',
  4: '/capture-studio',
  5: '/quality-lab',
  6: '/ai-analysis',
  7: '/anatomy-map',
  8: '/severity-studio',
  9: '/explainability-lab',
  10: '/review-queue',
  11: '/review-workstation',
  12: '/referral-command',
  13: '/longitudinal-record',
  14: '/district-simulink',
  15: '/model-registry'
};

export const pathToPageId = {
  '/': 2,
  '/login': 1,
  '/command-centre': 2,
  '/dashboard': 2,
  '/registration': 3,
  '/patient-registration': 3,
  '/capture-studio': 4,
  '/capture': 4,
  '/quality-lab': 5,
  '/ai-analysis': 6,
  '/ai-engine': 6,
  '/anatomy-map': 7,
  '/severity-studio': 8,
  '/explainability-lab': 9,
  '/explainability': 9,
  '/review-queue': 10,
  '/review-workstation': 11,
  '/workstation': 11,
  '/referral-command': 12,
  '/referrals': 12,
  '/longitudinal-record': 13,
  '/longitudinal': 13,
  '/district-simulink': 14,
  '/simulink': 14,
  '/model-registry': 15,
  '/models': 15
};

const RetinaCareContext = createContext();

export function RetinaCareProvider({ children }) {
  const navigate = useNavigate();
  const location = useLocation();

  // Navigation: 1 to 15
  const [activePage, setActivePage] = useState(() => pathToPageId[location.pathname] || 2);
  
  // Sync activePage whenever URL changes via browser back/forward or direct link
  useEffect(() => {
    const matchedId = pathToPageId[location.pathname];
    if (matchedId && matchedId !== activePage) {
      setActivePage(matchedId);
    }
  }, [location.pathname]);

  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [currentUser, setCurrentUser] = useState({
    name: 'Dr. Ananya Sharma',
    role: 'Ophthalmologist (Tele-Review Lead)',
    initials: 'AS',
    email: 'ananya.sharma@myh-indore.gov.in',
    facility: 'M.Y. Hospital Central Hub (Indore)',
    mciRegNo: 'MP-MC-2015-88412'
  });

  // Active Patient & Patient Directory
  const [currentPatient, setCurrentPatient] = useState(sureshVerma);
  const [patients, setPatients] = useState(mockPatientList);

  // Review Queue & Referrals
  const [reviewQueue, setReviewQueue] = useState(initialReviewQueue);
  const [selectedCase, setSelectedCase] = useState(initialReviewQueue[0]);
  const [referrals, setReferrals] = useState(initialReferrals);
  const [selectedReferral, setSelectedReferral] = useState(initialReferrals[0]);
  
  // Modals & UI Controls
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [printModalOpen, setPrintModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  // System status
  const [offlineMode, setOfflineMode] = useState(false);
  const [bandwidthMode, setBandwidthMode] = useState('optimal'); // 'optimal', 'throttled', 'offline'
  const [syncQueue, setSyncQueue] = useState([]);
  const [simulinkParams, setSimulinkParams] = useState(defaultSimulinkParams);

  // Keyboard shortcut listener for Ctrl+K / Cmd+K
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Trigger temporary toast notification
  const showToast = (title, message, type = 'info') => {
    setToastMessage({ title, message, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const navigateTo = (target) => {
    if (typeof target === 'number') {
      const targetPath = pageRoutes[target] || '/command-centre';
      setActivePage(target);
      navigate(targetPath);
    } else if (typeof target === 'string') {
      const matched = pathToPageId[target];
      if (matched) setActivePage(matched);
      navigate(target);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleOffline = () => {
    const nextState = !offlineMode;
    setOfflineMode(nextState);
    if (nextState) {
      setBandwidthMode('offline');
      showToast('Offline Mode Activated', 'Changes will be queued in local IndexedDB store and synced once 4G link resumes.', 'warning');
    } else {
      setBandwidthMode('optimal');
      showToast('Network Restored', `Synchronized ${syncQueue.length} queued records to National Health Mission cloud.`, 'success');
      setSyncQueue([]);
    }
  };

  // Action to submit doctor sign-off on Page 11
  const submitDoctorReview = (caseId, validationData) => {
    setReviewQueue((prev) =>
      prev.map((c) =>
        c.id === caseId
          ? {
              ...c,
              status: 'Reviewed & Signed Off',
              doctorNotes: validationData.notes,
              doctorDiagnosis: validationData.confirmedDiagnosis,
              reviewedAt: 'Just now by Dr. Ananya Sharma'
            }
          : c
      )
    );

    if (validationData.referralGenerated) {
      const newRef = {
        id: `REF-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        patientId: currentPatient.id,
        patientName: currentPatient.name,
        abhaId: currentPatient.abhaId,
        phone: currentPatient.phone,
        age: currentPatient.age,
        gender: currentPatient.gender,
        originPhc: currentPatient.registrationPhc,
        destinationHub: validationData.destinationFacility || 'M.Y. Hospital, Indore (Retina Specialty OPD 4)',
        referralUrgency: validationData.urgency || 'Urgent (Within 72 Hours)',
        urgencyLevel: 'urgent',
        drStage: validationData.confirmedDiagnosis,
        icdrGrade: validationData.grade,
        referringOfficer: currentUser.name,
        receivingConsultant: 'Prof. S. N. Agrawal, MS',
        scheduledDate: 'Tomorrow, 10:30 AM',
        createdDate: '19 Sep 2026, Just Now',
        status: 'slot_booked',
        stageIndex: 3,
        distanceKm: 46.2,
        transportVoucher: 'Govt 108 Emergency Ambulance / ASHA Escort Issued',
        patientToken: `ABDM-FAST-${Math.floor(1000 + Math.random() * 9000)}`,
        notifications: {
          smsSent: true,
          smsDeliveredAt: 'Just now',
          whatsappDelivered: true,
          ashaAlerted: true,
          ashaName: currentPatient.ashaWorker
        },
        clinicalIndication: validationData.notes || 'Referred for specialist vitreo-retinal consultation & OCT',
        notes: 'Priority OPD Pass Generated by Tele-Ophthalmology Workstation'
      };
      setReferrals((prev) => [newRef, ...prev]);
      setSelectedReferral(newRef);
      showToast('Validation & Referral Submitted', `Case ${caseId} confirmed. Priority Referral Token ${newRef.patientToken} dispatched via ABDM SMS.`, 'success');
    } else {
      showToast('Review Signed Off', `Case ${caseId} validated. Patient scheduled for routine 12-month community recall.`, 'success');
    }
  };

  const registerNewPatient = (patientData) => {
    const newPt = {
      ...sureshVerma,
      ...patientData,
      id: `RC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      status: 'Registered - Ready for Imaging'
    };
    setPatients((prev) => [newPt, ...prev]);
    setCurrentPatient(newPt);
    showToast('Patient Registered', `ABHA ${newPt.abhaId} verified. Patient profile enqueued for fundus capture.`, 'success');
    navigateTo(4); // Advance to Capture Studio
  };

  const advanceReferralStage = (referralId) => {
    setReferrals((prev) =>
      prev.map((r) => {
        if (r.id !== referralId) return r;
        const nextStageIdx = Math.min(r.stageIndex + 1, 5);
        const stageStatusMap = [
          'initiated',
          'triaged',
          'specialist_assigned',
          'slot_booked',
          'patient_admitted',
          'completed'
        ];
        const nextStatus = stageStatusMap[nextStageIdx];
        showToast(
          'Referral Stage Advanced',
          `Patient ${r.patientName} (${r.patientToken}) advanced to: Stage ${nextStageIdx + 1} (${nextStatus.replace('_', ' ')})`,
          'success'
        );
        return {
          ...r,
          stageIndex: nextStageIdx,
          status: nextStatus
        };
      })
    );
  };

  const createManualReferral = (newReferralData) => {
    const refId = `REF-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const fullRef = {
      id: refId,
      patientId: newReferralData.patientId || currentPatient.id,
      patientName: newReferralData.patientName || currentPatient.name,
      abhaId: newReferralData.abhaId || currentPatient.abhaId,
      phone: newReferralData.phone || currentPatient.phone,
      age: newReferralData.age || currentPatient.age,
      gender: newReferralData.gender || currentPatient.gender,
      originPhc: newReferralData.originPhc || currentPatient.registrationPhc,
      destinationHub: newReferralData.destinationHub || 'M.Y. Hospital, Indore (Retina Specialty OPD 4)',
      referralUrgency: newReferralData.referralUrgency || 'Urgent (Within 72 Hours)',
      urgencyLevel: newReferralData.urgencyLevel || 'urgent',
      drStage: newReferralData.drStage || currentPatient.confirmedDiagnosis,
      icdrGrade: newReferralData.icdrGrade || 2,
      referringOfficer: currentUser.name,
      receivingConsultant: newReferralData.receivingConsultant || 'Prof. S. N. Agrawal, MS',
      scheduledDate: newReferralData.scheduledDate || 'Tomorrow, 10:30 AM',
      createdDate: '19 Sep 2026, Just Now',
      status: 'initiated',
      stageIndex: 0,
      distanceKm: newReferralData.distanceKm || 38.5,
      transportVoucher: newReferralData.transportVoucher || 'Govt 108 Emergency Ambulance / ASHA Escort Issued',
      patientToken: `ABDM-EXP-${Math.floor(1000 + Math.random() * 9000)}`,
      notifications: {
        smsSent: true,
        smsDeliveredAt: 'Just now',
        whatsappDelivered: true,
        ashaAlerted: true,
        ashaName: newReferralData.ashaName || currentPatient.ashaWorker
      },
      clinicalIndication: newReferralData.clinicalIndication || 'Referred for specialist vitreo-retinal evaluation',
      notes: newReferralData.notes || 'Created via Referral Command Centre'
    };

    setReferrals((prev) => [fullRef, ...prev]);
    setSelectedReferral(fullRef);
    showToast(
      'New Tele-Referral Created',
      `Referral Token ${fullRef.patientToken} successfully issued for ${fullRef.patientName}.`,
      'success'
    );
  };

  return (
    <RetinaCareContext.Provider
      value={{
        activePage,
        setActivePage,
        navigateTo,
        isAuthenticated,
        setIsAuthenticated,
        currentUser,
        setCurrentUser,
        currentPatient,
        setCurrentPatient,
        patients,
        setPatients,
        registerNewPatient,
        reviewQueue,
        setReviewQueue,
        selectedCase,
        setSelectedCase,
        referrals,
        setReferrals,
        selectedReferral,
        setSelectedReferral,
        advanceReferralStage,
        createManualReferral,
        submitDoctorReview,
        commandPaletteOpen,
        setCommandPaletteOpen,
        printModalOpen,
        setPrintModalOpen,
        toastMessage,
        showToast,
        offlineMode,
        toggleOffline,
        bandwidthMode,
        setBandwidthMode,
        syncQueue,
        simulinkParams,
        setSimulinkParams,
        phcCenters,
        districtMetrics,
        aiClusterModels,
        queueStats,
        referralStats,
        referralLifecycleStages,
        pageRoutes,
        pathToPageId
      }}
    >
      {children}
    </RetinaCareContext.Provider>
  );
}

export function useRetinaCare() {
  const context = useContext(RetinaCareContext);
  if (!context) {
    throw new Error('useRetinaCare must be used within a RetinaCareProvider');
  }
  return context;
}

