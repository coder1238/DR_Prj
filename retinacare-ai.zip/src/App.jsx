import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { RetinaCareProvider, useRetinaCare } from './context/RetinaCareContext';
import NavigationRail from './components/shell/NavigationRail';
import GlobalTopBar from './components/shell/GlobalTopBar';
import CommandPaletteModal from './components/shell/CommandPaletteModal';
import PrintableReferralModal from './components/common/PrintableReferralModal';

// 15 Interactive Pages
import ClinicalLogin from './components/pages/01_ClinicalLogin';
import CommandCentre from './components/pages/02_CommandCentre';
import PatientRegistration from './components/pages/03_PatientRegistration';
import CaptureStudio from './components/pages/04_CaptureStudio';
import ImageQualityLab from './components/pages/05_ImageQualityLab';
import AIAnalysisCentre from './components/pages/06_AIAnalysisCentre';
import RetinalAnatomyMap from './components/pages/07_RetinalAnatomyMap';
import DRSeverityStudio from './components/pages/08_DRSeverityStudio';
import ExplainabilityLab from './components/pages/09_ExplainabilityLab';
import ReviewQueue from './components/pages/10_ReviewQueue';
import ReviewWorkstation from './components/pages/11_ReviewWorkstation';
import ReferralCentre from './components/pages/12_ReferralCentre';
import LongitudinalRecord from './components/pages/13_LongitudinalRecord';
import DistrictSimulink from './components/pages/14_DistrictSimulink';
import AIModelCentre from './components/pages/15_AIModelCentre';

import { CheckCircle2, AlertTriangle, Info } from 'lucide-react';

function AppContent() {
  const { toastMessage } = useRetinaCare();
  const location = useLocation();

  // Screen 01 Login page renders standalone
  if (location.pathname === '/login') {
    return (
      <div className="min-h-screen bg-slate-50 font-sans">
        <ClinicalLogin />
        <CommandPaletteModal />
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 font-sans">
      {/* 260px / Collapsible Navigation Rail */}
      <NavigationRail />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Global Top Bar */}
        <GlobalTopBar />

        {/* Scrollable Page Router Viewport */}
        <main className="flex-1 overflow-y-auto bg-slate-100 pb-16">
          <Routes>
            {/* Primary 15 Clean URL Endpoints */}
            <Route path="/" element={<Navigate to="/command-centre" replace />} />
            <Route path="/command-centre" element={<CommandCentre />} />
            <Route path="/registration" element={<PatientRegistration />} />
            <Route path="/capture-studio" element={<CaptureStudio />} />
            <Route path="/quality-lab" element={<ImageQualityLab />} />
            <Route path="/ai-analysis" element={<AIAnalysisCentre />} />
            <Route path="/anatomy-map" element={<RetinalAnatomyMap />} />
            <Route path="/severity-studio" element={<DRSeverityStudio />} />
            <Route path="/explainability-lab" element={<ExplainabilityLab />} />
            <Route path="/review-queue" element={<ReviewQueue />} />
            <Route path="/review-workstation" element={<ReviewWorkstation />} />
            <Route path="/referral-command" element={<ReferralCentre />} />
            <Route path="/longitudinal-record" element={<LongitudinalRecord />} />
            <Route path="/district-simulink" element={<DistrictSimulink />} />
            <Route path="/model-registry" element={<AIModelCentre />} />

            {/* Intuitive URL Aliases */}
            <Route path="/dashboard" element={<Navigate to="/command-centre" replace />} />
            <Route path="/patient-registration" element={<Navigate to="/registration" replace />} />
            <Route path="/capture" element={<Navigate to="/capture-studio" replace />} />
            <Route path="/quality" element={<Navigate to="/quality-lab" replace />} />
            <Route path="/ai-engine" element={<Navigate to="/ai-analysis" replace />} />
            <Route path="/lesion-map" element={<Navigate to="/anatomy-map" replace />} />
            <Route path="/severity" element={<Navigate to="/severity-studio" replace />} />
            <Route path="/explainability" element={<Navigate to="/explainability-lab" replace />} />
            <Route path="/queue" element={<Navigate to="/review-queue" replace />} />
            <Route path="/workstation" element={<Navigate to="/review-workstation" replace />} />
            <Route path="/referrals" element={<Navigate to="/referral-command" replace />} />
            <Route path="/longitudinal" element={<Navigate to="/longitudinal-record" replace />} />
            <Route path="/simulink" element={<Navigate to="/district-simulink" replace />} />
            <Route path="/models" element={<Navigate to="/model-registry" replace />} />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/command-centre" replace />} />
          </Routes>
        </main>
      </div>

      {/* Modals */}
      <CommandPaletteModal />
      <PrintableReferralModal />

      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900/95 text-white p-4 rounded-2xl shadow-2xl border border-purple-500/50 flex items-start gap-3 max-w-sm animate-in slide-in-from-bottom-5 duration-200">
          {toastMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
          ) : toastMessage.type === 'warning' ? (
            <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
          ) : (
            <Info className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
          )}
          <div className="space-y-0.5 text-xs">
            <div className="font-bold text-white">{toastMessage.title}</div>
            <div className="text-slate-300 leading-snug">{toastMessage.message}</div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <RetinaCareProvider>
      <AppContent />
    </RetinaCareProvider>
  );
}
