export const mockPatients = [
  {
    id: "RC-2026-9104",
    abhaId: "91-4829-1034-8291",
    name: "Suresh Chandra Verma",
    age: 56,
    gender: "Male",
    phone: "+91 98260 44192",
    village: "Rau Kalan",
    phc: "PHC Rau",
    district: "Indore, MP",
    worker: "Sunita Yadav (ANM-04)",
    diabetesProfile: {
      type: "Type 2 DM",
      durationYears: 9,
      hba1c: 8.8,
      hba1cStatus: "Suboptimal Control (>8.0%)",
      fastingGlucose: 164,
      postPrandialGlucose: 218,
      bp: "138/88 mmHg",
      treatments: ["Metformin 1000mg", "Glimepiride 2mg", "Diet & Exercise"],
      comorbidities: ["Hypertension (Controlled)", "No Nephropathy"]
    },
    ophthalmicHistory: {
      acuityOD: "6/9",
      acuityOS: "6/12",
      symptoms: ["Gradual Blurring", "Mild Floaters"],
      previousDR: "Diagnosed Mild NPDR (Jan 2025)",
      previousProcedures: ["Cataract IOL OS (March 2024)"],
      lastDilatedExam: "18 months ago (M.Y. Hospital)"
    },
    screeningOD: {
      eye: "OD",
      capturedAt: "19 Sep 2026, 12:15 PM IST",
      gradability: 91,
      qualityPass: true,
      currentGrade: 2,
      drStageLabel: "Level 2: Moderate NPDR",
      referableStatus: "REFERABLE",
      urgency: "Routine Specialist Consult (<30 Days)",
      aiConfidence: 91.8,
      ensembleAgreement: "93.3% (14/15 Models)",
      biomarkers: {
        microaneurysms: 8,
        hemorrhages: 2,
        hardExudates: 3,
        softExudates: 0,
        neovascularization: false,
        vesselDensity: 14.8,
        vesselTortuosity: 1.28,
        avRatio: 0.64,
        foveaDistanceLesion: "820 µm",
        centerInvolvingDME: false
      },
      probabilities: {
        level0: 1.2,
        level1: 5.4,
        level2: 87.6,
        level3: 4.8,
        level4: 1.0
      },
      evidenceItems: [
        {
          id: 1,
          title: "Microaneurysm Cluster",
          type: "Vascular Lesion (MA)",
          location: "Temporal macular subfield (820µm from fovea)",
          area: "0.08 mm²",
          count: 8,
          confidence: 96.4,
          model: "IDRiD Lesion Model v3",
          clinicalNote: "Exceeds mild threshold (>5 discrete MAs). Primary hallmark of Moderate NPDR."
        },
        {
          id: 2,
          title: "Flame Hemorrhages",
          type: "Intraretinal Hemorrhage",
          location: "Superotemporal vascular arcade (+1.8mm superior)",
          area: "0.24 mm²",
          count: 2,
          confidence: 94.8,
          model: "FundusExpert-Seg (nnU-Net)",
          clinicalNote: "Capillary breakdown localized to 1 quadrant (<20 hemorrhages, rules out 4-2-1 Severe NPDR)."
        },
        {
          id: 3,
          title: "Vascular Morphology Abnormality",
          type: "Microvascular Biomarker",
          location: "Arteriolar temporal branches",
          area: "Arcade caliber",
          count: 1,
          confidence: 96.0,
          model: "AutoMorph v2",
          clinicalNote: "Elevated tortuosity (1.28) and mild arteriolar narrowing (A/V 0.64) denote chronic vascular stress."
        },
        {
          id: 4,
          title: "Regional Saliency Peak",
          type: "Attention Attribution",
          location: "Macular-Disc Interspace",
          area: "Focus area",
          count: 1,
          confidence: 97.2,
          model: "RETFound-MAE (ViT-Large)",
          clinicalNote: "Layer Integrated Gradients confirm attention on vascular lesions and not image artifacts."
        }
      ]
    },
    screeningOS: {
      eye: "OS",
      capturedAt: "19 Sep 2026, 12:18 PM IST",
      gradability: 94,
      qualityPass: true,
      currentGrade: 1,
      drStageLabel: "Level 1: Mild NPDR",
      referableStatus: "NON-REFERABLE",
      urgency: "Annual Re-screening (12 Months)",
      aiConfidence: 94.5,
      biomarkers: {
        microaneurysms: 3,
        hemorrhages: 0,
        hardExudates: 0,
        softExudates: 0,
        neovascularization: false,
        vesselDensity: 15.2,
        vesselTortuosity: 1.15,
        avRatio: 0.66,
        centerInvolvingDME: false
      }
    },
    longitudinalHistory: [
      {
        date: "14 Jan 2025",
        facility: "PHC Depalpur",
        doctor: "Dr. R.K. Joshi",
        grade: 1,
        gradeLabel: "Level 1: Mild NPDR",
        microaneurysms: 4,
        hemorrhages: 0,
        exudates: 0,
        tortuosity: 1.12,
        avRatio: 0.67,
        lesionArea: 0.04,
        status: "Non-referable • 12-month follow-up"
      },
      {
        date: "08 Jun 2026",
        facility: "PHC Rau",
        doctor: "Dr. A. Sharma",
        grade: 2,
        gradeLabel: "Level 2: Moderate NPDR (Early)",
        microaneurysms: 6,
        hemorrhages: 1,
        exudates: 1,
        tortuosity: 1.20,
        avRatio: 0.66,
        lesionArea: 0.18,
        status: "Borderline • Re-screen 3 months"
      },
      {
        date: "19 Sep 2026",
        facility: "PHC Rau",
        doctor: "Dr. Ananya Sharma",
        grade: 2,
        gradeLabel: "Level 2: Moderate NPDR (Confirmed)",
        microaneurysms: 8,
        hemorrhages: 2,
        exudates: 3,
        tortuosity: 1.28,
        avRatio: 0.64,
        lesionArea: 0.42,
        status: "REFERABLE • Appointment Booked 28 Sep 2026"
      }
    ]
  }
];

export const sureshVerma = {
  ...mockPatients[0],
  registrationPhc: 'Depalpur Community Health Centre',
  ashaWorker: 'Kamla Devi (+91 94250 88219)',
  confirmedDiagnosis: 'Moderate NPDR (Grade 2)',
  longitudinalVisits: [
    { visitId: 'VIS-2024-1', date: '12 Mar 2024', grade: 'No DR (Grade 0)', hba1c: 7.1, maCount: 0, fazUm: 480, status: 'Normal' },
    { visitId: 'VIS-2024-2', date: '18 Oct 2024', grade: 'Mild NPDR (Grade 1)', hba1c: 7.8, maCount: 6, fazUm: 490, status: 'Initial Lesions' },
    { visitId: 'VIS-2025-1', date: '05 May 2025', grade: 'Mild NPDR (Grade 1)', hba1c: 8.6, maCount: 19, fazUm: 505, status: 'Progression' },
    { visitId: 'VIS-2026-1', date: '19 Sep 2026', grade: 'Moderate NPDR (Grade 2)', hba1c: 9.4, maCount: 38, fazUm: 520, status: 'Referable DME' }
  ]
};

export const mockPatientList = mockPatients.map(p => ({
  ...p,
  registrationPhc: p.phc || 'PHC Depalpur',
  ashaWorker: p.worker || 'Kamla Devi',
  confirmedDiagnosis: 'Moderate NPDR (Grade 2)'
}));

