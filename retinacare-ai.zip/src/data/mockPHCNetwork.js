export const phcCenters = [
  {
    id: 'PHC-01',
    name: 'Depalpur Community Health Centre',
    shortCode: 'DPLP',
    type: 'CHC / Block Hub',
    block: 'Depalpur',
    distanceToHubKm: 46.2,
    cameras: [
      { id: 'CAM-D1', model: 'Remidio NM-FOP II (Handheld)', serial: 'RM-2024-8841', status: 'Online', battery: 94, calibrationDate: '01 Sep 2026', snrAvg: '24.2 dB' },
      { id: 'CAM-D2', model: 'Forus 3nethra classic', serial: 'FR-2023-1102', status: 'Online', battery: 100, calibrationDate: '15 Aug 2026', snrAvg: '26.8 dB' }
    ],
    nursesTrained: 6,
    activeOperators: 2,
    dailyScreened: 34,
    dailyTarget: 40,
    referableToday: 5,
    networkLatencyMs: 42,
    connectivity: '4G LTE (Airtel Healthcare APN)',
    bandwidthKbps: 4200,
    syncStatus: 'Fully Synced (0 Pending)',
    coordinates: { lat: 22.852, lng: 75.548 }
  },
  {
    id: 'PHC-02',
    name: 'Dr. Ambedkar Nagar (Mhow) Civil Hospital',
    shortCode: 'MHOW',
    type: 'Sub-District Hospital',
    block: 'Mhow',
    distanceToHubKm: 28.5,
    cameras: [
      { id: 'CAM-M1', model: 'Remidio NM-FOP II (Handheld)', serial: 'RM-2024-9021', status: 'Online', battery: 88, calibrationDate: '28 Aug 2026', snrAvg: '23.9 dB' },
      { id: 'CAM-M2', model: 'Bosch Fundus Vision Plus', serial: 'BS-2025-0419', status: 'Online', battery: 100, calibrationDate: '05 Sep 2026', snrAvg: '27.4 dB' }
    ],
    nursesTrained: 8,
    activeOperators: 3,
    dailyScreened: 48,
    dailyTarget: 50,
    referableToday: 7,
    networkLatencyMs: 38,
    connectivity: 'Fiber Broadband + 5G Backup',
    bandwidthKbps: 8400,
    syncStatus: 'Fully Synced (0 Pending)',
    coordinates: { lat: 22.553, lng: 75.761 }
  },
  {
    id: 'PHC-03',
    name: 'Sanwer Primary Health Centre',
    shortCode: 'SNWR',
    type: 'Primary Health Centre',
    block: 'Sanwer',
    distanceToHubKm: 34.5,
    cameras: [
      { id: 'CAM-S1', model: 'Forus 3nethra classic', serial: 'FR-2024-3381', status: 'Online', battery: 78, calibrationDate: '10 Sep 2026', snrAvg: '25.1 dB' }
    ],
    nursesTrained: 4,
    activeOperators: 1,
    dailyScreened: 26,
    dailyTarget: 30,
    referableToday: 4,
    networkLatencyMs: 78,
    connectivity: '4G LTE (Jio Rural)',
    bandwidthKbps: 2100,
    syncStatus: 'Syncing (2 Enqueued)',
    coordinates: { lat: 22.973, lng: 75.829 }
  },
  {
    id: 'PHC-04',
    name: 'Rau Primary Health Centre',
    shortCode: 'RAU',
    type: 'Primary Health Centre',
    block: 'Indore Rural',
    distanceToHubKm: 18.0,
    cameras: [
      { id: 'CAM-R1', model: 'Bosch Fundus Vision Plus', serial: 'BS-2024-1188', status: 'Online', battery: 100, calibrationDate: '01 Aug 2026', snrAvg: '28.1 dB' }
    ],
    nursesTrained: 5,
    activeOperators: 2,
    dailyScreened: 38,
    dailyTarget: 35,
    referableToday: 3,
    networkLatencyMs: 24,
    connectivity: 'Fiber Optical (BSNL BharatNet)',
    bandwidthKbps: 12000,
    syncStatus: 'Fully Synced (0 Pending)',
    coordinates: { lat: 22.631, lng: 75.807 }
  },
  {
    id: 'PHC-05',
    name: 'Betma Primary Health Centre',
    shortCode: 'BTMA',
    type: 'Primary Health Centre',
    block: 'Depalpur Sub-centre',
    distanceToHubKm: 31.8,
    cameras: [
      { id: 'CAM-B1', model: 'Remidio NM-FOP II (Handheld)', serial: 'RM-2025-0104', status: 'Online', battery: 64, calibrationDate: '12 Sep 2026', snrAvg: '22.4 dB' }
    ],
    nursesTrained: 3,
    activeOperators: 1,
    dailyScreened: 19,
    dailyTarget: 25,
    referableToday: 2,
    networkLatencyMs: 95,
    connectivity: '3G/4G Fallback',
    bandwidthKbps: 850,
    syncStatus: 'Syncing (4 Enqueued - Low Bandwidth)',
    coordinates: { lat: 22.684, lng: 75.612 }
  }
];

export const districtMetrics = {
  totalScreened: 12842,
  referableCount: 1042,
  referableRatePercent: 8.1,
  gradabilityRatePercent: 96.8,
  activeCamerasDeployed: 18,
  ophthalmologistReviewHoursAvg: 1.8,
  highRiskImmediateTriageCount: 142,
  districtName: 'Indore District, Madhya Pradesh',
  stateName: 'Madhya Pradesh (NHM Region 4)',
  chiefMedicalOfficer: 'Dr. B. S. Saitya, CMO Indore',
  programDirector: 'Dr. Ananya Sharma, Tele-Ophthalmology Lead'
};

export const defaultSimulinkParams = {
  dailyScreeningVolume: 165,
  aiTriageCutoff: 0.70,
  teleReviewBatchSize: 40,
  specialistWeeklySlots: 350,
  transportSubsidyInr: 250,
  mobileVanDeployments: 3,
  ashaFollowupIncentiveInr: 150,
  repeatScreeningIntervalMonths: 12,
  highRiskFastTrackThreshold: 0.85,
  optOutRatePercent: 4.5
};

