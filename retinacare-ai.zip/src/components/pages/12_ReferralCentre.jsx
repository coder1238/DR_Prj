import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import { referralLifecycleStages as defaultLifecycleStages } from '../../data/mockReferrals';
import {
  Send,
  Printer,
  Phone,
  MessageSquare,
  MapPin,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Search,
  Filter,
  ArrowRight,
  ShieldCheck,
  PlusCircle,
  X,
  Building2,
  Calendar,
  UserCheck,
  Activity,
  Check,
  ChevronRight
} from 'lucide-react';

export default function ReferralCentre() {
  const {
    referrals,
    referralStats,
    referralLifecycleStages,
    setSelectedReferral,
    setPrintModalOpen,
    advanceReferralStage,
    createManualReferral,
    showToast
  } = useRetinaCare();

  const stages = referralLifecycleStages || defaultLifecycleStages;

  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [createModalOpen, setCreateModalOpen] = useState(false);

  // New referral form state
  const [newRefForm, setNewRefForm] = useState({
    patientName: 'Kailash Narayan Rathore',
    abhaId: '91-5509-1284-3329',
    phone: '+91 98261 55920',
    age: 51,
    gender: 'Male',
    originPhc: 'PHC Rau',
    destinationHub: 'M.Y. Hospital, Indore (Retina Specialty OPD 4)',
    referralUrgency: 'Urgent (Within 72 Hours)',
    urgencyLevel: 'urgent',
    drStage: 'Moderate NPDR with Macular Threat',
    icdrGrade: 2,
    clinicalIndication: 'Perifoveal microaneurysms with increasing retinal thickness in temporal macula.',
    transportVoucher: 'Govt 108 Emergency Ambulance / ASHA Escort Issued',
    ashaName: 'Leela Patel (+91 98934 11209)'
  });

  const filteredReferrals = referrals.filter((r) => {
    let matchesFilter = true;
    if (activeFilter === 'urgent') {
      matchesFilter = r.urgencyLevel === 'urgent' || r.urgencyLevel === 'emergency';
    } else if (activeFilter === 'slot_booked') {
      matchesFilter = r.status === 'slot_booked';
    } else if (activeFilter === 'admitted') {
      matchesFilter = r.status === 'patient_admitted';
    } else if (activeFilter === 'completed') {
      matchesFilter = r.status === 'completed';
    }

    const patientName = r.patientName || '';
    const patientToken = r.patientToken || '';
    const originPhc = r.originPhc || '';
    const abhaId = r.abhaId || '';

    const matchesSearch =
      patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      patientToken.toLowerCase().includes(searchQuery.toLowerCase()) ||
      originPhc.toLowerCase().includes(searchQuery.toLowerCase()) ||
      abhaId.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const handlePrint = (ref) => {
    setSelectedReferral(ref);
    setPrintModalOpen(true);
  };

  const handleSendNotification = (ref, type) => {
    const ashaName = ref.notifications?.ashaName ? ref.notifications.ashaName.split(' ')[0] : 'Assigned Worker';
    showToast(
      `${type} Dispatch Confirmed`,
      `Sent fast-track OPD token ${ref.patientToken} to ${ref.patientName} (${ref.phone}) and ASHA ${ashaName}.`,
      'success'
    );
  };

  const handleCallAsha = (ref) => {
    const ashaName = ref.notifications?.ashaName || 'ASHA Community Lead';
    showToast(
      'Connecting to ASHA Facilitator',
      `Direct tele-consult line initiated to ${ashaName} for patient ${ref.patientName}.`,
      'info'
    );
  };

  const handleCreateSubmit = (e) => {
    e.preventDefault();
    createManualReferral(newRefForm);
    setCreateModalOpen(false);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 12 • Care Coordination
            </span>
            <span className="text-xs text-slate-500 font-medium">Ayushman Bharat Digital Mission (ABDM) Transit</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Referral Command & Care Coordination</h1>
          <p className="text-xs text-slate-600">
            End-to-end patient journey tracking from rural PHC capture to tertiary retinal specialty care.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setCreateModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-purple-900/20"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Tele-Referral</span>
          </button>
          <button
            onClick={() => handlePrint(referrals[0] || null)}
            className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
          >
            <Printer className="w-4 h-4 text-purple-700" />
            <span>Print Current Pass</span>
          </button>
        </div>
      </div>

      {/* 5-KPI Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Active Referrals</div>
          <div className="text-2xl font-black text-purple-900 mt-1">{referralStats.activeReferrals}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Across 5 PHC Blocks</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Urgent &lt;72h</div>
          <div className="text-2xl font-black text-rose-600 mt-1">{referralStats.urgentReferrals}</div>
          <div className="text-[10px] text-rose-600 font-semibold mt-0.5">High CSME Risk</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Booked at M.Y. Hub</div>
          <div className="text-2xl font-black text-indigo-600 mt-1">{referralStats.pendingSpecialistSlot}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Specialist Slots Reserved</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Completed Consults</div>
          <div className="text-2xl font-black text-emerald-600 mt-1">{referralStats.completedConsultations}</div>
          <div className="text-[10px] text-emerald-600 font-semibold mt-0.5">88.4% Adherence</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Overdue Follow-ups</div>
          <div className="text-2xl font-black text-amber-600 mt-1">{referralStats.overdueFollowups}</div>
          <div className="text-[10px] text-amber-600 font-semibold mt-0.5">ASHA Home Visit Alerted</div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex-1 max-w-md relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search referral token, patient, ABHA, or clinic..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl focus:outline-none focus:border-purple-600"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {[
            { id: 'all', label: 'All Referrals' },
            { id: 'urgent', label: 'Urgent <72h' },
            { id: 'slot_booked', label: 'Slot Booked' },
            { id: 'admitted', label: 'Admitted at Hub' },
            { id: 'completed', label: 'Completed' }
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`px-3 py-1.5 rounded-xl font-bold transition ${
                activeFilter === f.id
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Referral Cards List */}
      <div className="space-y-4">
        {filteredReferrals.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center space-y-2">
            <div className="text-sm font-bold text-slate-700">No matching referrals found</div>
            <p className="text-xs text-slate-500">
              Try adjusting your search criteria or switch filter tab to "All Referrals".
            </p>
          </div>
        ) : (
          filteredReferrals.map((r) => {
            const isCompleted = r.status === 'completed';
            const ashaName = r.notifications?.ashaName || 'Assigned ASHA';
            return (
              <div
                key={r.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 hover:border-purple-300 shadow-xs space-y-4 transition"
              >
                {/* Top row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-bold text-slate-900 text-sm">{r.patientName}</span>
                    <span className="font-mono text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                      {r.patientId}
                    </span>
                    <span className="font-mono text-[11px] text-purple-700 bg-purple-50 px-2 py-0.5 rounded font-bold">
                      {r.patientToken}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        r.urgencyLevel === 'urgent'
                          ? 'bg-rose-100 text-rose-800'
                          : r.urgencyLevel === 'emergency'
                          ? 'bg-red-200 text-red-900'
                          : r.urgencyLevel === 'completed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-indigo-100 text-indigo-800'
                      }`}
                    >
                      {r.referralUrgency}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    {/* Advance Lifecycle Button */}
                    {!isCompleted && (
                      <button
                        onClick={() => advanceReferralStage(r.id)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold flex items-center gap-1 shadow-xs transition"
                        title="Move to Next Healthcare Stage"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Advance Stage</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleSendNotification(r, 'SMS / WhatsApp')}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 flex items-center gap-1 transition"
                      title="Dispatch SMS / WhatsApp Reminder"
                    >
                      <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-[11px] font-semibold">SMS Alert</span>
                    </button>

                    <button
                      onClick={() => handleCallAsha(r)}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-700 flex items-center gap-1 transition"
                      title="Direct Tele-link to ASHA Worker"
                    >
                      <Phone className="w-3.5 h-3.5 text-purple-600" />
                      <span className="text-[11px] font-semibold">Call ASHA</span>
                    </button>

                    <button
                      onClick={() => handlePrint(r)}
                      className="px-3 py-1.5 rounded-lg bg-purple-50 hover:bg-purple-100 text-purple-800 font-bold border border-purple-200 flex items-center gap-1 transition"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>ABDM Slip</span>
                    </button>
                  </div>
                </div>

                {/* 6-Stage Lifecycle Stepper */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    <span>Transit Lifecycle Status (Click Stage to Advance)</span>
                    <span className="text-purple-700">Stage {r.stageIndex + 1} of 6</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-[11px]">
                    {stages.map((stg, sIdx) => {
                      const isDone = sIdx < r.stageIndex;
                      const isCurrent = sIdx === r.stageIndex;
                      return (
                        <div
                          key={stg.id}
                          className={`p-2 rounded-xl border text-center transition ${
                            isCurrent
                              ? 'bg-purple-100 border-purple-400 text-purple-950 font-bold shadow-xs'
                              : isDone
                              ? 'bg-emerald-50 border-emerald-200 text-emerald-900 font-semibold'
                              : 'bg-slate-50 border-slate-200 text-slate-400'
                          }`}
                        >
                          <div className="text-[10px] flex items-center justify-center gap-1">
                            {isDone && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
                            <span>{stg.label}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Clinical & Transit Details */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs bg-slate-50/70 p-3.5 rounded-xl border border-slate-200/80">
                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Origin & Destination</div>
                    <div className="font-bold text-slate-900 mt-0.5">{r.originPhc}</div>
                    <div className="text-slate-600 text-[11px]">→ {r.destinationHub}</div>
                    <div className="text-slate-400 text-[10px] font-mono mt-0.5">Distance: {r.distanceKm} km</div>
                  </div>

                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Confirmed DR Indication</div>
                    <div className="font-bold text-purple-950 mt-0.5">{r.drStage}</div>
                    <div className="text-[11px] text-slate-600 line-clamp-2 mt-0.5">{r.clinicalIndication}</div>
                  </div>

                  <div>
                    <div className="text-[10px] text-slate-500 uppercase font-semibold">Transport & ASHA Support</div>
                    <div className="font-bold text-emerald-800 mt-0.5">{r.transportVoucher}</div>
                    <div className="text-[11px] text-slate-600 mt-0.5">ASHA: {ashaName}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Appointment: {r.scheduledDate}</div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal: Create New Tele-Referral */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Send className="w-5 h-5 text-purple-400" />
                <span className="font-bold text-sm">Issue Fast-Track Tele-Referral (ABDM)</span>
              </div>
              <button
                onClick={() => setCreateModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="p-6 space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Patient Name</label>
                  <input
                    type="text"
                    value={newRefForm.patientName}
                    onChange={(e) => setNewRefForm({ ...newRefForm, patientName: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">14-Digit ABHA ID</label>
                  <input
                    type="text"
                    value={newRefForm.abhaId}
                    onChange={(e) => setNewRefForm({ ...newRefForm, abhaId: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Origin PHC Clinic</label>
                  <select
                    value={newRefForm.originPhc}
                    onChange={(e) => setNewRefForm({ ...newRefForm, originPhc: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    <option>Depalpur Community Health Centre</option>
                    <option>Dr. Ambedkar Nagar (Mhow) Civil Hospital</option>
                    <option>Sanwer Primary Health Centre</option>
                    <option>PHC Rau</option>
                    <option>Betma Primary Health Centre</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Referral Urgency</label>
                  <select
                    value={newRefForm.referralUrgency}
                    onChange={(e) => {
                      const val = e.target.value;
                      const level = val.includes('Emergency') ? 'emergency' : val.includes('Urgent') ? 'urgent' : 'routine';
                      setNewRefForm({ ...newRefForm, referralUrgency: val, urgencyLevel: level });
                    }}
                    className="w-full p-2 border border-slate-300 rounded-lg text-rose-700 font-bold"
                  >
                    <option>Urgent (Within 72 Hours)</option>
                    <option>Emergency (Within 24 Hours)</option>
                    <option>Priority (Within 7 Days)</option>
                    <option>Elective (Within 14 Days)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Destination Specialty Centre</label>
                <select
                  value={newRefForm.destinationHub}
                  onChange={(e) => setNewRefForm({ ...newRefForm, destinationHub: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                >
                  <option>M.Y. Hospital, Indore (Retina Specialty OPD 4)</option>
                  <option>Indore District Eye Hospital (Civil Dispensary)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">Clinical Indication & Findings</label>
                <textarea
                  rows="2"
                  value={newRefForm.clinicalIndication}
                  onChange={(e) => setNewRefForm({ ...newRefForm, clinicalIndication: e.target.value })}
                  className="w-full p-2 border border-slate-300 rounded-lg"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Assigned ASHA Facilitator</label>
                  <input
                    type="text"
                    value={newRefForm.ashaName}
                    onChange={(e) => setNewRefForm({ ...newRefForm, ashaName: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Transport Assistance Voucher</label>
                  <select
                    value={newRefForm.transportVoucher}
                    onChange={(e) => setNewRefForm({ ...newRefForm, transportVoucher: e.target.value })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    <option>Govt 108 Emergency Ambulance / ASHA Escort Issued</option>
                    <option>State Transport Bus Pass Issued</option>
                    <option>Janani Express Transit Voucher</option>
                  </select>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-200 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold flex items-center gap-1.5 shadow-md shadow-purple-900/30"
                >
                  <Check className="w-4 h-4" />
                  <span>Issue Fast-Track Referral</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
