import React, { useState, useEffect } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import ReadinessRing from '../common/ReadinessRing';
import {
  Camera,
  Eye,
  Sliders,
  Maximize2,
  RefreshCw,
  Sparkles,
  Zap,
  Info,
  CheckCircle2,
  ArrowRight,
  Focus
} from 'lucide-react';

export default function CaptureStudio() {
  const { currentPatient, navigateTo, showToast } = useRetinaCare();

  const [selectedEye, setSelectedEye] = useState('OD'); // OD: Right, OS: Left
  const [cameraModel, setCameraModel] = useState('Remidio NM-FOP II (Handheld)');
  const [distanceMm, setDistanceMm] = useState(18);
  const [pupilMm, setPupilMm] = useState(4.2);
  const [illumination, setIllumination] = useState(94);
  const [isCapturing, setIsCapturing] = useState(false);
  const [flashEffect, setFlashEffect] = useState(false);

  // Compute live readiness
  const isDistanceGood = Math.abs(distanceMm - 18) <= 2;
  const isPupilGood = pupilMm >= 3.8;
  const isIllumGood = illumination >= 85;

  let computedReadiness = 65;
  if (isDistanceGood) computedReadiness += 12;
  if (isPupilGood) computedReadiness += 13;
  if (isIllumGood) computedReadiness += 7;

  const handleTriggerCapture = () => {
    setIsCapturing(true);
    setFlashEffect(true);
    setTimeout(() => {
      setFlashEffect(false);
    }, 250);

    setTimeout(() => {
      setIsCapturing(false);
      showToast('Capture Acquired', 'High-resolution RAW frame buffered. Passing to Image Quality Lab.', 'success');
      navigateTo(5); // Proceed to Quality Lab
    }, 1200);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Station 04 • Live Optical Acquisition
            </span>
            <span className="text-xs text-slate-500 font-medium">Auto-QC & Edge Alignment Active</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Retinal Capture Studio</h1>
          <p className="text-xs text-slate-600">
            Patient: <span className="font-bold text-purple-950">{currentPatient.name}</span> ({currentPatient.id} • ABHA: {currentPatient.abhaId})
          </p>
        </div>

        {/* Eye Toggle & Camera Selector */}
        <div className="flex items-center gap-3">
          <div className="flex p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold">
            <button
              onClick={() => setSelectedEye('OD')}
              className={`px-3 py-1.5 rounded-lg transition ${
                selectedEye === 'OD'
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              OD (Right Eye)
            </button>
            <button
              onClick={() => setSelectedEye('OS')}
              className={`px-3 py-1.5 rounded-lg transition ${
                selectedEye === 'OS'
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              OS (Left Eye)
            </button>
          </div>

          <select
            value={cameraModel}
            onChange={(e) => setCameraModel(e.target.value)}
            className="p-2 border border-slate-300 rounded-xl text-xs font-semibold text-slate-800 bg-white"
          >
            <option>Remidio NM-FOP II (Handheld)</option>
            <option>Forus 3nethra classic</option>
            <option>Bosch Fundus Vision Plus</option>
          </select>
        </div>
      </div>

      {/* Main Studio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 8 Cols: Dark Optical Acquisition Viewport */}
        <div className="lg:col-span-8 bg-slate-950 rounded-3xl p-6 border border-slate-800 shadow-2xl relative flex flex-col items-center justify-center min-h-[520px] overflow-hidden">
          {/* Flash animation */}
          {flashEffect && (
            <div className="absolute inset-0 bg-white z-50 animate-out fade-out duration-300 pointer-events-none" />
          )}

          {/* Optical Target Frame */}
          <div className="relative w-[380px] h-[380px] sm:w-[440px] sm:h-[440px] rounded-full border-2 border-purple-500/40 shadow-2xl flex items-center justify-center overflow-hidden bg-radial from-amber-950/30 via-slate-950 to-black">
            {/* Live optical scanline */}
            <div className="absolute inset-x-0 h-1 bg-purple-400/40 shadow-purple-500 shadow-[0_0_12px] animate-scanline pointer-events-none" />

            {/* Target Retinal Silhouette preview */}
            <div className="w-full h-full opacity-60 mix-blend-screen flex items-center justify-center">
              <svg viewBox="0 0 400 400" className="w-full h-full">
                <circle cx="200" cy="200" r="190" fill="#3B1104" opacity="0.8" />
                {/* Optic Disc */}
                <circle cx="130" cy="200" r="32" fill="#FBBF24" opacity="0.8" />
                {/* Macula Center */}
                <circle cx="260" cy="200" r="16" fill="#1C0501" stroke="#C084FC" strokeWidth="1" strokeDasharray="3 3" />
                {/* Branching vessels */}
                <path d="M 130 190 Q 180 120 280 90" fill="none" stroke="#991B1B" strokeWidth="3" />
                <path d="M 130 210 Q 180 280 280 310" fill="none" stroke="#991B1B" strokeWidth="3" />
              </svg>
            </div>

            {/* Alignment Reticle HUD */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-64 h-64 rounded-full border border-purple-400/30 border-dashed" />
              <div className="absolute w-32 h-32 rounded-full border border-purple-300/50" />
              <div className="absolute w-4 h-4 border-t-2 border-l-2 border-purple-400 -translate-x-12 -translate-y-12" />
              <div className="absolute w-4 h-4 border-t-2 border-r-2 border-purple-400 translate-x-12 -translate-y-12" />
              <div className="absolute w-4 h-4 border-b-2 border-l-2 border-purple-400 -translate-x-12 translate-y-12" />
              <div className="absolute w-4 h-4 border-b-2 border-r-2 border-purple-400 translate-x-12 translate-y-12" />
            </div>

            {/* Live Indicator overlay */}
            <div className="absolute top-4 inset-x-0 flex justify-between px-6 text-[10px] font-mono text-purple-300">
              <span className="flex items-center gap-1.5 bg-slate-900/80 px-2 py-0.5 rounded-full border border-purple-800">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                LIVE 60 FPS • {selectedEye}
              </span>
              <span className="bg-slate-900/80 px-2 py-0.5 rounded-full border border-purple-800">
                FOV: 45° Non-Mydriatic
              </span>
            </div>

            <div className="absolute bottom-4 inset-x-0 flex justify-center text-[10px] font-mono text-slate-300">
              <span className="bg-slate-900/90 px-3 py-1 rounded-full border border-slate-700">
                Fixation Target: Center Amber LED
              </span>
            </div>
          </div>

          {/* Bottom Telemetry Bar */}
          <div className="mt-4 flex items-center justify-between w-full max-w-lg text-[11px] font-mono text-slate-400 bg-slate-900/80 px-4 py-2 rounded-xl border border-slate-800">
            <span>Camera: {cameraModel.split(' ')[0]}</span>
            <span>Dist: {distanceMm} mm</span>
            <span>Pupil: {pupilMm} mm</span>
            <span className="text-emerald-400 font-bold">Auto-Focus: LOCKED</span>
          </div>
        </div>

        {/* Right 4 Cols: Hardware Simulator Controls & ReadinessRing */}
        <div className="lg:col-span-4 space-y-4">
          {/* Readiness Ring Component */}
          <ReadinessRing
            readiness={computedReadiness}
            isReady={computedReadiness >= 85}
            distanceMm={distanceMm}
            pupilMm={pupilMm}
            illuminationPercent={illumination}
            onTriggerCapture={handleTriggerCapture}
          />

          {/* Interactive Optical Calibration Sliders */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-1.5 font-bold text-slate-900">
                <Sliders className="w-4 h-4 text-purple-700" />
                <span>Simulate Optical Alignment</span>
              </div>
              <button
                onClick={() => {
                  setDistanceMm(18);
                  setPupilMm(4.2);
                  setIllumination(94);
                }}
                className="text-[11px] text-purple-700 hover:underline font-semibold"
              >
                Auto-Align
              </button>
            </div>

            {/* Distance Slider */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>Working Distance</span>
                <span className="font-mono text-purple-900">{distanceMm} mm (Target: 18mm)</span>
              </div>
              <input
                type="range"
                min="10"
                max="26"
                value={distanceMm}
                onChange={(e) => setDistanceMm(Number(e.target.value))}
                className="w-full accent-purple-700"
              />
              <div className="flex justify-between text-[10px] text-slate-600">
                <span>10mm (Too Close)</span>
                <span>26mm (Too Far)</span>
              </div>
            </div>

            {/* Pupil Diameter Slider */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>Pupil Aperture</span>
                <span className="font-mono text-purple-900">{pupilMm} mm (Min: 3.8mm)</span>
              </div>
              <input
                type="range"
                min="2.5"
                max="6.0"
                step="0.1"
                value={pupilMm}
                onChange={(e) => setPupilMm(Number(e.target.value))}
                className="w-full accent-purple-700"
              />
              <div className="flex justify-between text-[10px] text-slate-600">
                <span>2.5mm (Constricted)</span>
                <span>6.0mm (Dilated)</span>
              </div>
            </div>

            {/* Illumination Gain */}
            <div className="space-y-1">
              <div className="flex justify-between font-semibold text-slate-700">
                <span>LED Illumination Gain</span>
                <span className="font-mono text-purple-900">{illumination}%</span>
              </div>
              <input
                type="range"
                min="60"
                max="100"
                value={illumination}
                onChange={(e) => setIllumination(Number(e.target.value))}
                className="w-full accent-purple-700"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

