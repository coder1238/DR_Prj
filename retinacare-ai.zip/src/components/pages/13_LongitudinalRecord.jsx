import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  History,
  Calendar,
  Activity,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Eye,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export default function LongitudinalRecord() {
  const { currentPatient, navigateTo } = useRetinaCare();

  const visits = currentPatient.longitudinalVisits || [
    { visitId: 'VIS-2024-1', date: '12 Mar 2024', grade: 'No DR (Grade 0)', hba1c: 7.1, maCount: 0, fazUm: 480, status: 'Normal' },
    { visitId: 'VIS-2024-2', date: '18 Oct 2024', grade: 'Mild NPDR (Grade 1)', hba1c: 7.8, maCount: 6, fazUm: 490, status: 'Initial Lesions' },
    { visitId: 'VIS-2025-1', date: '05 May 2025', grade: 'Mild NPDR (Grade 1)', hba1c: 8.6, maCount: 19, fazUm: 505, status: 'Progression' },
    { visitId: 'VIS-2026-1', date: '19 Sep 2026', grade: 'Moderate NPDR (Grade 2)', hba1c: 9.4, maCount: 38, fazUm: 520, status: 'Referable DME' }
  ];

  const [selectedVisitId, setSelectedVisitId] = useState('VIS-2026-1');

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 13 • Longitudinal Trajectory
            </span>
            <span className="text-xs text-slate-500 font-medium">3-Year Microvascular Disease Monitoring</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Longitudinal Patient Record & Trajectory</h1>
          <p className="text-xs text-slate-600">
            Patient: <span className="font-bold text-slate-900">{currentPatient.name}</span> ({currentPatient.id} • ABHA: {currentPatient.abhaId})
          </p>
        </div>

        <button
          onClick={() => navigateTo(11)}
          className="px-4 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-purple-900/20"
        >
          <span>Open Workstation</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Synchronized Dual-Image Comparator */}
      <div className="bg-slate-950 rounded-3xl p-6 border border-slate-800 shadow-xl space-y-4 text-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-purple-400" />
            <h2 className="text-base font-bold text-white">
              Synchronized Fundus Comparator: Baseline (2024) vs Current (2026)
            </h2>
          </div>
          <span className="text-xs text-purple-300 font-mono">OD (Right Eye) Registered</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          {/* Baseline Fundus (2024) */}
          <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 flex flex-col items-center space-y-3">
            <div className="w-full flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300">Baseline Visit (12 Mar 2024)</span>
              <span className="text-[10px] font-mono bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded border border-emerald-800">
                Grade 0: Normal Retina
              </span>
            </div>

            <div className="w-64 h-64 rounded-full overflow-hidden border-2 border-emerald-500/40 bg-black flex items-center justify-center">
              <svg viewBox="0 0 260 260" className="w-full h-full">
                <circle cx="130" cy="130" r="128" fill="#3B0C02" />
                <circle cx="85" cy="130" r="22" fill="#FBBF24" opacity="0.9" />
                <circle cx="175" cy="130" r="12" fill="#140200" stroke="#A855F7" strokeWidth="0.8" />
                <path d="M 85 125 Q 120 70 190 55" fill="none" stroke="#DC2626" strokeWidth="2.5" />
                <path d="M 85 135 Q 120 190 190 205" fill="none" stroke="#DC2626" strokeWidth="2.5" />
              </svg>
            </div>

            <div className="text-[11px] font-mono text-slate-400 text-center">
              HbA1c: 7.1% • 0 Microaneurysms • FAZ: 480µm
            </div>
          </div>

          {/* Current Fundus (2026) */}
          <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 flex flex-col items-center space-y-3">
            <div className="w-full flex items-center justify-between text-xs">
              <span className="font-bold text-purple-300">Current Visit (19 Sep 2026)</span>
              <span className="text-[10px] font-mono bg-rose-950 text-rose-300 px-2 py-0.5 rounded border border-rose-800">
                Grade 2: Moderate NPDR + DME
              </span>
            </div>

            <div className="w-64 h-64 rounded-full overflow-hidden border-2 border-rose-500/40 bg-black flex items-center justify-center">
              <svg viewBox="0 0 260 260" className="w-full h-full">
                <circle cx="130" cy="130" r="128" fill="#3B0C02" />
                <circle cx="85" cy="130" r="22" fill="#FBBF24" opacity="0.9" />
                <circle cx="175" cy="130" r="14" fill="#140200" stroke="#EF4444" strokeWidth="1" strokeDasharray="2 2" />
                <path d="M 85 125 Q 120 70 190 55" fill="none" stroke="#DC2626" strokeWidth="2.5" />
                <path d="M 85 135 Q 120 190 190 205" fill="none" stroke="#DC2626" strokeWidth="2.5" />
                {/* Microaneurysms */}
                <circle cx="160" cy="120" r="2.5" fill="#EF4444" />
                <circle cx="168" cy="140" r="2.5" fill="#EF4444" />
                <circle cx="185" cy="115" r="2.5" fill="#EF4444" />
                {/* Exudates */}
                <circle cx="165" cy="128" r="3.5" fill="#FACC15" />
                <circle cx="172" cy="120" r="3.5" fill="#FACC15" />
                <circle cx="180" cy="122" r="3.5" fill="#FACC15" />
              </svg>
            </div>

            <div className="text-[11px] font-mono text-purple-300 text-center">
              HbA1c: 9.4% (↑) • 38 Microaneurysms (↑) • FAZ: 520µm (↑)
            </div>
          </div>
        </div>
      </div>

      {/* 3 Trajectory Trend Line SVG Charts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Chart 1: HbA1c */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase">Glycemic Control</span>
            <span className="font-mono text-xs font-bold text-rose-600">9.4% (High)</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">HbA1c Progression (%)</h4>
          
          <div className="h-28 w-full bg-slate-50 rounded-xl p-2 border border-slate-100">
            <svg viewBox="0 0 200 80" className="w-full h-full overflow-visible">
              <line x1="20" y1="20" x2="180" y2="20" stroke="#E2E8F0" strokeWidth="0.5" strokeDasharray="2 2" />
              <line x1="20" y1="50" x2="180" y2="50" stroke="#E2E8F0" strokeWidth="0.5" strokeDasharray="2 2" />
              {/* Path: 7.1% (y=60), 7.8% (y=48), 8.6% (y=32), 9.4% (y=15) */}
              <polyline
                fill="none"
                stroke="#DC2626"
                strokeWidth="2.5"
                points="20,60 70,48 125,32 180,15"
              />
              <circle cx="20" cy="60" r="3" fill="#DC2626" />
              <circle cx="70" cy="48" r="3" fill="#DC2626" />
              <circle cx="125" cy="32" r="3" fill="#DC2626" />
              <circle cx="180" cy="15" r="4" fill="#991B1B" />
              <text x="20" y="75" fontSize="7" fill="#64748B" textAnchor="middle">Mar '24</text>
              <text x="70" y="75" fontSize="7" fill="#64748B" textAnchor="middle">Oct '24</text>
              <text x="125" y="75" fontSize="7" fill="#64748B" textAnchor="middle">May '25</text>
              <text x="180" y="75" fontSize="7" fill="#DC2626" fontWeight="bold" textAnchor="middle">Sep '26</text>
            </svg>
          </div>
        </div>

        {/* Chart 2: Microaneurysm Burden */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase">Capillary Ruptures</span>
            <span className="font-mono text-xs font-bold text-orange-600">38 Lesions</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">Microaneurysm Count</h4>

          <div className="h-28 w-full bg-slate-50 rounded-xl p-2 border border-slate-100">
            <svg viewBox="0 0 200 80" className="w-full h-full overflow-visible">
              <line x1="20" y1="20" x2="180" y2="20" stroke="#E2E8F0" strokeWidth="0.5" strokeDasharray="2 2" />
              <line x1="20" y1="50" x2="180" y2="50" stroke="#E2E8F0" strokeWidth="0.5" strokeDasharray="2 2" />
              {/* Path: 0 (y=70), 6 (y=58), 19 (y=38), 38 (y=12) */}
              <polyline
                fill="none"
                stroke="#EA580C"
                strokeWidth="2.5"
                points="20,70 70,58 125,38 180,12"
              />
              <circle cx="20" cy="70" r="3" fill="#EA580C" />
              <circle cx="70" cy="58" r="3" fill="#EA580C" />
              <circle cx="125" cy="38" r="3" fill="#EA580C" />
              <circle cx="180" cy="12" r="4" fill="#C2410C" />
              <text x="20" y="75" fontSize="7" fill="#64748B" textAnchor="middle">Mar '24</text>
              <text x="70" y="75" fontSize="7" fill="#64748B" textAnchor="middle">Oct '24</text>
              <text x="125" y="75" fontSize="7" fill="#64748B" textAnchor="middle">May '25</text>
              <text x="180" y="75" fontSize="7" fill="#EA580C" fontWeight="bold" textAnchor="middle">Sep '26</text>
            </svg>
          </div>
        </div>

        {/* Chart 3: FAZ Diameter */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase">Capillary Drop-out</span>
            <span className="font-mono text-xs font-bold text-purple-700">520 µm</span>
          </div>
          <h4 className="text-sm font-bold text-slate-900">FAZ Diameter (µm)</h4>

          <div className="h-28 w-full bg-slate-50 rounded-xl p-2 border border-slate-100">
            <svg viewBox="0 0 200 80" className="w-full h-full overflow-visible">
              <line x1="20" y1="30" x2="180" y2="30" stroke="#F43F5E" strokeWidth="0.8" strokeDasharray="2 2" />
              {/* Path: 480 (y=62), 490 (y=52), 505 (y=36), 520 (y=18) */}
              <polyline
                fill="none"
                stroke="#7C3AED"
                strokeWidth="2.5"
                points="20,62 70,52 125,36 180,18"
              />
              <circle cx="20" cy="62" r="3" fill="#7C3AED" />
              <circle cx="70" cy="52" r="3" fill="#7C3AED" />
              <circle cx="125" cy="36" r="3" fill="#7C3AED" />
              <circle cx="180" cy="18" r="4" fill="#581C87" />
              <text x="20" y="75" fontSize="7" fill="#64748B" textAnchor="middle">Mar '24</text>
              <text x="70" y="75" fontSize="7" fill="#64748B" textAnchor="middle">Oct '24</text>
              <text x="125" y="75" fontSize="7" fill="#64748B" textAnchor="middle">May '25</text>
              <text x="180" y="75" fontSize="7" fill="#7C3AED" fontWeight="bold" textAnchor="middle">Sep '26</text>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

