import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import CircularFundusCanvas from '../common/CircularFundusCanvas';
import {
  Stethoscope,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Printer,
  FileCheck,
  Layers,
  Sparkles,
  Sliders,
  Send
} from 'lucide-react';

export default function ReviewWorkstation() {
  const {
    selectedCase,
    submitDoctorReview,
    currentUser,
    navigateTo,
    setPrintModalOpen
  } = useRetinaCare();

  const activeCase = selectedCase || {
    id: 'RQ-8821',
    patientId: 'RC-2026-9104',
    patientName: 'Suresh Chandra Verma',
    abhaId: '91-4021-8842-1923',
    age: 58,
    gender: 'Male',
    phc: 'PHC Depalpur',
    camera: 'Remidio NM-FOP II (Handheld)',
    aiSeverity: 'Moderate NPDR',
    icdrGrade: 2,
    confidence: 0.941,
    priority: 'Urgent'
  };

  const [confirmedGrade, setConfirmedGrade] = useState(2);
  const [dmeConfirmed, setDmeConfirmed] = useState(true);
  const [urgency, setUrgency] = useState('Urgent (Within 72 Hours)');
  const [destination, setDestination] = useState('M.Y. Hospital, Indore (Retina Specialty OPD 4)');
  const [doctorNotes, setDoctorNotes] = useState(
    'I have reviewed the 45-degree non-mydriatic fundus image. Confirmed Grade 2 Moderate NPDR. Circinate hard exudate ring in perimacular area encroaching within 400µm of foveal avascular zone with significant macular edema risk. Urgent referral indicated for OCT baseline scan and possible anti-VEGF therapy.'
  );
  const [isSignedOff, setIsSignedOff] = useState(false);

  const handleSignOff = (e) => {
    e.preventDefault();
    setIsSignedOff(true);

    const gradeLabels = [
      'No Diabetic Retinopathy',
      'Mild NPDR',
      'Moderate NPDR with Clinically Significant DME',
      'Severe NPDR',
      'Proliferative Diabetic Retinopathy'
    ];

    submitDoctorReview(activeCase.id, {
      confirmedDiagnosis: gradeLabels[confirmedGrade],
      grade: confirmedGrade,
      dme: dmeConfirmed,
      notes: doctorNotes,
      urgency: urgency,
      destinationFacility: destination,
      referralGenerated: true
    });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 11 • Tele-Ophthalmology Workstation
            </span>
            <span className="text-xs text-slate-500 font-medium">Digital Signature Validated Under MCI Guidelines</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Specialist Review & Validation Station</h1>
          <p className="text-xs text-slate-600">
            Case: <span className="font-bold text-slate-900">{activeCase.patientName}</span> ({activeCase.patientId} • ABHA: {activeCase.abhaId}) • Origin: {activeCase.phc}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo(10)}
            className="px-4 py-2 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold transition"
          >
            ← Back to Queue
          </button>
          {isSignedOff && (
            <button
              onClick={() => setPrintModalOpen(true)}
              className="px-4 py-2 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 text-xs font-bold transition flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print ABDM Pass</span>
            </button>
          )}
        </div>
      </div>

      {/* 3-Zone Clinical Workstation Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Zone 1 (Left 6 Cols): Circular Retinal Canvas */}
        <div className="lg:col-span-6 bg-slate-950 rounded-3xl p-6 border border-slate-800 shadow-2xl flex flex-col items-center justify-center space-y-3">
          <div className="w-full flex items-center justify-between text-xs text-slate-400 px-2">
            <span className="font-bold text-purple-300">Right Eye (OD) • Macula-Centered</span>
            <span className="font-mono text-[11px] bg-slate-900 px-2 py-0.5 rounded border border-slate-800 text-emerald-400">
              Gradable (91%)
            </span>
          </div>

          <CircularFundusCanvas
            activeLayers={{
              microaneurysms: true,
              hemorrhages: true,
              hardExudates: true,
              cottonWoolSpots: true,
              vessels: true,
              opticDisc: true,
              fovea: true,
              gradCam: false,
              calipers: true
            }}
            size={480}
            interactive={true}
          />

          <div className="text-[11px] font-mono text-slate-400 text-center">
            Click lesions to inspect. Calipers show 380µm margin from foveola to hard exudate border.
          </div>
        </div>

        {/* Zone 2 & 3 (Right 6 Cols): AI Consensus Matrix & Doctor Validation Panel */}
        <div className="lg:col-span-6 space-y-5">
          {/* Zone 2: AI Multi-Model Consensus Card */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-700" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  AI Architecture Consensus
                </h3>
              </div>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Consensus Agreement: 100%
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase">ViT-B/16 (MC-07)</div>
                <div className="font-bold text-purple-950">Moderate NPDR</div>
                <div className="text-[10px] font-mono text-emerald-700">Prob: 0.941</div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase">EfficientNetV2 (MC-08)</div>
                <div className="font-bold text-purple-950">Moderate NPDR</div>
                <div className="text-[10px] font-mono text-emerald-700">Prob: 0.928</div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase">ConvNeXt (MC-09)</div>
                <div className="font-bold text-purple-950">Moderate NPDR</div>
                <div className="text-[10px] font-mono text-emerald-700">Prob: 0.935</div>
              </div>
            </div>
          </div>

          {/* Zone 3: Doctor Validation Panel */}
          <form onSubmit={handleSignOff} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-purple-700" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Clinician Validation & Signature
                </h3>
              </div>
              <span className="text-[10px] font-mono text-slate-500">
                Dr. {currentUser.name.split(' ')[1]} ({currentUser.mciRegNo})
              </span>
            </div>

            {/* Diagnosis Selection */}
            <div>
              <label className="block text-slate-700 font-bold mb-1">
                Confirmed ICDR Stage (Clinical Decision)
              </label>
              <select
                value={confirmedGrade}
                onChange={(e) => setConfirmedGrade(Number(e.target.value))}
                className="w-full p-2.5 border border-slate-300 rounded-xl text-slate-900 font-bold focus:outline-none focus:border-purple-600"
              >
                <option value={0}>Grade 0: No Diabetic Retinopathy</option>
                <option value={1}>Grade 1: Mild Non-Proliferative DR</option>
                <option value={2}>Grade 2: Moderate Non-Proliferative DR (AI Confirmed)</option>
                <option value={3}>Grade 3: Severe Non-Proliferative DR</option>
                <option value={4}>Grade 4: Proliferative Diabetic Retinopathy</option>
              </select>
            </div>

            {/* DME Checkbox */}
            <div className="flex items-center gap-3 p-3 bg-purple-50/70 border border-purple-200 rounded-xl">
              <input
                type="checkbox"
                id="dmeConfirm"
                checked={dmeConfirmed}
                onChange={(e) => setDmeConfirmed(e.target.checked)}
                className="w-4 h-4 text-purple-700 rounded"
              />
              <label htmlFor="dmeConfirm" className="font-bold text-purple-950">
                Clinically Significant Macular Edema (CSME) confirmed on clinical grounds
              </label>
            </div>

            {/* Referral Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Referral Urgency</label>
                <select
                  value={urgency}
                  onChange={(e) => setUrgency(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-slate-900"
                >
                  <option>Urgent (Within 72 Hours)</option>
                  <option>Emergency (Within 24 Hours)</option>
                  <option>Priority (Within 7 Days)</option>
                  <option>Routine (Annual Recall)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Specialty Hub</label>
                <select
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  className="w-full p-2 border border-slate-300 rounded-lg text-slate-900"
                >
                  <option>M.Y. Hospital, Indore (Retina Specialty OPD 4)</option>
                  <option>Indore District Eye Hospital (Civil Dispensary)</option>
                </select>
              </div>
            </div>

            {/* Doctor Clinical Notes */}
            <div>
              <label className="block text-slate-700 font-semibold mb-1">Doctor Tele-Ophthalmology Notes</label>
              <textarea
                rows="4"
                value={doctorNotes}
                onChange={(e) => setDoctorNotes(e.target.value)}
                className="w-full p-2.5 border border-slate-300 rounded-xl text-slate-800 leading-relaxed focus:outline-none focus:border-purple-600"
              />
            </div>

            {/* Action Submit */}
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold text-xs uppercase tracking-wider transition flex items-center justify-center gap-2 shadow-lg shadow-purple-900/30 cursor-pointer"
            >
              <FileCheck className="w-4 h-4" />
              <span>Sign Off & Issue Fast-Track ABDM Referral</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

