import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import CalibrationGraph from '../common/CalibrationGraph';
import {
  Boxes,
  ShieldCheck,
  CheckCircle2,
  Database,
  Cpu,
  Layers,
  HardDrive,
  Sparkles,
  ExternalLink,
  Award
} from 'lucide-react';

export default function AIModelCentre() {
  const { aiClusterModels, navigateTo } = useRetinaCare();

  const [activeTab, setActiveTab] = useState('registry'); // 'registry', 'datasets', 'telemetry'

  const datasets = [
    {
      name: 'AIIMS Rural India Retinal Cohort',
      count: '6,240 Images',
      source: 'AIIMS New Delhi & Madhya Pradesh Rural PHC Field Units',
      population: 'Indian Central Region (MP & UP), Non-mydriatic handheld cameras',
      drPrevalence: '14.2%',
      annotation: 'Triple Consensus Board-Certified Retinal Specialists (MS Ophthal)'
    },
    {
      name: 'EyePACS Telehealth Database',
      count: '88,702 Images',
      source: 'EyePACS Primary Care Tele-retinal Program',
      population: 'Multi-ethnic community clinic screening',
      drPrevalence: '19.4%',
      annotation: 'Licensed Optometrists and Ophthalmologists'
    },
    {
      name: 'Messidor-2 Benchmark',
      count: '1,748 Images',
      source: 'French National Research Project (Messidor Consortium)',
      population: 'European Diabetic Clinic Cohort (Topcon TRC NW6 non-mydriatic)',
      drPrevalence: '22.8%',
      annotation: 'Reference standard for DME and referable DR benchmarking'
    },
    {
      name: 'DDR Dataset',
      count: '13,673 Images',
      source: 'Multi-hospital Diabetic Retinopathy Cohort',
      population: 'East Asian cohort with pixel-level lesion bounding masks',
      drPrevalence: '45.1%',
      annotation: 'Pixel-level segmentation for MAs, Hemorrhages, Hard/Soft Exudates'
    },
    {
      name: 'APTOS 2019 Blindness Detection',
      count: '3,662 Images',
      source: 'Aravind Eye Hospital, Tamil Nadu, India',
      population: 'Rural India mobile eye camps',
      drPrevalence: '48.9%',
      annotation: 'Aravind Vitreoretinal Faculty'
    }
  ];

  const flattenedModels = [];
  aiClusterModels.forEach((c) => {
    c.models.forEach((m) => {
      flattenedModels.push({
        ...m,
        clusterName: c.clusterName,
        clusterId: c.clusterId
      });
    });
  });

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 15 • AI Governance & Model Registry
            </span>
            <span className="text-xs text-slate-500 font-medium">CDSCO Class B Clinical Decision Support Architecture</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">AI Model Registry & External Validation</h1>
          <p className="text-xs text-slate-600">
            Transparent registry of all 15 neural architectures, benchmarked targets, and demographic validation datasets.
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
          <button
            onClick={() => setActiveTab('registry')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'registry' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            15-Model Registry
          </button>
          <button
            onClick={() => setActiveTab('datasets')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'datasets' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Validation Datasets (5)
          </button>
          <button
            onClick={() => setActiveTab('telemetry')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'telemetry' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Edge Telemetry
          </button>
        </div>
      </div>

      {activeTab === 'registry' && (
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Boxes className="w-4 h-4 text-purple-700" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                Full 15-Model Architecture Registry
              </h3>
            </div>
            <span className="text-[11px] font-mono text-purple-700 font-bold bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Total Ensemble Latency: 84.6ms
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                  <th className="py-3 px-4">ID</th>
                  <th className="py-3 px-4">Model Name</th>
                  <th className="py-3 px-4">Functional Cluster</th>
                  <th className="py-3 px-4">Backbone Architecture</th>
                  <th className="py-3 px-4">Target AUC</th>
                  <th className="py-3 px-4">Validated AUC</th>
                  <th className="py-3 px-4">Latency</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {flattenedModels.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-4 font-mono font-bold text-purple-800">{m.id}</td>
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900">{m.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{m.primaryTask}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">{m.clusterName.split('&')[0]}</td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-600">{m.arch}</td>
                    <td className="py-3 px-4 font-mono text-slate-500">{m.targetMetric}</td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-700">{m.validatedMetric}</td>
                    <td className="py-3 px-4 font-mono text-slate-600">{m.latencyMs}</td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        <CheckCircle2 className="w-3 h-3" />
                        Validated
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'datasets' && (
        <div className="space-y-4">
          <div className="p-4 bg-purple-50 border border-purple-200 rounded-2xl text-xs text-purple-900 leading-relaxed">
            <span className="font-bold">Demographic Fairness Protocol: </span>
            Models are evaluated across rural primary health centres in India (including AIIMS Rural Cohort) to guard against camera hardware domain shift, cataract media opacity degradation, and skin/retinal pigmentation variance.
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {datasets.map((d, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-2 text-xs"
              >
                <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                  <div className="font-bold text-slate-900 text-sm">{d.name}</div>
                  <span className="font-mono text-[11px] font-bold text-purple-800 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                    {d.count}
                  </span>
                </div>
                <div className="space-y-1 text-slate-600">
                  <div>
                    <span className="font-semibold text-slate-700">Source:</span> {d.source}
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">Population:</span> {d.population}
                  </div>
                  <div>
                    <span className="font-semibold text-slate-700">DR Prevalence:</span>{' '}
                    <span className="font-bold text-purple-900">{d.drPrevalence}</span>
                  </div>
                  <div className="pt-1 text-[11px] text-slate-500 italic">
                    Annotation Standard: {d.annotation}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'telemetry' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-900 border-b border-slate-200 pb-2">
              Edge Hardware & TensorRT Telemetry
            </h3>
            <div className="space-y-2.5">
              <div className="flex justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-600">Runtime Acceleration</span>
                <span className="font-bold font-mono text-purple-900">TensorRT FP16 (GPU/NPU)</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-600">Peak System RAM Footprint</span>
                <span className="font-bold font-mono text-slate-900">1.42 GB (Edge Optimized)</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-600">End-to-End Ensemble Latency</span>
                <span className="font-bold font-mono text-emerald-700">84.6 milliseconds</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-600">Camera Interop Adapters</span>
                <span className="font-bold font-mono text-slate-900">Remidio, Forus 3nethra, Bosch</span>
              </div>
              <div className="flex justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-slate-600">Data Privacy Standard</span>
                <span className="font-bold font-mono text-purple-900">Zero Cloud Leakage • Local Edge Triage</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <CalibrationGraph />
          </div>
        </div>
      )}
    </div>
  );
}

