import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  Eye,
  ShieldCheck,
  Building2,
  Lock,
  User,
  KeyRound,
  ArrowRight,
  WifiOff,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export default function ClinicalLogin() {
  const {
    navigateTo,
    setCurrentUser,
    toggleOffline,
    offlineMode,
    showToast
  } = useRetinaCare();

  const [role, setRole] = useState('doctor');
  const [facility, setFacility] = useState('M.Y. Hospital Central Hub (Indore)');
  const [abhaDoctorId, setAbhaDoctorId] = useState('DOC-MP-IND-8841');
  const [password, setPassword] = useState('••••••••••••');

  const handleLogin = (e) => {
    e.preventDefault();
    if (role === 'doctor') {
      setCurrentUser({
        name: 'Dr. Ananya Sharma',
        role: 'Ophthalmologist (Tele-Review Lead)',
        initials: 'AS',
        email: 'ananya.sharma@myh-indore.gov.in',
        facility: facility,
        mciRegNo: 'MP-MC-2015-88412'
      });
    } else if (role === 'nurse') {
      setCurrentUser({
        name: 'Sister Sunita Patidar',
        role: 'Trained Retinal Screener (CHO)',
        initials: 'SP',
        email: 'sunita.patidar@phc-depalpur.gov.in',
        facility: 'Depalpur Community Health Centre',
        mciRegNo: 'MP-NUR-2019-3321'
      });
    } else {
      setCurrentUser({
        name: 'Dr. B. S. Saitya',
        role: 'Chief Medical Officer / District Admin',
        initials: 'BS',
        email: 'cmo.indore@mp.gov.in',
        facility: 'District Health Office, Indore',
        mciRegNo: 'MP-MC-1998-1092'
      });
    }

    showToast('Authentication Successful', 'Logged into ABDM Tele-Ophthalmology gateway.', 'success');
    navigateTo(2); // Advance to Command Centre
  };

  const handleFastLogin = (chosenRole) => {
    setRole(chosenRole);
    if (chosenRole === 'doctor') {
      setAbhaDoctorId('DOC-MP-IND-8841');
    } else if (chosenRole === 'nurse') {
      setAbhaDoctorId('CHO-DPLP-4402');
      setFacility('Depalpur Community Health Centre');
    } else {
      setAbhaDoctorId('ADMIN-IND-001');
      setFacility('District Health Office, Indore');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row text-slate-900">
      {/* Left Optical Canvas / Fundus Glow Hero */}
      <div className="lg:w-7/12 relative flex flex-col justify-between p-8 lg:p-12 overflow-hidden border-b lg:border-b-0 lg:border-r border-slate-200 bg-gradient-to-br from-purple-50/80 via-indigo-50/40 to-white">
        {/* Background optical scan rings & glow */}
        <div className="absolute -top-32 -left-32 w-[550px] h-[550px] rounded-full bg-purple-200/40 blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[480px] h-[480px] rounded-full border border-purple-200/60 pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] rounded-full border border-purple-300/40 pointer-events-none" />

        {/* Brand Header */}
        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-purple-700 to-indigo-600 flex items-center justify-center shadow-lg shadow-purple-600/20 ring-1 ring-purple-200">
              <Eye className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-slate-900 flex items-center gap-2">
                RetinaCare AI
                <span className="text-[11px] font-mono uppercase px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 border border-purple-200 font-bold">
                  NHM Pilot
                </span>
              </h1>
              <p className="text-xs text-purple-700 font-semibold">
                See Earlier. Explain Clearly. Refer Smarter.
              </p>
            </div>
          </div>
        </div>

        {/* Central Graphic Callout */}
        <div className="relative z-10 my-12 max-w-xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-purple-100/90 border border-purple-200 text-purple-900 text-xs font-semibold shadow-2xs">
            <ShieldCheck className="w-4 h-4 text-purple-700" />
            <span>ABDM Unified Health Interface Compliant • CDSCO Class B</span>
          </div>

          <h2 className="text-3xl lg:text-4xl font-black text-slate-900 leading-tight">
            AI-Powered Smart Retinopathy Screening for Rural & District Healthcare
          </h2>

          <p className="text-sm text-slate-600 leading-relaxed font-normal">
            Empowering Community Health Officers at Primary Health Centres with 15-model deep learning ensembles, lesion-level explainability, and fast-track tele-ophthalmology referral channels to tertiary hubs.
          </p>

          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-3 gap-3 pt-2">
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <div className="text-2xl font-black text-slate-900">12,842</div>
              <div className="text-[11px] text-slate-500 font-medium">Patients Screened</div>
            </div>
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <div className="text-2xl font-black text-purple-700">96.8%</div>
              <div className="text-[11px] text-slate-500 font-medium">Gradability Rate</div>
            </div>
            <div className="p-4 rounded-2xl bg-white border border-slate-200 shadow-xs">
              <div className="text-2xl font-black text-emerald-600">3.4 Days</div>
              <div className="text-[11px] text-slate-500 font-medium">Avg Referral Transit</div>
            </div>
          </div>
        </div>

        {/* Footer Disclaimer */}
        <div className="relative z-10 text-[11px] text-slate-500 border-t border-slate-200/80 pt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <span>AI assists, clinician decides • Human-in-the-loop governance mandatory</span>
          <span className="font-mono text-slate-600 font-medium">Indore District Rollout v4.2</span>
        </div>
      </div>

      {/* Right Login Panel */}
      <div className="lg:w-5/12 p-8 lg:p-12 flex flex-col justify-center bg-white shadow-xl lg:shadow-none">
        <div className="max-w-md w-full mx-auto space-y-6">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-purple-700 font-mono">
              Secure Clinical Gateway
            </span>
            <h3 className="text-2xl font-bold text-slate-900 mt-1">Practitioner Sign In</h3>
            <p className="text-xs text-slate-500 mt-1">
              Authenticate via National Health Authority / ABHA credentials
            </p>
          </div>

          {/* Fast Role Selectors */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700">Select Role Simulation:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleFastLogin('doctor')}
                className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  role === 'doctor'
                    ? 'bg-purple-50 border-2 border-purple-600 text-purple-950 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <div className="font-bold text-xs">Ophthalmologist</div>
                <div className="text-[10px] text-purple-700 font-medium">Dr. Sharma</div>
              </button>

              <button
                type="button"
                onClick={() => handleFastLogin('nurse')}
                className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  role === 'nurse'
                    ? 'bg-purple-50 border-2 border-purple-600 text-purple-950 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <div className="font-bold text-xs">PHC Screener</div>
                <div className="text-[10px] text-purple-700 font-medium">Sister Sunita</div>
              </button>

              <button
                type="button"
                onClick={() => handleFastLogin('admin')}
                className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                  role === 'admin'
                    ? 'bg-purple-50 border-2 border-purple-600 text-purple-950 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <div className="font-bold text-xs">District Admin</div>
                <div className="text-[10px] text-purple-700 font-medium">CMO Indore</div>
              </button>
            </div>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div>
              <label className="block text-slate-700 font-medium mb-1">Health Facility Node</label>
              <div className="relative">
                <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <select
                  value={facility}
                  onChange={(e) => setFacility(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-4 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-600 text-xs transition shadow-2xs"
                >
                  <option>M.Y. Hospital Central Hub (Indore)</option>
                  <option>Depalpur Community Health Centre</option>
                  <option>Dr. Ambedkar Nagar (Mhow) Civil Hospital</option>
                  <option>Sanwer Primary Health Centre</option>
                  <option>Rau Primary Health Centre</option>
                  <option>Betma Primary Health Centre</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">ABHA / Practitioner ID</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={abhaDoctorId}
                  onChange={(e) => setAbhaDoctorId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-4 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-600 text-xs font-mono shadow-2xs"
                  placeholder="DOC-MP-IND-XXXX"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-medium mb-1">Security PIN / Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-4 py-2.5 text-slate-900 focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-600 text-xs shadow-2xs"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-purple-700 hover:bg-purple-800 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition shadow-md shadow-purple-700/20 cursor-pointer"
            >
              <span>Authenticate & Enter Platform</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Continue Offline Option */}
          <div className="pt-3 border-t border-slate-200 text-center space-y-2">
            <button
              type="button"
              onClick={() => {
                if (!offlineMode) toggleOffline();
                navigateTo(2);
              }}
              className="inline-flex items-center gap-2 text-xs text-amber-800 hover:text-amber-900 font-semibold transition bg-amber-50 hover:bg-amber-100/80 border border-amber-200 px-3.5 py-1.5 rounded-lg cursor-pointer shadow-2xs"
            >
              <WifiOff className="w-3.5 h-3.5 text-amber-600" />
              <span>Continue in Offline Tele-Mode (PHC Local Store)</span>
            </button>
            <p className="text-[10px] text-slate-500">
              Offline mode enables full local image grading with delayed batch sync to district servers.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

