import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  QrCode,
  UserPlus,
  Activity,
  Eye,
  ShieldCheck,
  Calendar,
  Phone,
  MapPin,
  Heart,
  ArrowRight,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

export default function PatientRegistration() {
  const { registerNewPatient, showToast } = useRetinaCare();

  const [activeStep, setActiveStep] = useState(1);
  const [formData, setFormData] = useState({
    name: 'Suresh Chandra Verma',
    abhaId: '91-4021-8842-1923',
    age: 58,
    gender: 'Male',
    phone: '+91 98260 41234',
    address: 'Gram Panchayat Depalpur, Ward 4, Indore MP - 453115',
    ashaWorker: 'Kamla Devi (+91 94250 88219)',
    diabetesType: 'Type 2 Diabetes Mellitus',
    diabetesDurationYears: 12,
    hba1c: 9.4,
    fastingBloodSugar: 198,
    bloodPressure: '148/92 mmHg',
    hypertension: true,
    visualAcuityOD: '6/12',
    visualAcuityOS: '6/9',
    symptoms: 'Blurred vision in right eye when reading; mild glare at night',
    priorLaser: 'None',
    priorInjections: 'None',
    allergies: 'No known drug allergies (NKDA)',
    consentSigned: true
  });

  const handleSimulateAbhaScan = () => {
    setFormData({
      name: 'Suresh Chandra Verma',
      abhaId: '91-4021-8842-1923',
      age: 58,
      gender: 'Male',
      phone: '+91 98260 41234',
      address: 'Gram Panchayat Depalpur, Ward 4, Indore MP - 453115',
      ashaWorker: 'Kamla Devi (+91 94250 88219)',
      diabetesType: 'Type 2 Diabetes Mellitus',
      diabetesDurationYears: 12,
      hba1c: 9.4,
      fastingBloodSugar: 198,
      bloodPressure: '148/92 mmHg',
      hypertension: true,
      visualAcuityOD: '6/12',
      visualAcuityOS: '6/9',
      symptoms: 'Blurred vision in right eye when reading; mild glare at night',
      priorLaser: 'None',
      priorInjections: 'None',
      allergies: 'No known drug allergies (NKDA)',
      consentSigned: true
    });
    showToast('ABHA Token Scanned', 'Demographics pulled directly from National Health Authority gateway.', 'success');
  };

  const handleRegister = (e) => {
    e.preventDefault();
    registerNewPatient(formData);
  };

  const steps = [
    { num: 1, title: 'Demographics & ABHA' },
    { num: 2, title: 'Metabolic Profile' },
    { num: 3, title: 'Visual Acuity & Symptoms' },
    { num: 4, title: 'Ophthalmic History' },
    { num: 5, title: 'Comorbidities' },
    { num: 6, title: 'Consent & Imaging Queue' }
  ];

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              CDSS Level 1 Intake
            </span>
            <span className="text-xs text-slate-500 font-medium">PHC Depalpur Screener Station</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mt-1">Patient Intake & ABHA Verification</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Collect baseline metabolic biomarkers, visual acuity, and sync patient digital health record.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSimulateAbhaScan}
          className="px-4 py-2.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold text-xs flex items-center gap-2 border border-purple-300 shadow-xs transition"
        >
          <QrCode className="w-4 h-4 text-purple-700" />
          <span>Simulate ABHA Card Scan</span>
        </button>
      </div>

      {/* Stepper Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 text-xs">
          {steps.map((step) => {
            const isActive = activeStep === step.num;
            const isDone = activeStep > step.num;
            return (
              <button
                key={step.num}
                type="button"
                onClick={() => setActiveStep(step.num)}
                className={`p-2.5 rounded-xl border text-left transition ${
                  isActive
                    ? 'border-purple-600 bg-purple-50 text-purple-950 font-bold shadow-xs'
                    : isDone
                    ? 'border-emerald-300 bg-emerald-50 text-emerald-900'
                    : 'border-slate-200 bg-slate-50 text-slate-500'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono font-bold">0{step.num}</span>
                  {isDone && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                </div>
                <div className="truncate text-[11px] mt-1">{step.title}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Form Content */}
      <form onSubmit={handleRegister} className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
        {/* Step 1: Demographics */}
        {activeStep === 1 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
              Step 1: Patient Identity & Ayushman Bharat Health Account (ABHA)
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Full Legal Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-purple-600"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">14-Digit ABHA ID</label>
                <input
                  type="text"
                  value={formData.abhaId}
                  onChange={(e) => setFormData({ ...formData, abhaId: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-purple-900 font-mono font-bold focus:outline-none focus:border-purple-600"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Age (Years)</label>
                  <input
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: Number(e.target.value) })}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                  >
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Mobile Phone Number</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-slate-700 font-semibold mb-1">Residential Address / Village</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-slate-700 font-semibold mb-1">Assigned ASHA Health Facilitator</label>
                <input
                  type="text"
                  value={formData.ashaWorker}
                  onChange={(e) => setFormData({ ...formData, ashaWorker: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Metabolic Profile */}
        {activeStep === 2 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
              Step 2: Diabetes Severity & Metabolic Biomarkers
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Diabetes Diagnosis Classification</label>
                <select
                  value={formData.diabetesType}
                  onChange={(e) => setFormData({ ...formData, diabetesType: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                >
                  <option>Type 2 Diabetes Mellitus</option>
                  <option>Type 1 Diabetes Mellitus</option>
                  <option>Gestational Diabetes</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Duration of Diabetes (Years)</label>
                <input
                  type="number"
                  value={formData.diabetesDurationYears}
                  onChange={(e) => setFormData({ ...formData, diabetesDurationYears: Number(e.target.value) })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                />
                <span className="text-[10px] text-amber-600 font-medium">≥10 years significantly elevates NPDR risk</span>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Latest Glycated Hemoglobin (HbA1c %)</label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.hba1c}
                  onChange={(e) => setFormData({ ...formData, hba1c: Number(e.target.value) })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-rose-700 font-bold font-mono"
                />
                <span className="text-[10px] text-rose-600 font-semibold">9.4% (Uncontrolled Glycemia)</span>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Fasting Blood Glucose (mg/dL)</label>
                <input
                  type="number"
                  value={formData.fastingBloodSugar}
                  onChange={(e) => setFormData({ ...formData, fastingBloodSugar: Number(e.target.value) })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 3: Visual Acuity */}
        {activeStep === 3 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
              Step 3: Snellen Visual Acuity & Presenting Complaints
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Right Eye (OD) Snellen Acuity</label>
                <select
                  value={formData.visualAcuityOD}
                  onChange={(e) => setFormData({ ...formData, visualAcuityOD: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900 font-mono"
                >
                  <option>6/6 (Normal)</option>
                  <option>6/9</option>
                  <option>6/12 (Mild Impairment)</option>
                  <option>6/18</option>
                  <option>6/24</option>
                  <option>6/60 (Severe Impairment)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">Left Eye (OS) Snellen Acuity</label>
                <select
                  value={formData.visualAcuityOS}
                  onChange={(e) => setFormData({ ...formData, visualAcuityOS: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900 font-mono"
                >
                  <option>6/6 (Normal)</option>
                  <option>6/9</option>
                  <option>6/12</option>
                  <option>6/18</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-slate-700 font-semibold mb-1">Subjective Visual Symptoms</label>
                <textarea
                  rows="3"
                  value={formData.symptoms}
                  onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-purple-600"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Ophthalmic History */}
        {activeStep === 4 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
              Step 4: Prior Retinal Procedures & Cataract History
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Prior Retinal Photocoagulation / Laser</label>
                <input
                  type="text"
                  value={formData.priorLaser}
                  onChange={(e) => setFormData({ ...formData, priorLaser: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Prior Intravitreal Anti-VEGF / Steroid</label>
                <input
                  type="text"
                  value={formData.priorInjections}
                  onChange={(e) => setFormData({ ...formData, priorInjections: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>
            </div>
          </div>
        )}

        {/* Step 5: Comorbidities */}
        {activeStep === 5 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
              Step 5: Systemic Microvascular Comorbidities
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">Blood Pressure (Sitting)</label>
                <input
                  type="text"
                  value={formData.bloodPressure}
                  onChange={(e) => setFormData({ ...formData, bloodPressure: e.target.value })}
                  className="w-full p-2.5 border border-slate-300 rounded-lg text-slate-900"
                />
              </div>
              <div className="flex items-center gap-3 pt-6">
                <input
                  type="checkbox"
                  id="htn"
                  checked={formData.hypertension}
                  onChange={(e) => setFormData({ ...formData, hypertension: e.target.checked })}
                  className="w-4 h-4 text-purple-600 rounded"
                />
                <label htmlFor="htn" className="text-slate-800 font-semibold">
                  Patient diagnosed with Systemic Hypertension
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Step 6: Consent & Final Enqueue */}
        {activeStep === 6 && (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 border-b border-slate-200 pb-2">
              Step 6: Informed Consent & Capture Studio Enqueue
            </h3>
            
            <div className="p-4 bg-purple-50 border border-purple-200 rounded-xl space-y-2 text-xs text-slate-700">
              <div className="font-bold text-purple-950 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-purple-700" />
                ABDM Patient Consent Clause (Rule 2021)
              </div>
              <p className="leading-relaxed">
                I hereby grant consent for tele-ophthalmic retinal imaging, automated clinical decision support analysis, and transmission of encrypted retinal scans to authorized government ophthalmologists at M.Y. Hospital Hub.
              </p>
              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="consent"
                  checked={formData.consentSigned}
                  onChange={(e) => setFormData({ ...formData, consentSigned: e.target.checked })}
                  className="w-4 h-4 text-purple-600 rounded"
                  required
                />
                <label htmlFor="consent" className="font-bold text-slate-900">
                  Patient digital signature / thumbprint recorded by Sister Sunita Patidar
                </label>
              </div>
            </div>

            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-700 flex-shrink-0 mt-0.5" />
              <span>
                Automated risk index: <span className="font-bold">High Risk (0.89)</span> due to 12-year DM duration + HbA1c 9.4% + hypertension. Fast-track imaging enqueued.
              </span>
            </div>
          </div>
        )}

        {/* Stepper Navigation Buttons */}
        <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            disabled={activeStep === 1}
            onClick={() => setActiveStep((s) => Math.max(s - 1, 1))}
            className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:hover:bg-transparent text-xs font-semibold"
          >
            Back
          </button>

          {activeStep < 6 ? (
            <button
              type="button"
              onClick={() => setActiveStep((s) => Math.min(s + 1, 6))}
              className="px-5 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold transition flex items-center gap-2"
            >
              <span>Continue Step</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 shadow-lg shadow-purple-900/30"
            >
              <span>Complete & Launch Capture Studio</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </form>
    </div>
  );
}

