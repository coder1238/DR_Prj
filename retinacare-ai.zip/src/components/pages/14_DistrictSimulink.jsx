import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  TrendingUp,
  Sliders,
  MapPin,
  Building2,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  RotateCcw,
  Zap,
  BarChart3
} from 'lucide-react';

export default function DistrictSimulink() {
  const {
    phcCenters,
    districtMetrics,
    simulinkParams,
    setSimulinkParams,
    showToast
  } = useRetinaCare();

  const [activeTab, setActiveTab] = useState('simulink'); // 'simulink', 'map'
  const [params, setParams] = useState(simulinkParams);

  // Dynamic calculations based on params
  const monthlyScreened = params.dailyScreeningVolume * 26; // 26 working days
  const estimatedReferralRate = 0.081 + (1 - params.aiTriageCutoff) * 0.04;
  const monthlyReferrals = Math.round(monthlyScreened * estimatedReferralRate);
  const monthlySpecialistCapacity = Math.round((params.specialistWeeklySlots * 52) / 12);
  const hubUtilization = Math.min(Math.round((monthlyReferrals / monthlySpecialistCapacity) * 100), 160);
  const isBottleneck = hubUtilization > 95;
  const avgWaitDays = isBottleneck
    ? (3.4 + (hubUtilization - 95) * 0.3).toFixed(1)
    : Math.max(1.8, (3.4 - (params.transportSubsidyInr / 500) * 1.2)).toFixed(1);

  const totalMonthlyBudgetLakhs = (
    (monthlyScreened * 45 +
      monthlyReferrals * params.transportSubsidyInr +
      monthlyReferrals * params.ashaFollowupIncentiveInr +
      params.mobileVanDeployments * 65000) /
    100000
  ).toFixed(2);

  const handleApplySurgePreset = () => {
    const surge = {
      ...params,
      dailyScreeningVolume: 320,
      mobileVanDeployments: 6,
      aiTriageCutoff: 0.75,
      transportSubsidyInr: 350
    };
    setParams(surge);
    setSimulinkParams(surge);
    showToast('Camp Surge Scenario Applied', 'Simulated 320 screenings/day with 6 mobile vans deployed across Indore rural blocks.', 'info');
  };

  const handleReset = () => {
    setParams(simulinkParams);
    showToast('Reset to Baseline Parameters', 'Default district operational parameters restored.', 'info');
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 14 • District Health Systems Engineering
            </span>
            <span className="text-xs text-slate-500 font-medium">{districtMetrics.districtName}</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">District Operations & Simulink Capacity Engine</h1>
          <p className="text-xs text-slate-600">
            Simulate healthcare resource scaling, specialist workload bottlenecks, and referral transit queues.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
          <button
            onClick={() => setActiveTab('simulink')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'simulink' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Simulink Capacity Simulator
          </button>
          <button
            onClick={() => setActiveTab('map')}
            className={`px-3 py-1.5 rounded-lg transition ${
              activeTab === 'map' ? 'bg-purple-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            District PHC Network Map
          </button>
        </div>
      </div>

      {/* Dynamic Forecast Outcome KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Monthly Screenings</div>
          <div className="text-2xl font-black text-slate-900 mt-1">{monthlyScreened.toLocaleString()}</div>
          <div className="text-[10px] text-purple-700 font-semibold mt-0.5">{params.dailyScreeningVolume}/day target</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Monthly Referrals</div>
          <div className="text-2xl font-black text-purple-900 mt-1">{monthlyReferrals.toLocaleString()}</div>
          <div className="text-[10px] text-slate-500 mt-0.5">{(estimatedReferralRate * 100).toFixed(1)}% detection rate</div>
        </div>

        <div className={`p-4 rounded-2xl border shadow-xs ${
          isBottleneck ? 'bg-rose-50 border-rose-300' : 'bg-white border-slate-200'
        }`}>
          <div className="text-[10px] font-bold uppercase text-slate-500">Hub Specialist Load</div>
          <div className={`text-2xl font-black mt-1 ${isBottleneck ? 'text-rose-600' : 'text-emerald-600'}`}>
            {hubUtilization}%
          </div>
          <div className="text-[10px] font-semibold mt-0.5">
            {isBottleneck ? '⚠️ CAPACITY OVERLOAD' : 'Within Safe Range'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Avg Referral Wait</div>
          <div className="text-2xl font-black text-indigo-700 mt-1">{avgWaitDays} Days</div>
          <div className="text-[10px] text-slate-500 mt-0.5">Target: &lt; 5.0 Days</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase">Est. Monthly Budget</div>
          <div className="text-2xl font-black text-emerald-700 mt-1">₹{totalMonthlyBudgetLakhs} L</div>
          <div className="text-[10px] text-slate-500 mt-0.5">NHM NHSRC Grant</div>
        </div>
      </div>

      {activeTab === 'simulink' ? (
        /* Simulink Sliders Grid */
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-purple-700" />
                <h2 className="text-base font-bold text-slate-900">
                  10-Parameter Health Systems Dynamics Engine
                </h2>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Adjust variables in real-time to forecast district-wide throughput and OPD capacity.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleApplySurgePreset}
                className="px-3 py-1.5 rounded-xl bg-purple-100 hover:bg-purple-200 text-purple-900 font-bold text-xs transition flex items-center gap-1.5"
              >
                <Zap className="w-3.5 h-3.5 text-purple-700" />
                <span>Simulate Camp Surge</span>
              </button>
              <button
                onClick={handleReset}
                className="px-3 py-1.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-600 text-xs font-semibold transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Slider 1 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>1. Daily Screening Target (Patients/Day)</span>
                <span className="font-mono text-purple-900 text-sm">{params.dailyScreeningVolume}</span>
              </div>
              <input
                type="range"
                min="50"
                max="500"
                step="5"
                value={params.dailyScreeningVolume}
                onChange={(e) => setParams({ ...params, dailyScreeningVolume: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>50 / day</span>
                <span>500 / day</span>
              </div>
            </div>

            {/* Slider 2 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>2. AI Triage Sensitivity Cutoff Score</span>
                <span className="font-mono text-purple-900 text-sm">{params.aiTriageCutoff.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.50"
                max="0.90"
                step="0.01"
                value={params.aiTriageCutoff}
                onChange={(e) => setParams({ ...params, aiTriageCutoff: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0.50 (High Recall)</span>
                <span>0.90 (High Precision)</span>
              </div>
            </div>

            {/* Slider 3 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>3. Specialist Weekly Slots (M.Y. Hospital Hub)</span>
                <span className="font-mono text-purple-900 text-sm">{params.specialistWeeklySlots}</span>
              </div>
              <input
                type="range"
                min="100"
                max="800"
                step="25"
                value={params.specialistWeeklySlots}
                onChange={(e) => setParams({ ...params, specialistWeeklySlots: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>100 slots/wk</span>
                <span>800 slots/wk</span>
              </div>
            </div>

            {/* Slider 4 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>4. Govt Patient Transport Subsidy (₹ / Patient)</span>
                <span className="font-mono text-emerald-800 text-sm">₹{params.transportSubsidyInr}</span>
              </div>
              <input
                type="range"
                min="0"
                max="500"
                step="25"
                value={params.transportSubsidyInr}
                onChange={(e) => setParams({ ...params, transportSubsidyInr: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>₹0 (Unsubsidized)</span>
                <span>₹500 (Full 108/Bus)</span>
              </div>
            </div>

            {/* Slider 5 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>5. Mobile Retinal Screening Vans Deployed</span>
                <span className="font-mono text-purple-900 text-sm">{params.mobileVanDeployments} Vans</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={params.mobileVanDeployments}
                onChange={(e) => setParams({ ...params, mobileVanDeployments: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
            </div>

            {/* Slider 6 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>6. ASHA Follow-up Incentive (₹ / Verified Case)</span>
                <span className="font-mono text-emerald-800 text-sm">₹{params.ashaFollowupIncentiveInr}</span>
              </div>
              <input
                type="range"
                min="50"
                max="300"
                step="25"
                value={params.ashaFollowupIncentiveInr}
                onChange={(e) => setParams({ ...params, ashaFollowupIncentiveInr: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
            </div>

            {/* Slider 7 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>7. Repeat Screening Recall Cycle (Months)</span>
                <span className="font-mono text-purple-900 text-sm">{params.repeatScreeningIntervalMonths} Mo</span>
              </div>
              <input
                type="range"
                min="6"
                max="24"
                step="6"
                value={params.repeatScreeningIntervalMonths}
                onChange={(e) => setParams({ ...params, repeatScreeningIntervalMonths: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
            </div>

            {/* Slider 8 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>8. High-Risk Fast-Track Threshold</span>
                <span className="font-mono text-purple-900 text-sm">{params.highRiskFastTrackThreshold.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.70"
                max="0.95"
                step="0.05"
                value={params.highRiskFastTrackThreshold}
                onChange={(e) => setParams({ ...params, highRiskFastTrackThreshold: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
            </div>

            {/* Slider 9 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>9. Tele-Review Batch Size (Cases / Slot)</span>
                <span className="font-mono text-purple-900 text-sm">{params.teleReviewBatchSize} Cases</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={params.teleReviewBatchSize}
                onChange={(e) => setParams({ ...params, teleReviewBatchSize: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
            </div>

            {/* Slider 10 */}
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <div className="flex justify-between font-bold text-slate-800">
                <span>10. Patient Opt-Out / Non-Compliance Rate</span>
                <span className="font-mono text-rose-700 text-sm">{params.optOutRatePercent}%</span>
              </div>
              <input
                type="range"
                min="1"
                max="15"
                step="0.5"
                value={params.optOutRatePercent}
                onChange={(e) => setParams({ ...params, optOutRatePercent: Number(e.target.value) })}
                className="w-full accent-purple-700"
              />
            </div>
          </div>
        </div>
      ) : (
        /* District Network Map View */
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            Hub & Spoke Tele-Ophthalmology Network (Indore District)
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* Central Hub Card */}
            <div className="p-4 rounded-2xl bg-purple-950 text-white space-y-2 border border-purple-800 md:col-span-2 lg:col-span-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-purple-400" />
                  <span className="font-bold text-sm">TERTIARY HUB: M.Y. Hospital, Indore (Retina Specialty OPD 4)</span>
                </div>
                <span className="text-[10px] font-mono bg-purple-900 px-2 py-0.5 rounded text-purple-200">
                  Central Node
                </span>
              </div>
              <div className="grid grid-cols-3 gap-4 pt-2 text-[11px] text-purple-200">
                <div>Specialist Weekly Capacity: <span className="font-bold text-white">{params.specialistWeeklySlots} Slots</span></div>
                <div>OCT & Anti-VEGF Facilities: <span className="font-bold text-emerald-400">Available</span></div>
                <div>Tele-Review Turnaround: <span className="font-bold text-white">&lt;120 mins SLA</span></div>
              </div>
            </div>

            {/* Peripheral PHC Nodes */}
            {phcCenters.map((phc) => (
              <div
                key={phc.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{phc.name}</span>
                  <span className="text-[10px] font-mono bg-slate-200 px-1.5 py-0.5 rounded">
                    {phc.distanceToHubKm} km
                  </span>
                </div>
                <div className="text-[11px] text-slate-600">
                  Cameras: <span className="font-bold text-purple-900">{phc.cameras.length} Active Units</span>
                </div>
                <div className="text-[11px] text-slate-600">
                  Daily Volume: <span className="font-bold text-slate-900">{phc.dailyScreened} / {phc.dailyTarget} Screened</span>
                </div>
                <div className="text-[10px] font-mono text-emerald-700 font-semibold pt-1 border-t border-slate-200">
                  Network: {phc.connectivity} ({phc.networkLatencyMs}ms)
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

