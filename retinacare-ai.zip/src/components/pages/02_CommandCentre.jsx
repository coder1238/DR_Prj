import React from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  Users,
  Eye,
  Activity,
  Calendar,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Camera,
  Layers,
  Send,
  Building2,
  Clock,
  ShieldCheck,
  TrendingUp,
  Cpu,
  ChevronRight
} from 'lucide-react';

export default function CommandCentre() {
  const {
    currentUser,
    currentPatient,
    districtMetrics,
    phcCenters,
    reviewQueue,
    setSelectedCase,
    navigateTo
  } = useRetinaCare();

  const urgentQueue = reviewQueue.filter((c) => c.priority === 'Urgent').slice(0, 3);

  const pipelineStages = [
    { num: '01', title: 'Patient Registration', sub: 'ABHA & Risk Profile', page: 3, icon: Users, color: 'border-purple-300 bg-purple-50 text-purple-900' },
    { num: '02', title: 'Capture Studio', sub: 'Real-time Auto-QC', page: 4, icon: Camera, color: 'border-indigo-300 bg-indigo-50 text-indigo-900' },
    { num: '03', title: 'Image Quality Lab', sub: 'CLAHE & Gradability', page: 5, icon: Layers, color: 'border-blue-300 bg-blue-50 text-blue-900' },
    { num: '04', title: 'AI Intelligence', sub: '15-Model Ensemble', page: 6, icon: Cpu, color: 'border-purple-300 bg-purple-50 text-purple-900' },
    { num: '05', title: 'Tele-Review & Referral', sub: 'Specialist Sign-off', page: 11, icon: Send, color: 'border-emerald-300 bg-emerald-50 text-emerald-900' }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-purple-900 to-slate-900 rounded-3xl p-6 lg:p-8 text-white shadow-xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute right-0 top-0 w-96 h-96 rounded-full bg-purple-600/10 blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono font-bold tracking-widest text-purple-300 uppercase px-2.5 py-0.5 rounded-full bg-purple-950 border border-purple-800">
                Central Tele-Ophthalmology Hub
              </span>
              <span className="text-xs text-purple-300">• Live PHC Stream</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-black tracking-tight text-white">
              Welcome back, {currentUser.name}
            </h1>
            <p className="text-xs text-purple-200/90 max-w-2xl leading-relaxed">
              District Retinal Intelligence Operations active across 5 Peripheral Health Centres & 18 Fundus Units. 14 urgent cases awaiting specialist review.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => navigateTo(10)}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 font-bold text-xs uppercase tracking-wider text-white shadow-lg shadow-purple-950 transition flex items-center gap-2 cursor-pointer"
            >
              <span>Open Review Queue (87)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => navigateTo(3)}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-bold text-xs text-white border border-slate-700 transition flex items-center gap-2 cursor-pointer"
            >
              <Users className="w-4 h-4 text-purple-400" />
              <span>Register New Patient</span>
            </button>
          </div>
        </div>
      </div>

      {/* 4-KPI District Screening Pulse */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Total Patients Screened</div>
            <div className="text-2xl font-black text-slate-900 mt-1">{districtMetrics.totalScreened.toLocaleString()}</div>
            <div className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1 mt-0.5">
              <span>↑ +165 Screened Today</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center border border-purple-100">
            <Users className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Referable DR Detected</div>
            <div className="text-2xl font-black text-rose-600 mt-1">{districtMetrics.referableCount.toLocaleString()}</div>
            <div className="text-[11px] text-rose-600 font-semibold flex items-center gap-1 mt-0.5">
              <span>8.1% District Prevalence</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Image Gradability Rate</div>
            <div className="text-2xl font-black text-emerald-600 mt-1">{districtMetrics.gradabilityRatePercent}%</div>
            <div className="text-[11px] text-slate-500 font-medium flex items-center gap-1 mt-0.5">
              <span>Across 18 Deployed Cameras</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-100">
            <Eye className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Avg Referral Transit</div>
            <div className="text-2xl font-black text-purple-700 mt-1">3.4 Days</div>
            <div className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1 mt-0.5">
              <span>↓ Down from 26 Days Baseline</span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center border border-indigo-100">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* 5-Stage Clinical Pipeline Navigation Stepper */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-600" />
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Primary Tele-Ophthalmology Screening Workflow
            </h2>
          </div>
          <span className="text-[11px] text-slate-500 font-medium">Click any stage to inspect</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-1">
          {pipelineStages.map((stage) => {
            const Icon = stage.icon;
            return (
              <button
                key={stage.num}
                onClick={() => navigateTo(stage.page)}
                className={`p-3.5 rounded-xl border text-left transition hover:shadow-md group cursor-pointer ${stage.color}`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-black">{stage.num}</span>
                  <Icon className="w-4 h-4 transition group-hover:scale-110" />
                </div>
                <div className="font-bold text-xs mt-2">{stage.title}</div>
                <div className="text-[10px] opacity-80 mt-0.5">{stage.sub}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Two Column Grid: Urgent Review Queue & PHC Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left (7 Cols): Urgent Priority Triage Cases */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping" />
              <h2 className="text-sm font-bold text-slate-900">Urgent Review Queue (High Risk)</h2>
            </div>
            <button
              onClick={() => navigateTo(10)}
              className="text-xs text-purple-700 font-bold hover:underline flex items-center gap-1"
            >
              <span>View All 87</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {urgentQueue.map((c) => (
              <div
                key={c.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-purple-300 hover:bg-purple-50/40 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 text-sm">{c.patientName}</span>
                    <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">
                      {c.patientId}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">
                      {c.priority}
                    </span>
                  </div>
                  <div className="text-slate-600 text-[11px]">
                    {c.age}y {c.gender} • <span className="font-medium text-slate-800">{c.phc}</span> • Camera: {c.camera.split(' ')[0]}
                  </div>
                  <div className="text-[11px] text-rose-700 font-medium">
                    AI Finding: {c.aiSeverity} (Conf: {(c.confidence * 100).toFixed(1)}%) • {c.flagReason}
                  </div>
                </div>

                <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 font-mono block">SLA: {c.elapsedMinutes}m / {c.slaMinutes}m</span>
                    <span className="text-[10px] text-amber-700 font-bold bg-amber-100 px-2 py-0.5 rounded">
                      {c.status}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedCase(c);
                      navigateTo(11); // Open in Workstation
                    }}
                    className="px-3 py-1.5 rounded-lg bg-purple-700 hover:bg-purple-600 text-white font-bold text-xs transition"
                  >
                    Open Case
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right (5 Cols): PHC Network Telemetry */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-purple-700" />
              <h2 className="text-sm font-bold text-slate-900">Peripheral Health Centre Network</h2>
            </div>
            <button
              onClick={() => navigateTo(14)}
              className="text-xs text-purple-700 font-bold hover:underline"
            >
              Simulink Map →
            </button>
          </div>

          <div className="space-y-2.5 text-xs">
            {phcCenters.map((phc) => (
              <div
                key={phc.id}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100/80 transition space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-slate-900">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    <span>{phc.name}</span>
                  </div>
                  <span className="font-mono text-[10px] bg-slate-200/80 px-1.5 py-0.5 rounded text-slate-700">
                    {phc.distanceToHubKm} km away
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-1 text-[11px] text-slate-600 pt-1">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Screened Today</span>
                    <span className="font-bold text-slate-900">{phc.dailyScreened} / {phc.dailyTarget}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Cameras Active</span>
                    <span className="font-bold text-purple-800">{phc.cameras.length} Units</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Latency</span>
                    <span className="font-mono font-bold text-emerald-700">{phc.networkLatencyMs}ms</span>
                  </div>
                </div>

                <div className="text-[10px] text-slate-500 flex items-center justify-between border-t border-slate-200/70 pt-1 font-mono">
                  <span>{phc.connectivity}</span>
                  <span className="text-emerald-700 font-semibold">{phc.syncStatus.split('(')[0]}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

