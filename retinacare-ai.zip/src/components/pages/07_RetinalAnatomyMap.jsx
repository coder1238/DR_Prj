import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import CircularFundusCanvas from '../common/CircularFundusCanvas';
import {
  Layers,
  Eye,
  Sliders,
  Ruler,
  Info,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sparkles,
  Maximize2
} from 'lucide-react';

export default function RetinalAnatomyMap() {
  const { currentPatient, navigateTo } = useRetinaCare();

  const [activeLayers, setActiveLayers] = useState({
    microaneurysms: true,
    hemorrhages: true,
    hardExudates: true,
    cottonWoolSpots: true,
    vessels: true,
    opticDisc: true,
    fovea: true,
    gradCam: false,
    calipers: true
  });

  const [selectedQuadrant, setSelectedQuadrant] = useState('ALL'); // 'ALL', 'ST', 'IT', 'SN', 'IN'

  const toggleLayer = (layerKey) => {
    setActiveLayers((prev) => ({
      ...prev,
      [layerKey]: !prev[layerKey]
    }));
  };

  const biomarkers = [
    { label: 'Microaneurysms', count: '38', unit: 'lesions', color: 'text-red-500', bg: 'bg-red-50', border: 'border-red-200' },
    { label: 'Hemorrhages (Blot/Flame)', count: '14', unit: 'lesions (1.84 mm²)', color: 'text-rose-700', bg: 'bg-rose-50', border: 'border-rose-200' },
    { label: 'Hard Exudates (Circinate)', count: '9', unit: 'clusters (2.15 mm²)', color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' },
    { label: 'Cotton Wool Spots', count: '3', unit: 'infarcts', color: 'text-slate-600', bg: 'bg-slate-100', border: 'border-slate-200' },
    { label: 'FAZ Diameter', count: '520', unit: 'µm (Threshold 500µm)', color: 'text-purple-700', bg: 'bg-purple-50', border: 'border-purple-200' },
    { label: 'Cup-to-Disc Ratio', count: '0.38', unit: 'CDR (Normal < 0.5)', color: 'text-emerald-700', bg: 'bg-emerald-50', border: 'border-emerald-200' }
  ];

  const layerControls = [
    { key: 'microaneurysms', label: 'Microaneurysms (38)', color: '#EF4444' },
    { key: 'hemorrhages', label: 'Hemorrhages (14)', color: '#991B1B' },
    { key: 'hardExudates', label: 'Hard Exudates (9)', color: '#FACC15' },
    { key: 'cottonWoolSpots', label: 'Cotton Wool Spots (3)', color: '#E2E8F0' },
    { key: 'vessels', label: 'Retinal Vessel Tree', color: '#DC2626' },
    { key: 'opticDisc', label: 'Optic Disc Boundary', color: '#F59E0B' },
    { key: 'fovea', label: 'Fovea & FAZ Contour', color: '#A855F7' },
    { key: 'calipers', label: 'Distance Calipers', color: '#06B6D4' }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 07 • Semantic Lesion Map
            </span>
            <span className="text-xs text-slate-500 font-medium">11 Anatomical & Pathological Toggles</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Retinal Anatomy & Lesion Distribution</h1>
          <p className="text-xs text-slate-600">
            Hover over lesions on the retinal canvas to view coordinates, confidence, and anatomical quadrant.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo(8)}
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-purple-900/20"
          >
            <span>DR Severity Studio</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 6 Biomarkers Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {biomarkers.map((b, i) => (
          <div
            key={i}
            className={`p-3 rounded-2xl border ${b.border} ${b.bg} space-y-1`}
          >
            <div className="text-[10px] font-bold text-slate-600 uppercase tracking-wide truncate">
              {b.label}
            </div>
            <div className={`text-xl font-black ${b.color}`}>{b.count}</div>
            <div className="text-[10px] text-slate-500 truncate">{b.unit}</div>
          </div>
        ))}
      </div>

      {/* Main Canvas + Layer Controls Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 8 Cols: Interactive Circular Canvas */}
        <div className="lg:col-span-8 bg-slate-900 rounded-3xl p-6 border border-slate-800 shadow-xl flex flex-col items-center justify-center">
          <CircularFundusCanvas
            activeLayers={activeLayers}
            size={500}
            interactive={true}
          />
        </div>

        {/* Right 4 Cols: Layer Controls & Quadrant Filter */}
        <div className="lg:col-span-4 space-y-4">
          {/* Layer Visibility Toggles */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-purple-700" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Anatomical Layers
                </h3>
              </div>
              <button
                onClick={() => {
                  const allOn = Object.values(activeLayers).every(Boolean);
                  const newState = {};
                  Object.keys(activeLayers).forEach((k) => (newState[k] = !allOn));
                  setActiveLayers(newState);
                }}
                className="text-[11px] text-purple-700 font-bold hover:underline"
              >
                Toggle All
              </button>
            </div>

            <div className="space-y-1.5 text-xs">
              {layerControls.map((layer) => {
                const isChecked = activeLayers[layer.key];
                return (
                  <button
                    key={layer.key}
                    onClick={() => toggleLayer(layer.key)}
                    className={`w-full flex items-center justify-between p-2 rounded-xl border transition ${
                      isChecked
                        ? 'bg-purple-50/60 border-purple-300 text-purple-950 font-semibold'
                        : 'bg-slate-50 border-slate-200 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: layer.color }}
                      />
                      <span className="text-[11px]">{layer.label}</span>
                    </div>
                    <span className="text-[10px] font-mono">
                      {isChecked ? 'VISIBLE' : 'HIDDEN'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quadrant Breakdown */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4 text-purple-700" />
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Quadrant Breakdown
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] font-bold text-slate-500 uppercase">Superior Temporal</div>
                <div className="font-bold text-slate-900 mt-0.5">14 MAs • 4 Hemorrhages</div>
                <div className="text-[10px] text-amber-700">Hard exudates near fovea</div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] font-bold text-slate-500 uppercase">Inferior Temporal</div>
                <div className="font-bold text-slate-900 mt-0.5">16 MAs • 6 Hemorrhages</div>
                <div className="text-[10px] text-rose-700">Blot hemorrhages clustered</div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] font-bold text-slate-500 uppercase">Superior Nasal</div>
                <div className="font-bold text-slate-900 mt-0.5">5 MAs • 2 Hemorrhages</div>
                <div className="text-[10px] text-slate-500">1 CWS near arcade</div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200">
                <div className="text-[10px] font-bold text-slate-500 uppercase">Inferior Nasal</div>
                <div className="font-bold text-slate-900 mt-0.5">3 MAs • 2 Hemorrhages</div>
                <div className="text-[10px] text-slate-500">Mild venular dilation</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

