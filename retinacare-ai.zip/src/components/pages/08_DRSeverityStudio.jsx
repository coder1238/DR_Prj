import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import SeverityWheel from '../common/SeverityWheel';
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Info,
  Stethoscope
} from 'lucide-react';

export default function DRSeverityStudio() {
  const { currentPatient, navigateTo, showToast } = useRetinaCare();

  const [selectedGrade, setSelectedGrade] = useState(2);
  const [overrideActive, setOverrideActive] = useState(false);

  const handleGradeSelect = (grade) => {
    setSelectedGrade(grade);
    setOverrideActive(grade !== 2);
    if (grade !== 2) {
      showToast('Grade Override Selected', `Clinician modified grade to Grade ${grade}. Decision audit log updated.`, 'info');
    }
  };

  const decisionRules = [
    { rule: 'Microaneurysms Present', status: true, detail: '38 detected (Criteria: >0 for Mild NPDR)' },
    { rule: 'Exudates / Hemorrhages', status: true, detail: 'Hard exudates encroaching within 500µm of fovea' },
    { rule: '4-2-1 Severe NPDR Rule', status: false, detail: 'Not fulfilled (Hemorrhages present in 2 quadrants, beading in 0)' },
    { rule: 'Neovascularization (NVD/NVE)', status: false, detail: 'Negative (No proliferative neovascular fronds)' },
    { rule: 'Diabetic Macular Edema (DME)', status: true, detail: 'High Risk (Score: 0.887) - Clinically Significant' }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 08 • Multi-Class Severity Inference
            </span>
            <span className="text-xs text-slate-500 font-medium">International Clinical DR Guidelines (ICDR)</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">DR Severity Studio & Referral Threshold</h1>
          <p className="text-xs text-slate-600">
            Case: <span className="font-bold text-slate-900">{currentPatient.name}</span> ({currentPatient.id})
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo(9)}
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-purple-900/20"
          >
            <span>Explainability Lab</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Severity Wheel vs Clinical Decision Rules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 6 Cols: Severity Wheel & Softmax */}
        <div className="lg:col-span-6">
          <SeverityWheel
            currentGrade={selectedGrade}
            confidence={selectedGrade === 2 ? 0.941 : 0.72}
            referable={selectedGrade >= 2}
            interactive={true}
            onSelectGrade={handleGradeSelect}
          />
        </div>

        {/* Right 6 Cols: Decision Rules & Tele-Triage Guidance */}
        <div className="lg:col-span-6 space-y-4">
          {/* Clinical Decision Rule Verification */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-purple-700" />
                <h3 className="text-sm font-bold text-slate-900">
                  International Clinical Diabetic Retinopathy (ICDR) Rule Check
                </h3>
              </div>
              <span className="text-[10px] font-mono bg-purple-50 text-purple-800 px-2 py-0.5 rounded border border-purple-200">
                Rule Engine v2.1
              </span>
            </div>

            <div className="space-y-2 text-xs">
              {decisionRules.map((r, i) => (
                <div
                  key={i}
                  className={`p-3 rounded-xl border flex items-start justify-between gap-3 ${
                    r.status
                      ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                      : 'bg-slate-50 border-slate-200 text-slate-600'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="font-bold text-slate-900">{r.rule}</div>
                    <div className="text-[11px] text-slate-600">{r.detail}</div>
                  </div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold flex-shrink-0 ${
                      r.status ? 'bg-amber-200 text-amber-900' : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {r.status ? 'TRIGGERED' : 'NEGATIVE'}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Clinician Action Recommendation */}
          <div className="bg-gradient-to-br from-purple-950 to-indigo-950 text-white rounded-2xl p-5 border border-purple-800 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-xs text-purple-300 uppercase tracking-wider">
                <Stethoscope className="w-4 h-4 text-purple-400" />
                <span>Tele-Ophthalmology Action Plan</span>
              </div>
              <span className="text-[10px] font-bold bg-rose-600 text-white px-2 py-0.5 rounded">
                Referral Urgency: 72 Hours
              </span>
            </div>

            <p className="text-xs text-purple-100 leading-relaxed">
              Patient exhibits <span className="font-bold text-amber-300">Grade 2 Moderate NPDR</span> with imminent macular threat. Under National Health Mission protocol, tele-ophthalmologist review is mandated within 120 minutes of capture.
            </p>

            <div className="flex items-center justify-between pt-2 border-t border-purple-800/80">
              <span className="text-[11px] text-purple-300">Fast-track slot at M.Y. Hospital Hub</span>
              <button
                onClick={() => navigateTo(11)}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 font-bold text-xs uppercase tracking-wider text-white transition flex items-center gap-1.5"
              >
                <span>Launch Tele-Review</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

