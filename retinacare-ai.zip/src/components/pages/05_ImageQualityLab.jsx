import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  SlidersHorizontal,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Eye,
  ShieldCheck,
  SplitSquareVertical
} from 'lucide-react';

export default function ImageQualityLab() {
  const { currentPatient, navigateTo, showToast } = useRetinaCare();

  const [sliderPos, setSliderPos] = useState(50); // 0 to 100
  const [activeTab, setActiveTab] = useState('split'); // 'split', 'raw', 'clahe'
  const [claheStrength, setClaheStrength] = useState(2.4);

  const qualityStages = [
    {
      id: 1,
      name: 'Illumination Uniformity',
      score: 92,
      status: 'Pass',
      metric: 'SNR 24.2 dB',
      desc: 'Uniform illumination across posterior pole. Vignetting < 8%.'
    },
    {
      id: 2,
      name: 'Sharpness & Microvascular Contrast',
      score: 89,
      status: 'Pass',
      metric: 'Tenengrad Gradient 142.1',
      desc: 'Capillary detail visible up to 4th order arteriolar bifurcation.'
    },
    {
      id: 3,
      name: 'Anatomical Field Coverage',
      score: 98,
      status: 'Pass',
      metric: '45° Non-Mydriatic',
      desc: 'Optic Disc positioned >2 disc diameters from temporal border; Macula centered.'
    },
    {
      id: 4,
      name: 'Media Opacities & Lens Glare',
      score: 86,
      status: 'Mild Haze',
      metric: 'Scatter Index 0.12',
      desc: 'Mild nuclear sclerotic cataract scatter in nasal periphery; posterior pole unaffected.'
    },
    {
      id: 5,
      name: 'Motion Blur & Artifacts',
      score: 94,
      status: 'Pass',
      metric: 'PSNR 38.6 dB',
      desc: 'No saccadic motion smear or eyelash shadowing.'
    }
  ];

  const handleApprove = () => {
    showToast('Quality Approved', 'Image classified as Gradable (91%). Triggering 15-model AI ensemble.', 'success');
    navigateTo(6); // Advance to AI Analysis Centre
  };

  const handleRecapture = () => {
    showToast('Recapture Requested', 'Returning to Capture Studio with illumination guidance.', 'warning');
    navigateTo(4);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 05 • Automated Preprocessing & QC
            </span>
            <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Diagnostic Quality: Gradable (Grade A)</span>
            </span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Image Quality & CLAHE Lab</h1>
          <p className="text-xs text-slate-600">
            Automated image quality assessment and contrast-limited adaptive histogram equalization.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRecapture}
            className="px-4 py-2 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold transition flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Recapture Scan</span>
          </button>
          <button
            onClick={handleApprove}
            className="px-5 py-2 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 shadow-lg shadow-purple-900/30"
          >
            <span>Run 15 AI Models</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Grid: Split Slider vs Quality Pipeline */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Cols: Interactive Before / After Split Slider */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-6 border border-slate-800 shadow-xl flex flex-col items-center justify-center space-y-4">
          <div className="w-full flex items-center justify-between text-xs text-slate-400 px-2">
            <span className="font-bold text-amber-400">Raw Capture (Left)</span>
            <span className="text-[11px] font-mono">Drag slider to compare CLAHE enhancement</span>
            <span className="font-bold text-purple-400">CLAHE Processed (Right)</span>
          </div>

          {/* Interactive Split Viewport */}
          <div className="relative w-[360px] h-[360px] sm:w-[420px] sm:h-[420px] rounded-full overflow-hidden border-2 border-purple-500/40 shadow-2xl bg-black select-none">
            {/* Base Image: CLAHE Enhanced (Right side) */}
            <div className="absolute inset-0 flex items-center justify-center bg-radial from-amber-950 via-slate-950 to-black">
              <svg viewBox="0 0 400 400" className="w-full h-full">
                <circle cx="200" cy="200" r="198" fill="#3B0C02" />
                {/* Crisp Optic Disc */}
                <circle cx="130" cy="200" r="34" fill="#FBBF24" stroke="#FDE68A" strokeWidth="2" />
                <ellipse cx="128" cy="198" rx="14" ry="16" fill="#FFFBEB" />
                {/* Sharpened Macula */}
                <circle cx="270" cy="200" r="22" fill="#140200" stroke="#C084FC" strokeWidth="1.2" strokeDasharray="3 3" />
                {/* High contrast vessels */}
                <path d="M 130 190 Q 180 110 290 80" fill="none" stroke="#DC2626" strokeWidth="3.5" />
                <path d="M 130 210 Q 180 290 290 320" fill="none" stroke="#DC2626" strokeWidth="3.5" />
                <path d="M 130 195 Q 185 130 280 110" fill="none" stroke="#881337" strokeWidth="4.2" />
                <path d="M 130 205 Q 185 270 280 290" fill="none" stroke="#881337" strokeWidth="4.2" />
                {/* Hard exudates crisply revealed */}
                <circle cx="250" cy="190" r="4.5" fill="#FACC15" />
                <circle cx="260" cy="180" r="5" fill="#FACC15" />
                <circle cx="275" cy="182" r="4" fill="#FACC15" />
                <circle cx="285" cy="195" r="5.5" fill="#FACC15" />
              </svg>
            </div>

            {/* Overlaid Clip: Raw Image (Left side) */}
            <div
              className="absolute inset-0 overflow-hidden"
              style={{ width: `${sliderPos}%` }}
            >
              <div className="absolute inset-0 w-[360px] h-[360px] sm:w-[420px] sm:h-[420px] flex items-center justify-center bg-radial from-amber-950/70 via-slate-950 to-black opacity-80 filter brightness-90 contrast-90">
                <svg viewBox="0 0 400 400" className="w-full h-full">
                  <circle cx="200" cy="200" r="198" fill="#2E0A03" />
                  {/* Softer Disc */}
                  <circle cx="130" cy="200" r="34" fill="#D97706" opacity="0.8" />
                  {/* Faint Macula */}
                  <circle cx="270" cy="200" r="22" fill="#1C0501" opacity="0.6" />
                  {/* Softer vessels */}
                  <path d="M 130 190 Q 180 110 290 80" fill="none" stroke="#991B1B" strokeWidth="2.8" opacity="0.7" />
                  <path d="M 130 210 Q 180 290 290 320" fill="none" stroke="#991B1B" strokeWidth="2.8" opacity="0.7" />
                </svg>
              </div>
            </div>

            {/* Divider Line & Handle */}
            <div
              className="absolute top-0 bottom-0 w-1 bg-white shadow-lg pointer-events-none"
              style={{ left: `${sliderPos}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-7 rounded-full bg-purple-600 text-white flex items-center justify-center shadow-md border-2 border-white">
                <SplitSquareVertical className="w-3.5 h-3.5" />
              </div>
            </div>
          </div>

          {/* Interactive Range Slider */}
          <div className="w-full max-w-md px-4 space-y-1">
            <input
              type="range"
              min="0"
              max="100"
              value={sliderPos}
              onChange={(e) => setSliderPos(Number(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
            <div className="flex justify-between text-[11px] font-mono text-slate-400">
              <span>0% Raw Capture</span>
              <span className="text-purple-300 font-bold">{sliderPos}% Split</span>
              <span>100% Processed</span>
            </div>
          </div>
        </div>

        {/* Right 5 Cols: Automated Quality Pipeline Checklist */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div>
              <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                Automated Quality Assessment
              </div>
              <h3 className="text-lg font-bold text-slate-900">5-Stage QC Pipeline</h3>
            </div>
            <div className="text-right">
              <span className="text-2xl font-black text-emerald-600">91%</span>
              <span className="text-[10px] text-slate-500 block">Gradability Index</span>
            </div>
          </div>

          <div className="space-y-3">
            {qualityStages.map((stg) => (
              <div
                key={stg.id}
                className="p-3 rounded-xl border border-slate-200 bg-slate-50/60 hover:bg-slate-100/80 transition space-y-1 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">
                    {stg.id}. {stg.name}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      stg.status === 'Pass'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {stg.status} ({stg.score}%)
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 font-mono">{stg.metric}</div>
                <div className="text-[11px] text-slate-600 leading-snug">{stg.desc}</div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-purple-50 border border-purple-200 rounded-xl text-[11px] text-purple-900 leading-relaxed">
            <span className="font-bold">Quality Conclusion: </span>
            The retinal image meets NHS England & CDSCO non-mydriatic screening adequacy requirements. Both Optic Disc and Macula are sharply resolved for lesion quantification.
          </div>
        </div>
      </div>
    </div>
  );
}

