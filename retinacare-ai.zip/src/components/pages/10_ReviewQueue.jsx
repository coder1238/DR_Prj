import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  Inbox,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Filter,
  Search,
  ArrowRight,
  Eye,
  Camera,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

export default function ReviewQueue() {
  const {
    reviewQueue,
    setSelectedCase,
    navigateTo,
    queueStats
  } = useRetinaCare();

  const [activeFilter, setActiveFilter] = useState('all'); // 'all', 'urgent', 'referable', 'low-confidence', 'disagreements', 'recaptures'
  const [searchQuery, setSearchQuery] = useState('');

  const filterBuckets = [
    { id: 'all', label: "Today's Queue", count: 87, color: 'bg-purple-100 text-purple-800' },
    { id: 'urgent', label: 'Urgent High-Risk', count: 14, color: 'bg-rose-100 text-rose-800' },
    { id: 'referable', label: 'Referable DR', count: 28, color: 'bg-orange-100 text-orange-800' },
    { id: 'low-confidence', label: 'Low AI Confidence', count: 12, color: 'bg-amber-100 text-amber-800' },
    { id: 'disagreements', label: 'Model Splits', count: 9, color: 'bg-indigo-100 text-indigo-800' },
    { id: 'recaptures', label: 'Recaptures Needed', count: 11, color: 'bg-slate-200 text-slate-800' }
  ];

  const filteredCases = reviewQueue.filter((c) => {
    const matchesFilter =
      activeFilter === 'all' ||
      (c.category && c.category.includes(activeFilter)) ||
      (activeFilter === 'urgent' && c.priority === 'Urgent');

    const matchesSearch =
      c.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.patientId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phc.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesFilter && matchesSearch;
  });

  const handleOpenCase = (c) => {
    setSelectedCase(c);
    navigateTo(11); // Advance to Specialist Workstation
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 10 • Tele-Ophthalmology Triage
            </span>
            <span className="text-xs text-slate-500 font-medium">SLA Turnaround Guarantee: &lt;120 Minutes</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Specialist Review & Triage Queue</h1>
          <p className="text-xs text-slate-600">
            Assigned to: <span className="font-bold text-purple-950">Dr. Ananya Sharma</span> • Tele-Review Lead (M.Y. Hospital Hub)
          </p>
        </div>

        {/* SLA Stats Pill */}
        <div className="flex items-center gap-3">
          <div className="p-3 bg-purple-50 border border-purple-200 rounded-xl text-xs text-right">
            <div className="text-[10px] font-bold text-slate-500 uppercase">Average Review Latency</div>
            <div className="font-black text-purple-900 text-base">{queueStats.avgTurnaroundMinutes} mins</div>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Filter queue by patient name, ID, or PHC clinic..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-xs focus:outline-none focus:border-purple-600"
          />
        </div>

        {/* Filter Buckets */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {filterBuckets.map((bucket) => {
            const isActive = activeFilter === bucket.id;
            return (
              <button
                key={bucket.id}
                onClick={() => setActiveFilter(bucket.id)}
                className={`px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-2 ${
                  isActive
                    ? 'bg-purple-700 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                <span>{bucket.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                    isActive ? 'bg-purple-900 text-purple-200' : bucket.color
                  }`}
                >
                  {bucket.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Cases List */}
      <div className="space-y-3">
        {filteredCases.map((c) => (
          <div
            key={c.id}
            className="bg-white rounded-2xl p-5 border border-slate-200 hover:border-purple-300 hover:shadow-md transition flex flex-col md:flex-row md:items-center justify-between gap-4"
          >
            {/* Left: Patient and PHC info */}
            <div className="space-y-2 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-slate-900 text-sm">{c.patientName}</span>
                <span className="font-mono text-[11px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded">
                  {c.patientId}
                </span>
                <span className="font-mono text-[11px] text-slate-500">
                  ABHA: {c.abhaId}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    c.priority === 'Urgent'
                      ? 'bg-rose-100 text-rose-800'
                      : c.priority === 'Disagreements'
                      ? 'bg-indigo-100 text-indigo-800'
                      : c.priority === 'Low Confidence'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-slate-100 text-slate-800'
                  }`}
                >
                  {c.priority}
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600">
                <span>{c.age} Yrs / {c.gender}</span>
                <span>•</span>
                <span className="font-semibold text-purple-950">{c.phc}</span>
                <span>•</span>
                <span className="font-mono text-[11px] text-slate-500">Camera: {c.camera}</span>
                <span>•</span>
                <span className="text-slate-400">{c.capturedAt}</span>
              </div>

              <div className="p-2.5 rounded-xl bg-purple-50/60 border border-purple-100 text-xs text-purple-950 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-purple-700 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">AI Diagnosis: {c.aiSeverity} </span>
                  <span className="font-mono font-bold text-purple-800">(Conf: {(c.confidence * 100).toFixed(1)}%)</span>
                  <span className="text-slate-600"> — {c.flagReason}</span>
                </div>
              </div>
            </div>

            {/* Right: SLA timer & Open Action */}
            <div className="flex md:flex-col items-center md:items-end justify-between gap-3 border-t md:border-t-0 pt-3 md:pt-0 border-slate-100">
              <div className="text-right">
                <div className="text-[10px] font-mono text-slate-400">
                  Elapsed: <span className="font-bold text-slate-700">{c.elapsedMinutes}m</span> / {c.slaMinutes}m
                </div>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded inline-block mt-0.5 ${
                    c.slaStatus === 'breached'
                      ? 'bg-rose-100 text-rose-800'
                      : c.slaStatus === 'warning'
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {c.status}
                </span>
              </div>

              <button
                onClick={() => handleOpenCase(c)}
                className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold text-xs uppercase tracking-wider transition flex items-center gap-1.5 shadow-sm shadow-purple-900/30"
              >
                <span>Launch Workstation</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

