import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  Cpu,
  Sparkles,
  Layers,
  Activity,
  ArrowRight,
  CheckCircle2,
  Play,
  Clock,
  ShieldCheck,
  Zap,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

export default function AIAnalysisCentre() {
  const { aiClusterModels, navigateTo, showToast } = useRetinaCare();

  const [isRunning, setIsRunning] = useState(false);
  const [completedClusters, setCompletedClusters] = useState([1, 2, 3, 4, 5, 6]);
  const [expandedCluster, setExpandedCluster] = useState(3); // Cluster 3 (Severity) open by default

  const handleRunAll = () => {
    setIsRunning(true);
    setCompletedClusters([]);

    // Staggered simulation
    [1, 2, 3, 4, 5, 6].forEach((cId, idx) => {
      setTimeout(() => {
        setCompletedClusters((prev) => [...prev, cId]);
        if (idx === 5) {
          setIsRunning(false);
          showToast('15-Model Ensemble Complete', 'Total latency 84.6ms. ICDR Grade 2 Moderate NPDR confirmed.', 'success');
        }
      }, (idx + 1) * 350);
    });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 06 • Deep Learning Inference Engine
            </span>
            <span className="text-xs text-slate-500 font-medium">15 Models in 6 Functional Clusters</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mt-1">AI Analysis Command Centre</h1>
          <p className="text-xs text-slate-600 mt-0.5">
            Real-time multi-task deep neural network ensemble executing on edge TensorRT runtime.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={handleRunAll}
            disabled={isRunning}
            className="px-5 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 disabled:bg-purple-400 text-white text-xs font-bold uppercase tracking-wider transition flex items-center gap-2 shadow-lg shadow-purple-900/30"
          >
            {isRunning ? (
              <>
                <Zap className="w-4 h-4 animate-spin text-purple-200" />
                <span>Running Inference (84ms)...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                <span>Re-Execute Ensemble</span>
              </>
            )}
          </button>

          <button
            onClick={() => navigateTo(7)}
            className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition flex items-center gap-1.5"
          >
            <span>View Lesion Map</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Cluster Cards List */}
      <div className="space-y-4">
        {aiClusterModels.map((cluster) => {
          const isDone = completedClusters.includes(cluster.clusterId);
          const isExpanded = expandedCluster === cluster.clusterId;

          return (
            <div
              key={cluster.clusterId}
              className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs transition"
            >
              {/* Cluster Header */}
              <div
                onClick={() => setExpandedCluster(isExpanded ? null : cluster.clusterId)}
                className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50/80 transition"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-800 font-bold text-xs flex items-center justify-center border border-purple-200">
                    C{cluster.clusterId}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-slate-900">{cluster.clusterName}</h3>
                      <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                        {cluster.models.length} Models
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500">{cluster.purpose}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-[11px] font-mono text-slate-500">
                    Latency: ~{cluster.models.reduce((acc, m) => acc + parseInt(m.latencyMs), 0)}ms
                  </span>
                  {isDone ? (
                    <span className="flex items-center gap-1 text-[11px] text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      Executed
                    </span>
                  ) : (
                    <span className="text-[11px] text-amber-700 font-bold bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                      Pending
                    </span>
                  )}
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                </div>
              </div>

              {/* Models inside this cluster */}
              {isExpanded && (
                <div className="p-4 bg-slate-50/60 border-t border-slate-200 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  {cluster.models.map((m) => (
                    <div
                      key={m.id}
                      className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-[10px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded border border-purple-200">
                          {m.id}
                        </span>
                        <span className="text-[10px] font-mono text-slate-400">
                          {m.latencyMs}
                        </span>
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 text-xs">{m.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">{m.arch}</div>
                      </div>

                      <div className="pt-1 border-t border-slate-100 space-y-1 text-[11px]">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Output:</span>
                          <span className="font-bold text-purple-950 truncate max-w-[150px]" title={m.output}>
                            {m.output}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Confidence:</span>
                          <span className="font-mono font-bold text-emerald-700">
                            {(m.confidence * 100).toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Quick Jump Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 bg-white rounded-2xl border border-slate-200 text-xs">
        <div className="text-slate-600">
          <span className="font-bold text-slate-900">Ensemble Summary: </span>
          ICDR Grade 2 (Confidence: 94.1%) • Clinically Significant DME Detected (88.7%)
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigateTo(7)}
            className="px-3 py-1.5 rounded-lg bg-purple-50 text-purple-800 font-bold border border-purple-200 hover:bg-purple-100 transition"
          >
            07: Anatomy & Lesions →
          </button>
          <button
            onClick={() => navigateTo(8)}
            className="px-3 py-1.5 rounded-lg bg-purple-50 text-purple-800 font-bold border border-purple-200 hover:bg-purple-100 transition"
          >
            08: Severity Studio →
          </button>
          <button
            onClick={() => navigateTo(9)}
            className="px-3 py-1.5 rounded-lg bg-purple-50 text-purple-800 font-bold border border-purple-200 hover:bg-purple-100 transition"
          >
            09: Explainability Lab →
          </button>
        </div>
      </div>
    </div>
  );
}

