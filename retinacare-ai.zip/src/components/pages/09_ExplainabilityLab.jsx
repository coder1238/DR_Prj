import React, { useState } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import CircularFundusCanvas from '../common/CircularFundusCanvas';
import CalibrationGraph from '../common/CalibrationGraph';
import {
  Sparkles,
  Layers,
  Sliders,
  Eye,
  CheckCircle2,
  TrendingUp,
  Activity,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';

export default function ExplainabilityLab() {
  const { currentPatient, navigateTo } = useRetinaCare();

  const [activeTab, setActiveTab] = useState('gradcam'); // 'gradcam', 'intgrad', 'vit', 'lesions', 'calibration'
  const [gradCamOpacity, setGradCamOpacity] = useState(65);

  const rankedEvidence = [
    {
      rank: 1,
      finding: 'Circinate Hard Exudate Ring in Perimacular Region',
      weight: '42.4%',
      barWidth: '42%',
      impact: 'Primary driver of DME risk (0.887) and Moderate NPDR classification.',
      quadrant: 'ST / Perimacular',
      confidence: '98.1%'
    },
    {
      rank: 2,
      finding: '14 Deep Blot Hemorrhages in Inferior Temporal Arcade',
      weight: '28.1%',
      barWidth: '28%',
      impact: 'Indicates widespread capillary bed rupture and pericyte loss.',
      quadrant: 'Inferior Temporal',
      confidence: '96.8%'
    },
    {
      rank: 3,
      finding: '38 Microaneurysms Clustered in Paramacular Zone',
      weight: '18.6%',
      barWidth: '19%',
      impact: 'Establishes microvascular decompensation exceeding Mild NPDR threshold.',
      quadrant: 'ST & IT',
      confidence: '95.4%'
    },
    {
      rank: 4,
      finding: '3 Cotton Wool Spots (Precapillary Arteriolar Infarctions)',
      weight: '10.9%',
      barWidth: '11%',
      impact: 'Local retinal ischemia in nerve fiber layer near superior arcade.',
      quadrant: 'SN Arcade',
      confidence: '93.5%'
    }
  ];

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2.5 py-0.5 rounded border border-purple-200">
              Module 09 • Transparent Explainable AI (XAI)
            </span>
            <span className="text-xs text-slate-500 font-medium">Post-Hoc Attribution & Calibration</span>
          </div>
          <h1 className="text-xl font-bold text-slate-900 mt-1">Explainability & Evidence Lab</h1>
          <p className="text-xs text-slate-600">
            Unpacking the deep neural network decision boundary with multi-modal attribution techniques.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo(10)}
            className="px-4 py-2.5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-md shadow-purple-900/20"
          >
            <span>Ophthalmologist Queue</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 5 Modality Tabs */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-xs">
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
          {[
            { id: 'gradcam', label: '1. Grad-CAM Saliency' },
            { id: 'intgrad', label: '2. Integrated Gradients' },
            { id: 'vit', label: '3. ViT Attention Rollout' },
            { id: 'lesions', label: '4. Ranked Evidence Stack' },
            { id: 'calibration', label: '5. ECE Reliability Curve' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`py-2 px-3 rounded-xl font-bold transition text-center ${
                activeTab === tab.id
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Modality View Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 Cols: Canvas or Curve */}
        <div className="lg:col-span-7 bg-slate-950 rounded-3xl p-6 border border-slate-800 shadow-xl flex flex-col items-center justify-center space-y-4 min-h-[500px]">
          {activeTab === 'calibration' ? (
            <div className="w-full">
              <CalibrationGraph />
            </div>
          ) : (
            <>
              {/* Circular Fundus Canvas with Grad-CAM active */}
              <CircularFundusCanvas
                activeLayers={{
                  microaneurysms: true,
                  hemorrhages: true,
                  hardExudates: true,
                  cottonWoolSpots: true,
                  vessels: true,
                  opticDisc: true,
                  fovea: true,
                  gradCam: activeTab === 'gradcam' || activeTab === 'intgrad' || activeTab === 'vit',
                  calipers: true
                }}
                gradCamOpacity={gradCamOpacity}
                size={460}
                interactive={true}
              />

              {/* Opacity Slider for Grad-CAM overlay */}
              <div className="w-full max-w-md px-4 space-y-1">
                <div className="flex justify-between text-xs text-slate-300 font-semibold">
                  <span>Attribution Heatmap Opacity</span>
                  <span className="font-mono text-purple-400">{gradCamOpacity}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={gradCamOpacity}
                  onChange={(e) => setGradCamOpacity(Number(e.target.value))}
                  className="w-full accent-purple-500 cursor-pointer"
                />
              </div>
            </>
          )}
        </div>

        {/* Right 5 Cols: Ranked Evidence Stack & Explanations */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
            <div className="border-b border-slate-200 pb-3">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                Feature Attribution Ranking
              </span>
              <h3 className="text-base font-bold text-slate-900 mt-0.5">
                Top Retinal Features Influencing Grade 2
              </h3>
            </div>

            <div className="space-y-3">
              {rankedEvidence.map((ev) => (
                <div
                  key={ev.rank}
                  className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">
                      #{ev.rank} {ev.finding}
                    </span>
                    <span className="font-mono font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded text-[11px]">
                      {ev.weight}
                    </span>
                  </div>

                  {/* Horizontal Bar */}
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div
                      className="bg-purple-600 h-full rounded-full"
                      style={{ width: ev.barWidth }}
                    />
                  </div>

                  <div className="text-[11px] text-slate-600 leading-snug">{ev.impact}</div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-200/60 font-mono">
                    <span>Region: {ev.quadrant}</span>
                    <span className="text-emerald-700 font-semibold">Conf: {ev.confidence}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="p-4 bg-purple-50 border border-purple-200 rounded-2xl text-xs text-purple-900 space-y-1">
            <div className="font-bold flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-purple-700" />
              <span>Ophthalmologist Clinical Assurance</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Model heatmap focuses predominantly on actual microvascular pathology (hard exudate circinate ring and blot hemorrhages) rather than confounding optic nerve artifacts or vessel crossings.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

