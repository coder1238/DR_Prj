import React, { useState, useEffect } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  Search,
  Eye,
  User,
  Layers,
  Activity,
  Send,
  SlidersHorizontal,
  Stethoscope,
  X,
  ArrowRight,
  TrendingUp,
  Boxes,
  Camera,
  UserPlus
} from 'lucide-react';

export default function CommandPaletteModal() {
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    navigateTo,
    patients,
    setCurrentPatient,
    showToast,
    toggleOffline
  } = useRetinaCare();

  const [searchQuery, setSearchQuery] = useState('');

  if (!commandPaletteOpen) return null;

  const screens = [
    { id: 1, title: 'Screen 01: Clinical Login & Role Auth', group: 'Navigation' },
    { id: 2, title: 'Screen 02: Clinical Command Centre & PHC Map', group: 'Navigation' },
    { id: 3, title: 'Screen 03: Patient Registration & ABHA Integration', group: 'Navigation' },
    { id: 4, title: 'Screen 04: Retinal Capture Studio & Live Auto-QC', group: 'Navigation' },
    { id: 5, title: 'Screen 05: Image Quality Lab & Gradability', group: 'Navigation' },
    { id: 6, title: 'Screen 06: AI Analysis Engine & 15-Model Ensemble', group: 'Navigation' },
    { id: 7, title: 'Screen 07: Retinal Anatomy & 11-Layer Lesion Map', group: 'Navigation' },
    { id: 8, title: 'Screen 08: DR Severity Studio & 5-Grade Radial Dial', group: 'Navigation' },
    { id: 9, title: 'Screen 09: Explainability & Evidence Lab (Grad-CAM)', group: 'Navigation' },
    { id: 10, title: 'Screen 10: Ophthalmologist Review Queue (87 Cases)', group: 'Navigation' },
    { id: 11, title: 'Screen 11: Specialist Review & Validation Workstation', group: 'Navigation' },
    { id: 12, title: 'Screen 12: Referral Command & ABDM Dispatch', group: 'Navigation' },
    { id: 13, title: 'Screen 13: Longitudinal Retinal Journey & Timeline', group: 'Navigation' },
    { id: 14, title: 'Screen 14: District Intelligence & Simulink Surge', group: 'Navigation' },
    { id: 15, title: 'Screen 15: AI Model Registry, ECE Calibration & Datasets', group: 'Navigation' }
  ];

  const quickActions = [
    {
      title: 'Register New Patient Profile (ABHA Scan)',
      action: () => navigateTo(3),
      icon: UserPlus
    },
    {
      title: 'Launch Live Fundus Camera Capture',
      action: () => navigateTo(4),
      icon: Camera
    },
    {
      title: 'Open Urgent Ophthalmologist Review Queue',
      action: () => navigateTo(10),
      icon: Stethoscope
    },
    {
      title: 'Toggle Offline / Synchronized Tele-Mode',
      action: () => toggleOffline(),
      icon: SlidersHorizontal
    },
    {
      title: 'Simulate District Referral Surge (Simulink)',
      action: () => navigateTo(14),
      icon: TrendingUp
    }
  ];

  const filteredScreens = screens.filter((s) =>
    s.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredPatients = patients.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.abhaId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSelectPatient = (patient) => {
    setCurrentPatient(patient);
    setCommandPaletteOpen(false);
    showToast('Patient Selected', `Switched active clinical context to ${patient.name}`, 'info');
    navigateTo(7); // Jump to Retinal Anatomy Map
  };

  const handleNavigate = (pageId) => {
    setCommandPaletteOpen(false);
    navigateTo(pageId);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-start justify-center pt-20 p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3 bg-slate-50">
          <Search className="w-5 h-5 text-purple-600 flex-shrink-0" />
          <input
            type="text"
            autoFocus
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Type a screen number, patient name, ABHA ID, or action..."
            className="w-full bg-transparent border-none text-slate-800 placeholder-slate-400 text-sm focus:outline-none"
          />
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="p-1 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="overflow-y-auto p-3 space-y-4 text-xs">
          {/* Patients match */}
          {filteredPatients.length > 0 && (
            <div>
              <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Patients in Local Database
              </div>
              <div className="space-y-1 mt-1">
                {filteredPatients.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleSelectPatient(p)}
                    className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-purple-50 text-left border border-transparent hover:border-purple-200 transition"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-purple-100 text-purple-800 font-bold flex items-center justify-center">
                        {p.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-bold text-slate-800">{p.name}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {p.id} • ABHA: {p.abhaId} • {p.age}y {p.gender}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 font-semibold">
                      {p.confirmedDiagnosis}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quick actions */}
          {searchQuery === '' && (
            <div>
              <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Quick Clinical Actions
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1">
                {quickActions.map((qa, i) => {
                  const Icon = qa.icon;
                  return (
                    <button
                      key={i}
                      onClick={() => {
                        setCommandPaletteOpen(false);
                        qa.action();
                      }}
                      className="flex items-center gap-2.5 p-2 rounded-lg bg-slate-50 hover:bg-purple-50 hover:border-purple-200 border border-slate-200 text-left transition"
                    >
                      <Icon className="w-4 h-4 text-purple-600 flex-shrink-0" />
                      <span className="text-slate-700 font-medium text-[11px] truncate">
                        {qa.title}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Screens match */}
          <div>
            <div className="px-2 py-1 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              System Screens (15 Interactive Modules)
            </div>
            <div className="space-y-1 mt-1">
              {filteredScreens.map((s) => (
                <button
                  key={s.id}
                  onClick={() => handleNavigate(s.id)}
                  className="w-full flex items-center justify-between p-2 rounded-lg hover:bg-slate-100 text-left border border-transparent hover:border-slate-200 transition"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded bg-slate-100 text-slate-700 font-mono font-bold text-[11px] flex items-center justify-center">
                      {s.id < 10 ? `0${s.id}` : s.id}
                    </span>
                    <span className="font-semibold text-slate-700">{s.title}</span>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span>Press ESC to close</span>
          <span className="font-medium text-purple-700">RetinaCare AI • Smart DR Clinical Support</span>
        </div>
      </div>
    </div>
  );
}

