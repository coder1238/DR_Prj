import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  Eye,
  LayoutDashboard,
  UserPlus,
  Camera,
  SlidersHorizontal,
  Cpu,
  Layers,
  Activity,
  Sparkles,
  Inbox,
  Stethoscope,
  Send,
  History,
  TrendingUp,
  Boxes,
  WifiOff,
  Wifi,
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  Search,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';

export default function NavigationRail() {
  const location = useLocation();
  const {
    activePage,
    navigateTo,
    currentUser,
    offlineMode,
    toggleOffline,
    setCommandPaletteOpen,
    reviewQueue,
    referrals
  } = useRetinaCare();

  const [isCollapsed, setIsCollapsed] = useState(false);

  const urgentQueueCount = reviewQueue.filter((c) => c.priority === 'Urgent').length;
  const activeReferralCount = referrals.filter((r) => r.status !== 'completed').length;

  const navSections = [
    {
      title: 'PRIMARY PIPELINE',
      items: [
        { id: 1, path: '/login', label: 'Clinical Login', icon: ShieldCheck, num: '01', desc: 'Secure Auth & Facility' },
        { id: 2, path: '/command-centre', label: 'Command Centre', icon: LayoutDashboard, num: '02', desc: 'Screening Pulse & PHCs' },
        { id: 3, path: '/registration', label: 'Patient Registration', icon: UserPlus, num: '03', desc: 'ABHA & Metabolic Profile' },
        { id: 4, path: '/capture-studio', label: 'Retinal Capture Studio', icon: Camera, num: '04', desc: 'Live View & Auto-QC' },
        { id: 5, path: '/quality-lab', label: 'Image Quality Lab', icon: SlidersHorizontal, num: '05', desc: 'Gradability & Clahe' }
      ]
    },
    {
      title: 'DIAGNOSTIC INTELLIGENCE',
      items: [
        { id: 6, path: '/ai-analysis', label: 'AI Analysis Centre', icon: Cpu, num: '06', desc: '15 Models Live Ensemble' },
        { id: 7, path: '/anatomy-map', label: 'Retinal Anatomy Map', icon: Layers, num: '07', desc: '11-Layer Lesion Calipers' },
        { id: 8, path: '/severity-studio', label: 'DR Severity Studio', icon: Activity, num: '08', desc: 'ICDR 5-Grade Radial Dial' },
        { id: 9, path: '/explainability-lab', label: 'Explainability Lab', icon: Sparkles, num: '09', desc: 'Grad-CAM & ECE Curves' }
      ]
    },
    {
      title: 'TELE-MEDICINE & CARE',
      items: [
        { id: 10, path: '/review-queue', label: 'Review Queue', icon: Inbox, num: '10', desc: '87 Triage Cases', badge: urgentQueueCount, badgeColor: 'bg-rose-500' },
        { id: 11, path: '/review-workstation', label: 'Review Workstation', icon: Stethoscope, num: '11', desc: 'Doctor Clinical Sign-off' },
        { id: 12, path: '/referral-command', label: 'Referral Command', icon: Send, num: '12', desc: 'ABDM & Transport Dispatch', badge: `${activeReferralCount}`, badgeColor: 'bg-purple-600' },
        { id: 13, path: '/longitudinal-record', label: 'Longitudinal Record', icon: History, num: '13', desc: '3-Year Progression Canvas' }
      ]
    },
    {
      title: 'HEALTH SYSTEMS & AUDIT',
      items: [
        { id: 14, path: '/district-simulink', label: 'District Simulink', icon: TrendingUp, num: '14', desc: 'PHC Map & Surge Sim' },
        { id: 15, path: '/model-registry', label: 'AI Model Registry', icon: Boxes, num: '15', desc: '15 Weights, ECE & Datasets' }
      ]
    }
  ];

  return (
    <aside
      className={`relative bg-white text-slate-700 flex flex-col h-screen border-r border-slate-200 flex-shrink-0 select-none z-30 transition-all duration-300 ease-in-out shadow-sm ${
        isCollapsed ? 'w-20' : 'w-72'
      }`}
    >
      {/* Slide / Collapse Toggle Button */}
      <button
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="absolute -right-3.5 top-6 z-40 w-7 h-7 rounded-full bg-white border border-slate-200 text-slate-500 hover:text-purple-700 hover:bg-purple-50 hover:border-purple-300 flex items-center justify-center shadow-md transition duration-200 cursor-pointer"
        title={isCollapsed ? 'Expand Slide Bar' : 'Collapse Slide Bar'}
      >
        {isCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>

      {/* Brand Header */}
      <div className="p-4 border-b border-slate-200/80 bg-white flex flex-col gap-3">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-700 via-purple-600 to-indigo-600 flex items-center justify-center shadow-md shadow-purple-500/20 ring-1 ring-purple-200 flex-shrink-0">
            <Eye className="w-5 h-5 text-white" />
          </div>

          {!isCollapsed && (
            <div className="min-w-0 transition-opacity duration-200">
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-base text-slate-900 tracking-tight">RetinaCare</span>
                <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 border border-purple-200">
                  v4.2 AI
                </span>
              </div>
              <p className="text-[10px] text-slate-500 font-medium tracking-wide truncate">
                See Earlier • Explain • Refer
              </p>
            </div>
          )}
        </div>

        {/* Quick Search trigger */}
        {!isCollapsed ? (
          <button
            onClick={() => setCommandPaletteOpen(true)}
            className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-slate-50 hover:bg-purple-50/50 border border-slate-200 hover:border-purple-300 text-xs text-slate-500 hover:text-slate-800 group transition shadow-2xs cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 text-purple-600 group-hover:scale-110 transition" />
              <span className="text-slate-600 font-medium group-hover:text-purple-900">Quick Command...</span>
            </span>
            <kbd className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white border border-slate-200 text-slate-500 shadow-2xs">
              ⌘K
            </kbd>
          </button>
        ) : (
          <button
            onClick={() => setCommandPaletteOpen(true)}
            className="w-10 h-10 mx-auto flex items-center justify-center rounded-xl bg-slate-50 border border-slate-200 hover:border-purple-300 hover:bg-purple-50 text-purple-600 transition shadow-2xs cursor-pointer"
            title="Search Commands (⌘K)"
          >
            <Search className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Navigation Menu List */}
      <div className="flex-1 overflow-y-auto px-2.5 py-3 space-y-5 text-xs custom-scroll">
        {navSections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-1">
            {!isCollapsed ? (
              <div className="px-2 py-1 text-[10px] font-mono font-bold uppercase tracking-widest text-slate-400">
                {section.title}
              </div>
            ) : (
              <div className="h-px bg-slate-200 my-2 mx-1" />
            )}

            {section.items.map((item) => {
              const isActive = location.pathname === item.path || activePage === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.path)}
                  title={isCollapsed ? `${item.num}: ${item.label} — ${item.desc}` : undefined}
                  className={`w-full flex items-center ${
                    isCollapsed ? 'justify-center p-2.5' : 'justify-between px-3 py-2'
                  } rounded-xl text-left transition-all duration-150 group cursor-pointer relative ${
                    isActive
                      ? 'bg-purple-50 text-purple-950 font-bold border border-purple-200 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80 border border-transparent'
                  }`}
                >
                  {/* Glowing left accent pill when active */}
                  {isActive && (
                    <span className="absolute left-0 top-1.5 bottom-1.5 w-1 rounded-r-full bg-purple-600 shadow-[0_0_6px_rgba(147,51,234,0.4)]" />
                  )}

                  <div className="flex items-center gap-2.5 min-w-0">
                    {!isCollapsed && (
                      <span
                        className={`text-[10px] font-mono font-bold w-4 text-center ${
                          isActive ? 'text-purple-700' : 'text-slate-400 group-hover:text-slate-600'
                        }`}
                      >
                        {item.num}
                      </span>
                    )}

                    <Icon
                      className={`w-4 h-4 flex-shrink-0 transition-transform duration-200 group-hover:scale-110 ${
                        isActive ? 'text-purple-700' : 'text-slate-400 group-hover:text-purple-600'
                      }`}
                    />

                    {!isCollapsed && (
                      <div className="truncate">
                        <div className={`truncate font-semibold ${isActive ? 'text-purple-950 font-bold' : 'text-slate-700 group-hover:text-slate-900'}`}>
                          {item.label}
                        </div>
                        <div
                          className={`text-[10px] truncate ${
                            isActive ? 'text-purple-700/80 font-medium' : 'text-slate-400 group-hover:text-slate-500'
                          }`}
                        >
                          {item.desc}
                        </div>
                      </div>
                    )}
                  </div>

                  {!isCollapsed && item.badge && (
                    <span
                      className={`ml-1 px-2 py-0.5 rounded-full text-[10px] font-bold shadow-2xs ${
                        item.badgeColor === 'bg-rose-500'
                          ? 'bg-rose-100 text-rose-700 border border-rose-200'
                          : 'bg-purple-100 text-purple-700 border border-purple-200'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}

                  {isCollapsed && item.badge && (
                    <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white animate-pulse" />
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Network & Operator Profile Footer */}
      <div className="p-3 border-t border-slate-200 bg-slate-50/80 space-y-2">
        {/* Offline / Online Switcher */}
        {!isCollapsed ? (
          <button
            onClick={toggleOffline}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-xl border text-[11px] font-medium transition cursor-pointer ${
              offlineMode
                ? 'bg-amber-50 border-amber-200 text-amber-800'
                : 'bg-white border-slate-200 hover:border-emerald-300 text-slate-700 shadow-2xs'
            }`}
          >
            <div className="flex items-center gap-2">
              {offlineMode ? (
                <WifiOff className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
              ) : (
                <Wifi className="w-3.5 h-3.5 text-emerald-600" />
              )}
              <span className="font-bold">{offlineMode ? 'Offline Mode' : 'Online Sync'}</span>
            </div>
            <span
              className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded border ${
                offlineMode
                  ? 'bg-amber-100 text-amber-800 border-amber-200'
                  : 'bg-emerald-50 text-emerald-700 border-emerald-200'
              }`}
            >
              {offlineMode ? 'Queue On' : 'Synced'}
            </span>
          </button>
        ) : (
          <button
            onClick={toggleOffline}
            className={`w-10 h-10 mx-auto flex items-center justify-center rounded-xl border transition cursor-pointer ${
              offlineMode
                ? 'bg-amber-50 border-amber-200 text-amber-600'
                : 'bg-white border-slate-200 text-emerald-600 shadow-2xs hover:bg-emerald-50/50'
            }`}
            title={offlineMode ? 'Offline Mode Active' : 'Online Sync Active'}
          >
            {offlineMode ? <WifiOff className="w-4 h-4 text-amber-600" /> : <Wifi className="w-4 h-4 text-emerald-600" />}
          </button>
        )}

        {/* User Card */}
        <div className="flex items-center gap-2.5 pt-1 px-1">
          <div className="relative w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-700 to-indigo-600 text-white font-bold text-xs flex items-center justify-center ring-2 ring-purple-100 flex-shrink-0 shadow-xs">
            {currentUser.initials}
            <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-500 ring-2 ring-white" />
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <div className="text-xs font-bold text-slate-800 truncate">{currentUser.name}</div>
              <div className="text-[10px] text-slate-500 font-mono truncate">{currentUser.facility}</div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}

