import React, { useState, useRef, useEffect } from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import {
  Search,
  Building2,
  Wifi,
  WifiOff,
  Bell,
  ShieldAlert,
  Printer,
  ChevronDown,
  LogOut,
  User,
  Check,
  Activity
} from 'lucide-react';

export default function GlobalTopBar() {
  const {
    currentUser,
    setCurrentUser,
    currentPatient,
    offlineMode,
    toggleOffline,
    setCommandPaletteOpen,
    navigateTo,
    setPrintModalOpen,
    reviewQueue,
    showToast
  } = useRetinaCare();

  const [facilityDropdownOpen, setFacilityDropdownOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const facilityRef = useRef(null);
  const userMenuRef = useRef(null);

  const urgentCount = reviewQueue.filter((c) => c.priority === 'Urgent').length;

  const facilityList = [
    { name: 'M.Y. Hospital Central Hub (Indore)', type: 'Tertiary Hub 01' },
    { name: 'Depalpur Community Health Centre', type: 'CHC Spokes' },
    { name: 'Dr. Ambedkar Nagar Civil Hospital', type: 'Sub-District Hub' },
    { name: 'Sanwer Primary Health Centre', type: 'Rural PHC Spokes' },
    { name: 'Rau Primary Health Centre', type: 'Urban Health Post' },
    { name: 'Betma Primary Health Centre', type: 'Tribal Sub-Centre' }
  ];

  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (facilityRef.current && !facilityRef.current.contains(event.target)) {
        setFacilityDropdownOpen(false);
      }
      if (userMenuRef.current && !userMenuRef.current.contains(event.target)) {
        setUserMenuOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleFacilityChange = (fac) => {
    setCurrentUser((prev) => ({ ...prev, facility: fac.name }));
    setFacilityDropdownOpen(false);
    if (showToast) {
      showToast('Facility Switched', `Connected node updated to ${fac.name}`, 'info');
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 lg:px-6 flex items-center justify-between z-20 shadow-xs flex-shrink-0">
      {/* Left: Facility selector dropdown & Active patient breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        {/* Interactive Facility Switcher */}
        <div className="relative" ref={facilityRef}>
          <button
            onClick={() => setFacilityDropdownOpen(!facilityDropdownOpen)}
            className="flex items-center gap-2 text-xs text-slate-700 bg-slate-50 hover:bg-slate-100 px-3 py-2 rounded-xl border border-slate-200 hover:border-purple-300 transition cursor-pointer shadow-2xs"
            title="Switch Healthcare Facility Node"
          >
            <Building2 className="w-3.5 h-3.5 text-purple-700 flex-shrink-0" />
            <span className="font-semibold text-slate-800 max-w-[150px] sm:max-w-[210px] truncate">
              {currentUser.facility}
            </span>
            <span className="text-[10px] bg-purple-100 text-purple-800 font-bold px-1.5 py-0.5 rounded-md">
              Hub 01
            </span>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${facilityDropdownOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* Facility Dropdown Menu */}
          {facilityDropdownOpen && (
            <div className="absolute left-0 top-full mt-1.5 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 py-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
              <div className="px-3 py-1.5 border-b border-slate-100 text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                Connected ABDM Nodes
              </div>
              <div className="max-h-60 overflow-y-auto py-1">
                {facilityList.map((fac) => {
                  const isSelected = currentUser.facility === fac.name;
                  return (
                    <button
                      key={fac.name}
                      onClick={() => handleFacilityChange(fac)}
                      className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between transition cursor-pointer ${
                        isSelected
                          ? 'bg-purple-50 text-purple-950 font-bold'
                          : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <div className="min-w-0 pr-2">
                        <div className="truncate">{fac.name}</div>
                        <div className="text-[10px] text-slate-400 font-medium">{fac.type}</div>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-purple-600 flex-shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Current Active Patient Chip with Direct Jump */}
        <button
          onClick={() => navigateTo('/longitudinal-record')}
          className="hidden xl:flex items-center gap-2 text-xs bg-purple-50/80 hover:bg-purple-100/90 border border-purple-200/80 px-3 py-2 rounded-xl transition cursor-pointer shadow-2xs group"
          title="Click to open patient longitudinal chart"
        >
          <span className="w-2 h-2 rounded-full bg-purple-600 animate-ping" />
          <span className="text-slate-500 font-medium">Active Case:</span>
          <span className="font-bold text-purple-950 group-hover:underline">{currentPatient.name}</span>
          <span className="text-[11px] font-mono text-purple-700 bg-purple-100 px-1.5 py-0.5 rounded font-semibold">
            {currentPatient.id}
          </span>
          <span className="text-[11px] text-amber-800 font-semibold bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200">
            {currentPatient.confirmedDiagnosis}
          </span>
        </button>
      </div>

      {/* Middle: Universal ABHA Quick Search Input */}
      <div className="flex-1 max-w-md mx-4 hidden md:block">
        <button
          onClick={() => setCommandPaletteOpen(true)}
          className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-slate-50 hover:bg-slate-100/90 border border-slate-200 hover:border-purple-300 text-slate-500 text-xs transition shadow-2xs group cursor-pointer"
        >
          <span className="flex items-center gap-2.5">
            <Search className="w-4 h-4 text-purple-600 group-hover:scale-110 transition-transform" />
            <span className="text-slate-600 font-medium group-hover:text-slate-900">
              Search ABHA, Patient ID, Phone or Model...
            </span>
          </span>
          <kbd className="px-1.5 py-0.5 rounded bg-white border border-slate-200 font-mono text-[10px] text-slate-500 shadow-2xs">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right: Actions, Notifications, Tele-Bandwidth, Offline status & Profile */}
      <div className="flex items-center gap-2 sm:gap-2.5">
        {/* Review Queue Alerts Bell */}
        <button
          onClick={() => navigateTo('/review-queue')}
          className="relative p-2 rounded-xl text-slate-600 hover:text-purple-700 hover:bg-purple-50 border border-slate-200 transition cursor-pointer shadow-2xs"
          title={`${urgentCount} Urgent Tele-Review Cases`}
        >
          <Bell className="w-4 h-4" />
          {urgentCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center ring-2 ring-white animate-pulse">
              {urgentCount}
            </span>
          )}
        </button>

        {/* Printable Pass Modal Trigger */}
        <button
          onClick={() => setPrintModalOpen(true)}
          className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white hover:bg-purple-50 text-slate-700 hover:text-purple-800 border border-slate-200 hover:border-purple-300 text-xs font-semibold shadow-2xs transition cursor-pointer"
          title="Print ABDM Fast-Track Referral Slip"
        >
          <Printer className="w-3.5 h-3.5 text-purple-700" />
          <span className="hidden lg:inline">ABDM Slip</span>
        </button>

        {/* Network & Latency Pill */}
        <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-50 border border-slate-200 text-[11px] font-mono text-slate-600 shadow-2xs">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>4.2 Mbps</span>
          <span className="text-slate-300">•</span>
          <span>42ms</span>
        </div>

        {/* Offline Mode Switch */}
        <button
          onClick={toggleOffline}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition cursor-pointer shadow-2xs ${
            offlineMode
              ? 'bg-amber-50 border-amber-200 text-amber-800 hover:bg-amber-100/70'
              : 'bg-emerald-50 border-emerald-200 text-emerald-800 hover:bg-emerald-100/70'
          }`}
          title="Toggle Offline Tele-Medicine Mode"
        >
          {offlineMode ? (
            <>
              <WifiOff className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
              <span>Offline Mode</span>
            </>
          ) : (
            <>
              <Wifi className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden sm:inline">Online Sync</span>
            </>
          )}
        </button>

        {/* Clinical Disclaimer Flag */}
        <div
          className="hidden 2xl:flex items-center gap-1.5 text-[11px] font-medium text-purple-900 bg-purple-50 border border-purple-200 px-3 py-2 rounded-xl"
          title="CDSCO Class B Clinical Decision Support Architecture"
        >
          <ShieldAlert className="w-3.5 h-3.5 text-purple-700" />
          <span>CDSS Level 2 • Doctor Validated</span>
        </div>

        {/* User Profile Avatar & Switch Role */}
        <div className="relative pl-1" ref={userMenuRef}>
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            className="flex items-center gap-2 p-1 rounded-xl hover:bg-slate-100 transition cursor-pointer"
            title="User Account & Roles"
          >
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-700 to-indigo-600 text-white font-bold text-xs flex items-center justify-center ring-2 ring-purple-100 shadow-xs">
              {currentUser.initials}
            </div>
            <ChevronDown className={`w-3.5 h-3.5 text-slate-400 hidden sm:block transition-transform ${userMenuOpen ? 'rotate-180' : ''}`} />
          </button>

          {/* User Account Menu Dropdown */}
          {userMenuOpen && (
            <div className="absolute right-0 top-full mt-1.5 w-60 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 z-50 animate-in fade-in slide-in-from-top-1 duration-150">
              <div className="px-3 py-2 border-b border-slate-100">
                <div className="font-bold text-xs text-slate-900 truncate">{currentUser.name}</div>
                <div className="text-[10px] text-purple-700 font-medium truncate">{currentUser.role}</div>
                <div className="text-[10px] text-slate-400 font-mono truncate mt-0.5">{currentUser.mciRegNo || 'REG-ACTIVE'}</div>
              </div>

              <div className="py-1">
                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    navigateTo('/login');
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg text-xs text-slate-700 hover:text-purple-700 hover:bg-purple-50 flex items-center gap-2 transition cursor-pointer"
                >
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span>Switch Role / Facility</span>
                </button>

                <button
                  onClick={() => {
                    setUserMenuOpen(false);
                    navigateTo('/login');
                  }}
                  className="w-full text-left px-3 py-2 rounded-lg text-xs text-rose-600 hover:bg-rose-50 flex items-center gap-2 transition cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out (ABDM Session)</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}


