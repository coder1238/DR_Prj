import React from 'react';
import { Check, AlertCircle, Focus, Eye, Ruler, SunMedium } from 'lucide-react';

export default function ReadinessRing({
  readiness = 92,
  isReady = true,
  distanceMm = 18,
  pupilMm = 4.2,
  illuminationPercent = 94,
  onTriggerCapture = null
}) {
  const checks = [
    { label: 'Optical Alignment', status: true, val: 'Fovea-OD Locked', icon: Focus },
    { label: 'Pupil Aperture', status: pupilMm >= 3.8, val: `${pupilMm} mm (≥3.8mm req)`, icon: Eye },
    { label: 'Working Distance', status: Math.abs(distanceMm - 18) <= 2, val: `${distanceMm} mm (18mm target)`, icon: Ruler },
    { label: 'Illumination Uniformity', status: illuminationPercent >= 85, val: `${illuminationPercent}% SNR 24.2dB`, icon: SunMedium }
  ];

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 shadow-xl space-y-4">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
            Real-time Auto-QC Sensor
          </span>
        </div>
        <span className="text-[10px] font-mono bg-purple-950 text-purple-300 px-2 py-0.5 rounded border border-purple-800">
          Latency: 18ms
        </span>
      </div>

      {/* Circular Gauge Center */}
      <div className="flex items-center justify-center py-2">
        <div className="relative w-36 h-36 flex items-center justify-center">
          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90">
            {/* Background Ring */}
            <circle cx="50" cy="50" r="42" fill="none" stroke="#1E293B" strokeWidth="8" />
            {/* Progress Arc */}
            <circle
              cx="50"
              cy="50"
              r="42"
              fill="none"
              stroke={readiness >= 90 ? '#10B981' : '#F59E0B'}
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray="264"
              strokeDashoffset={264 - (264 * readiness) / 100}
              className="transition-all duration-700 ease-out"
            />
          </svg>

          {/* Center text */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="text-2xl font-black text-white">{readiness}%</span>
            <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wide">
              {readiness >= 90 ? 'Capture Ready' : 'Aligning...'}
            </span>
          </div>
        </div>
      </div>

      {/* 4 Sensor Checklist */}
      <div className="space-y-2">
        {checks.map((chk, i) => {
          const Icon = chk.icon;
          return (
            <div
              key={i}
              className="flex items-center justify-between p-2 rounded-lg bg-slate-800/80 border border-slate-700/60 text-xs"
            >
              <div className="flex items-center gap-2">
                <Icon className="w-3.5 h-3.5 text-purple-400" />
                <span className="text-slate-300 font-medium text-[11px]">{chk.label}</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className={chk.status ? 'text-slate-300' : 'text-amber-400'}>{chk.val}</span>
                {chk.status ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-3.5 h-3.5 text-amber-400" />
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Trigger Button */}
      <button
        onClick={onTriggerCapture}
        disabled={readiness < 80}
        className={`w-full py-2.5 px-4 rounded-xl font-bold text-xs uppercase tracking-wider transition shadow-lg flex items-center justify-center gap-2 ${
          readiness >= 85
            ? 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-purple-900/40 cursor-pointer active:scale-95'
            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
        }`}
      >
        <Eye className="w-4 h-4" />
        Trigger High-Res Capture
      </button>
    </div>
  );
}

