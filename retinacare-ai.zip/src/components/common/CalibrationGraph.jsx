import React from 'react';

export default function CalibrationGraph() {
  // 10 confidence bins with mean confidence vs empirical accuracy
  const bins = [
    { bin: '0.0-0.1', conf: 0.05, acc: 0.04, count: 140 },
    { bin: '0.1-0.2', conf: 0.15, acc: 0.14, count: 280 },
    { bin: '0.2-0.3', conf: 0.25, acc: 0.26, count: 410 },
    { bin: '0.3-0.4', conf: 0.35, acc: 0.33, count: 520 },
    { bin: '0.4-0.5', conf: 0.45, acc: 0.46, count: 680 },
    { bin: '0.5-0.6', conf: 0.55, acc: 0.54, count: 890 },
    { bin: '0.6-0.7', conf: 0.65, acc: 0.66, count: 1240 },
    { bin: '0.7-0.8', conf: 0.75, acc: 0.73, count: 2100 },
    { bin: '0.8-0.9', conf: 0.85, acc: 0.86, count: 3400 },
    { bin: '0.9-1.0', conf: 0.95, acc: 0.94, count: 5800 }
  ];

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-5 border border-slate-800 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[10px] font-mono uppercase text-purple-400 font-bold">
            Post-Hoc Temperature Scaling (T=1.14)
          </div>
          <h4 className="text-sm font-bold text-white">Model Reliability Diagram (ECE)</h4>
        </div>
        <div className="text-right">
          <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
            ECE: 0.024 (Target &lt; 0.030)
          </span>
        </div>
      </div>

      {/* SVG Reliability Plot */}
      <div className="relative w-full h-44 bg-slate-950 rounded-xl p-3 border border-slate-800/80">
        <svg viewBox="0 0 300 140" className="w-full h-full overflow-visible">
          {/* Grid lines */}
          <line x1="30" y1="10" x2="290" y2="10" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 4" />
          <line x1="30" y1="40" x2="290" y2="40" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 4" />
          <line x1="30" y1="70" x2="290" y2="70" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 4" />
          <line x1="30" y1="100" x2="290" y2="100" stroke="#334155" strokeWidth="0.5" strokeDasharray="2 4" />
          <line x1="30" y1="130" x2="290" y2="130" stroke="#64748B" strokeWidth="1" />
          <line x1="30" y1="10" x2="30" y2="130" stroke="#64748B" strokeWidth="1" />

          {/* Perfect calibration line (diagonal) */}
          <line x1="30" y1="130" x2="290" y2="10" stroke="#94A3B8" strokeWidth="1.5" strokeDasharray="4 4" />

          {/* Reliability Empirical Points & Bars */}
          {bins.map((b, i) => {
            // x: 30 to 290
            const x = 30 + (i + 0.5) * ((290 - 30) / 10);
            // y: 130 (0.0) to 10 (1.0)
            const yAcc = 130 - b.acc * 120;
            const yConf = 130 - b.conf * 120;
            const barWidth = 18;

            return (
              <g key={i} className="group">
                {/* Confidence bar */}
                <rect
                  x={x - barWidth / 2}
                  y={yAcc}
                  width={barWidth}
                  height={130 - yAcc}
                  fill="#7C3AED"
                  opacity="0.45"
                  rx="2"
                  className="hover:opacity-80 transition"
                />
                {/* Accuracy dot */}
                <circle cx={x} cy={yAcc} r="3" fill="#A855F7" stroke="#FFFFFF" strokeWidth="1" />
              </g>
            );
          })}

          {/* Axes labels */}
          <text x="25" y="15" fill="#94A3B8" fontSize="8" textAnchor="end">1.0</text>
          <text x="25" y="72" fill="#94A3B8" fontSize="8" textAnchor="end">0.5</text>
          <text x="25" y="132" fill="#94A3B8" fontSize="8" textAnchor="end">0.0</text>
          <text x="30" y="139" fill="#94A3B8" fontSize="8" textAnchor="middle">0.0</text>
          <text x="160" y="139" fill="#94A3B8" fontSize="8" textAnchor="middle">Mean Predicted Confidence</text>
          <text x="290" y="139" fill="#94A3B8" fontSize="8" textAnchor="middle">1.0</text>
        </svg>
      </div>

      <div className="grid grid-cols-3 gap-2 text-center text-[11px] pt-1">
        <div className="p-2 rounded bg-slate-800/80 border border-slate-700/60">
          <div className="text-slate-400 text-[10px]">Expected Calib. Error</div>
          <div className="font-bold text-purple-300 font-mono">0.024</div>
        </div>
        <div className="p-2 rounded bg-slate-800/80 border border-slate-700/60">
          <div className="text-slate-400 text-[10px]">Brier Multi-Class Score</div>
          <div className="font-bold text-emerald-300 font-mono">0.081</div>
        </div>
        <div className="p-2 rounded bg-slate-800/80 border border-slate-700/60">
          <div className="text-slate-400 text-[10px]">NLL (Log-Loss)</div>
          <div className="font-bold text-cyan-300 font-mono">0.142</div>
        </div>
      </div>
    </div>
  );
}

