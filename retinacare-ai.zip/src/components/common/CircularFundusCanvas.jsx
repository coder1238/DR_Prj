import React, { useState } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  Crosshair,
  Layers,
  Sparkles,
  Info,
  Ruler
} from 'lucide-react';

export default function CircularFundusCanvas({
  activeLayers = {
    microaneurysms: true,
    hemorrhages: true,
    hardExudates: true,
    cottonWoolSpots: true,
    vessels: true,
    opticDisc: true,
    fovea: true,
    gradCam: false,
    calipers: false
  },
  gradCamOpacity = 65,
  interactive = true,
  size = 540,
  selectedLesion = null,
  onSelectLesion = null
}) {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [hoveredItem, setHoveredItem] = useState(null);
  const [measurementMode, setMeasurementMode] = useState(false);

  // Lesion coordinate definitions for Suresh Chandra Verma's right eye (OD)
  // Center is (270, 270)
  // Optic Disc is at (180, 270), radius 42
  // Fovea is at (360, 270), radius 16
  const microaneurysms = [
    { id: 'MA-01', x: 330, y: 250, r: 3.5, quad: 'ST', conf: '96.2%', type: 'Microaneurysm' },
    { id: 'MA-02', x: 345, y: 285, r: 3.0, quad: 'IT', conf: '94.8%', type: 'Microaneurysm' },
    { id: 'MA-03', x: 380, y: 240, r: 4.0, quad: 'ST', conf: '95.1%', type: 'Microaneurysm' },
    { id: 'MA-04', x: 395, y: 295, r: 3.2, quad: 'IT', conf: '92.4%', type: 'Microaneurysm' },
    { id: 'MA-05', x: 315, y: 310, r: 4.2, quad: 'IT', conf: '97.0%', type: 'Microaneurysm' },
    { id: 'MA-06', x: 410, y: 260, r: 3.8, quad: 'Temporal', conf: '93.7%', type: 'Microaneurysm' },
    { id: 'MA-07', x: 300, y: 220, r: 3.1, quad: 'ST', conf: '91.8%', type: 'Microaneurysm' },
    { id: 'MA-08', x: 260, y: 190, r: 4.0, quad: 'SN', conf: '94.2%', type: 'Microaneurysm' },
    { id: 'MA-09', x: 370, y: 320, r: 3.6, quad: 'IT', conf: '95.8%', type: 'Microaneurysm' },
    { id: 'MA-10', x: 280, y: 340, r: 3.4, quad: 'IN', conf: '90.5%', type: 'Microaneurysm' }
  ];

  const hemorrhages = [
    { id: 'HEM-01', x: 340, y: 230, rx: 9, ry: 6, rot: 25, quad: 'ST', conf: '95.4%', type: 'Blot Hemorrhage' },
    { id: 'HEM-02', x: 390, y: 315, rx: 11, ry: 7, rot: -40, quad: 'IT', conf: '96.8%', type: 'Blot Hemorrhage' },
    { id: 'HEM-03', x: 325, y: 325, rx: 8, ry: 5, rot: 15, quad: 'IT', conf: '93.2%', type: 'Flame-shaped Hemorrhage' },
    { id: 'HEM-04', x: 420, y: 245, rx: 7, ry: 5, rot: 10, quad: 'Temporal', conf: '91.5%', type: 'Blot Hemorrhage' }
  ];

  const hardExudates = [
    // Circinate ring around macula
    { id: 'HEX-01', x: 335, y: 260, r: 5.5, quad: 'Perimacular', conf: '98.1%', type: 'Hard Exudate (Circinate Ring)' },
    { id: 'HEX-02', x: 345, y: 248, r: 6.2, quad: 'Perimacular', conf: '97.4%', type: 'Hard Exudate' },
    { id: 'HEX-03', x: 360, y: 245, r: 5.8, quad: 'Perimacular', conf: '96.9%', type: 'Hard Exudate (Threatening FAZ)' },
    { id: 'HEX-04', x: 375, y: 252, r: 5.0, quad: 'Perimacular', conf: '95.2%', type: 'Hard Exudate' },
    { id: 'HEX-05', x: 382, y: 270, r: 6.5, quad: 'Temporal Macula', conf: '98.6%', type: 'Hard Exudate Ring' },
    { id: 'HEX-06', x: 370, y: 290, r: 5.2, quad: 'Infra-macular', conf: '94.3%', type: 'Hard Exudate' },
    { id: 'HEX-07', x: 350, y: 292, r: 5.7, quad: 'Infra-macular', conf: '96.0%', type: 'Hard Exudate' }
  ];

  const cottonWoolSpots = [
    { id: 'CWS-01', x: 305, y: 195, r: 12, quad: 'SN Arcade', conf: '93.5%', type: 'Cotton Wool Spot (Nerve Fiber Infarct)' },
    { id: 'CWS-02', x: 405, y: 215, r: 10, quad: 'ST Periphery', conf: '91.2%', type: 'Cotton Wool Spot' },
    { id: 'CWS-03', x: 310, y: 350, r: 11, quad: 'IN Arcade', conf: '92.9%', type: 'Cotton Wool Spot' }
  ];

  return (
    <div className="relative flex flex-col items-center justify-center select-none">
      {/* Viewport Frame */}
      <div
        className="relative rounded-full overflow-hidden bg-slate-950 shadow-2xl ring-4 ring-slate-800/80 transition-transform duration-300"
        style={{ width: `${size}px`, height: `${size}px` }}
      >
        <svg
          viewBox="0 0 540 540"
          className="w-full h-full cursor-crosshair"
          style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center' }}
        >
          <defs>
            {/* Fundus Backing Gradient */}
            <radialGradient id="fundusGlow" cx="48%" cy="50%" r="52%">
              <stop offset="0%" stopColor="#4A1507" />
              <stop offset="45%" stopColor="#320C04" />
              <stop offset="78%" stopColor="#1E0702" />
              <stop offset="98%" stopColor="#0B0301" />
              <stop offset="100%" stopColor="#000000" />
            </radialGradient>

            {/* Optic Disc Gradient */}
            <radialGradient id="opticDiscGrad" cx="45%" cy="45%" r="55%">
              <stop offset="0%" stopColor="#FFF1B8" />
              <stop offset="40%" stopColor="#F59E0B" />
              <stop offset="85%" stopColor="#D97706" />
              <stop offset="100%" stopColor="#92400E" />
            </radialGradient>

            {/* Macular Fovea Gradient */}
            <radialGradient id="foveaGrad" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#180402" stopOpacity="0.95" />
              <stop offset="70%" stopColor="#2A0804" stopOpacity="0.75" />
              <stop offset="100%" stopColor="#3D0E06" stopOpacity="0" />
            </radialGradient>

            {/* Grad-CAM Heatmap Gradient */}
            <radialGradient id="gradCamHotspot" cx="64%" cy="50%" r="35%">
              <stop offset="0%" stopColor="#EF4444" stopOpacity="0.95" />
              <stop offset="35%" stopColor="#F59E0B" stopOpacity="0.80" />
              <stop offset="70%" stopColor="#10B981" stopOpacity="0.45" />
              <stop offset="92%" stopColor="#3B82F6" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#6366F1" stopOpacity="0" />
            </radialGradient>

            {/* Cotton Wool Glow */}
            <filter id="cwsBlur" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="4" />
            </filter>
          </defs>

          {/* Background Fundus Globe */}
          <circle cx="270" cy="270" r="268" fill="url(#fundusGlow)" />

          {/* Choroidal Texture Ring / Retinal Pigment Epithelium */}
          <circle
            cx="270"
            cy="270"
            r="262"
            fill="none"
            stroke="#9A3412"
            strokeWidth="0.8"
            strokeDasharray="4 8"
            opacity="0.25"
          />

          {/* Quadrant Axis Lines */}
          <line x1="270" y1="10" x2="270" y2="530" stroke="#7C3AED" strokeWidth="0.5" strokeDasharray="3 6" opacity="0.2" />
          <line x1="10" y1="270" x2="530" y2="270" stroke="#7C3AED" strokeWidth="0.5" strokeDasharray="3 6" opacity="0.2" />

          {/* 1. Optic Disc Layer */}
          {activeLayers.opticDisc && (
            <g id="optic-disc-layer">
              {/* Disc Margin */}
              <circle
                cx="180"
                cy="270"
                r="44"
                fill="url(#opticDiscGrad)"
                className="transition-all hover:stroke-purple-400 hover:stroke-2 cursor-pointer"
                onMouseEnter={() =>
                  setHoveredItem({
                    type: 'Optic Disc (OD)',
                    desc: 'Margin crisp, Cup-to-Disc ratio 0.38, Neuroretinal rim intact',
                    conf: '99.4%'
                  })
                }
                onMouseLeave={() => setHoveredItem(null)}
              />
              {/* Physiological Cup */}
              <ellipse cx="178" cy="268" rx="17" ry="19" fill="#FFFBEB" opacity="0.75" />
              <circle cx="180" cy="270" r="44" fill="none" stroke="#FDE68A" strokeWidth="1.2" opacity="0.7" />
              <text x="180" y="325" fill="#FDE68A" fontSize="10" fontWeight="bold" textAnchor="middle" opacity="0.8">
                Optic Disc
              </text>
            </g>
          )}

          {/* 2. Vessel Tree Layer (Arterioles and Venules with Branches) */}
          {activeLayers.vessels && (
            <g id="vessels-layer" opacity="0.9">
              {/* Superior Temporal Vein (darker, wider) */}
              <path
                d="M 180 260 C 190 200, 240 140, 340 120 C 400 110, 460 130, 490 170"
                fill="none"
                stroke="#881337"
                strokeWidth="4.2"
                strokeLinecap="round"
              />
              {/* Superior Temporal Artery (brighter red, narrower) */}
              <path
                d="M 185 255 C 200 190, 255 130, 360 110 C 420 100, 475 120, 500 150"
                fill="none"
                stroke="#E11D48"
                strokeWidth="2.8"
                strokeLinecap="round"
              />
              {/* Branch into Macular arcade */}
              <path
                d="M 280 150 C 310 175, 330 205, 345 225"
                fill="none"
                stroke="#E11D48"
                strokeWidth="1.6"
              />
              <path
                d="M 330 130 C 360 155, 380 185, 395 210"
                fill="none"
                stroke="#881337"
                strokeWidth="2.2"
              />

              {/* Inferior Temporal Vein */}
              <path
                d="M 180 280 C 195 340, 245 400, 350 420 C 410 430, 465 410, 495 370"
                fill="none"
                stroke="#881337"
                strokeWidth="4.2"
                strokeLinecap="round"
              />
              {/* Inferior Temporal Artery */}
              <path
                d="M 185 285 C 205 350, 260 410, 370 430 C 430 440, 480 420, 505 390"
                fill="none"
                stroke="#E11D48"
                strokeWidth="2.8"
                strokeLinecap="round"
              />
              {/* Inferior Macular branches */}
              <path
                d="M 290 390 C 320 365, 340 335, 350 315"
                fill="none"
                stroke="#E11D48"
                strokeWidth="1.6"
              />
              <path
                d="M 345 410 C 375 385, 390 355, 400 330"
                fill="none"
                stroke="#881337"
                strokeWidth="2.2"
              />

              {/* Nasal Vessels */}
              <path
                d="M 175 260 C 150 210, 110 170, 50 150"
                fill="none"
                stroke="#BE123C"
                strokeWidth="2.5"
              />
              <path
                d="M 175 280 C 150 330, 110 370, 50 390"
                fill="none"
                stroke="#BE123C"
                strokeWidth="2.5"
              />
            </g>
          )}

          {/* 3. Fovea & FAZ Layer */}
          {activeLayers.fovea && (
            <g id="fovea-layer">
              {/* Macula Lutea Hue */}
              <circle cx="360" cy="270" r="42" fill="url(#foveaGrad)" />
              {/* Foveal Avascular Zone (FAZ) */}
              <circle
                cx="360"
                cy="270"
                r="16"
                fill="#000000"
                opacity="0.8"
                stroke="#A855F7"
                strokeWidth="1.2"
                strokeDasharray="2 2"
                className="cursor-pointer hover:stroke-purple-300"
                onMouseEnter={() =>
                  setHoveredItem({
                    type: 'Foveal Avascular Zone (FAZ)',
                    desc: 'Diameter 520µm (Threshold 500µm). Perifoveal capillary drop-out noted.',
                    conf: '97.8%'
                  })
                }
                onMouseLeave={() => setHoveredItem(null)}
              />
              {/* Foveola Center Crosshair */}
              <circle cx="360" cy="270" r="2" fill="#E9D5FF" />
              <text x="360" y="305" fill="#D8B4FE" fontSize="9" fontWeight="bold" textAnchor="middle" opacity="0.9">
                Fovea (FAZ)
              </text>
            </g>
          )}

          {/* 4. Grad-CAM Overlay (Visual Heatmap) */}
          {activeLayers.gradCam && (
            <circle
              cx="365"
              cy="270"
              r="170"
              fill="url(#gradCamHotspot)"
              opacity={gradCamOpacity / 100}
              style={{ mixBlendMode: 'screen', pointerEvents: 'none' }}
            />
          )}

          {/* 5. Cotton Wool Spots */}
          {activeLayers.cottonWoolSpots && (
            <g id="cws-layer">
              {cottonWoolSpots.map((cws) => (
                <circle
                  key={cws.id}
                  cx={cws.x}
                  cy={cws.y}
                  r={cws.r}
                  fill="#E2E8F0"
                  opacity="0.68"
                  filter="url(#cwsBlur)"
                  className="cursor-pointer hover:opacity-100 transition"
                  onMouseEnter={() => setHoveredItem(cws)}
                  onMouseLeave={() => setHoveredItem(null)}
                />
              ))}
            </g>
          )}

          {/* 6. Hemorrhages (Flame + Blot) */}
          {activeLayers.hemorrhages && (
            <g id="hemorrhages-layer">
              {hemorrhages.map((hem) => (
                <g key={hem.id} transform={`rotate(${hem.rot} ${hem.x} ${hem.y})`}>
                  <ellipse
                    cx={hem.x}
                    cy={hem.y}
                    rx={hem.rx}
                    ry={hem.ry}
                    fill="#991B1B"
                    stroke="#EF4444"
                    strokeWidth="0.8"
                    className="cursor-pointer hover:stroke-white transition"
                    onMouseEnter={() => setHoveredItem(hem)}
                    onMouseLeave={() => setHoveredItem(null)}
                  />
                </g>
              ))}
            </g>
          )}

          {/* 7. Hard Exudates (Waxy yellow lipoid deposits) */}
          {activeLayers.hardExudates && (
            <g id="hard-exudates-layer">
              {hardExudates.map((hex) => (
                <circle
                  key={hex.id}
                  cx={hex.x}
                  cy={hex.y}
                  r={hex.r}
                  fill="#FACC15"
                  stroke="#CA8A04"
                  strokeWidth="1"
                  className="cursor-pointer hover:stroke-white transition shadow-sm animate-pulse"
                  style={{ animationDuration: '2.5s' }}
                  onMouseEnter={() => setHoveredItem(hex)}
                  onMouseLeave={() => setHoveredItem(null)}
                />
              ))}
            </g>
          )}

          {/* 8. Microaneurysms (Sharp tiny red dots) */}
          {activeLayers.microaneurysms && (
            <g id="microaneurysms-layer">
              {microaneurysms.map((ma) => (
                <circle
                  key={ma.id}
                  cx={ma.x}
                  cy={ma.y}
                  r={ma.r}
                  fill="#EF4444"
                  stroke="#FCA5A5"
                  strokeWidth="0.6"
                  className="cursor-pointer hover:stroke-white transition"
                  onMouseEnter={() => setHoveredItem(ma)}
                  onMouseLeave={() => setHoveredItem(null)}
                />
              ))}
            </g>
          )}

          {/* 9. Measurement Calipers (Distance from Macula to Exudate Ring) */}
          {(activeLayers.calipers || measurementMode) && (
            <g id="calipers-layer">
              <line
                x1="360"
                y1="270"
                x2="382"
                y2="270"
                stroke="#06B6D4"
                strokeWidth="1.5"
                strokeDasharray="2 2"
              />
              <circle cx="360" cy="270" r="3" fill="#06B6D4" />
              <circle cx="382" cy="270" r="3" fill="#06B6D4" />
              <rect x="362" y="254" width="46" height="14" rx="3" fill="#083344" opacity="0.9" />
              <text x="385" y="264" fill="#67E8F9" fontSize="8" fontWeight="bold" textAnchor="middle">
                380 µm
              </text>
            </g>
          )}

          {/* Optical Targeting Crosshair ring */}
          <circle
            cx="270"
            cy="270"
            r="160"
            fill="none"
            stroke="#7C3AED"
            strokeWidth="0.6"
            strokeDasharray="4 12"
            opacity="0.3"
          />
        </svg>

        {/* Hover Clinical Lesion Tooltip */}
        {hoveredItem && (
          <div className="absolute top-4 left-4 bg-slate-900/90 backdrop-blur-md text-white p-2.5 rounded-xl border border-purple-500/50 shadow-xl text-xs max-w-xs pointer-events-none animate-in fade-in duration-100">
            <div className="flex items-center justify-between gap-2 font-bold text-purple-300">
              <span>{hoveredItem.type}</span>
              <span className="text-[10px] font-mono bg-purple-950 text-purple-200 px-1.5 py-0.5 rounded border border-purple-800">
                {hoveredItem.conf}
              </span>
            </div>
            {hoveredItem.quad && (
              <div className="text-[11px] text-slate-300 mt-0.5">
                Location: <span className="text-white font-medium">{hoveredItem.quad}</span>
              </div>
            )}
            {hoveredItem.desc && (
              <div className="text-[11px] text-slate-400 mt-1 leading-snug">{hoveredItem.desc}</div>
            )}
          </div>
        )}

        {/* Bottom Metadata Overlay */}
        <div className="absolute bottom-3 inset-x-0 flex justify-between px-5 text-[10px] font-mono text-slate-400 pointer-events-none">
          <span className="bg-slate-900/80 px-2 py-0.5 rounded backdrop-blur-xs">
            EYE: OD (Right) • 45° Macula Centered
          </span>
          <span className="bg-slate-900/80 px-2 py-0.5 rounded backdrop-blur-xs">
            1 DD ≈ 1500 µm
          </span>
        </div>
      </div>

      {/* Floating Canvas Controls Toolbar */}
      {interactive && (
        <div className="mt-3 flex items-center gap-2 bg-white px-3 py-1.5 rounded-full border border-slate-200 shadow-sm text-xs">
          <button
            onClick={() => setZoomLevel((z) => Math.min(z + 0.25, 2.25))}
            className="p-1 rounded-full hover:bg-slate-100 text-slate-700 transition"
            title="Zoom In"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <span className="text-[11px] font-mono font-semibold text-slate-600 min-w-[40px] text-center">
            {Math.round(zoomLevel * 100)}%
          </span>
          <button
            onClick={() => setZoomLevel((z) => Math.max(z - 0.25, 0.75))}
            className="p-1 rounded-full hover:bg-slate-100 text-slate-700 transition"
            title="Zoom Out"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <div className="w-px h-4 bg-slate-200" />
          <button
            onClick={() => setZoomLevel(1)}
            className="px-2 py-0.5 rounded hover:bg-slate-100 text-slate-600 text-[11px] font-medium"
            title="Reset Zoom"
          >
            Reset
          </button>
          <div className="w-px h-4 bg-slate-200" />
          <button
            onClick={() => setMeasurementMode((m) => !m)}
            className={`flex items-center gap-1 px-2 py-0.5 rounded transition ${
              measurementMode
                ? 'bg-cyan-100 text-cyan-800 font-bold'
                : 'hover:bg-slate-100 text-slate-600'
            }`}
            title="Toggle Calipers"
          >
            <Ruler className="w-3.5 h-3.5" />
            <span className="text-[11px]">Calipers</span>
          </button>
        </div>
      )}
    </div>
  );
}

