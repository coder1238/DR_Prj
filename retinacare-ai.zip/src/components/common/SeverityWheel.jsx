import React from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2 } from 'lucide-react';

export default function SeverityWheel({
  currentGrade = 2,
  confidence = 0.941,
  referable = true,
  distribution = [
    { grade: 0, label: 'No DR', prob: 0.012, color: '#10B981' },
    { grade: 1, label: 'Mild NPDR', prob: 0.047, color: '#F59E0B' },
    { grade: 2, label: 'Moderate NPDR', prob: 0.887, color: '#EA580C' },
    { grade: 3, label: 'Severe NPDR', prob: 0.041, color: '#DC2626' },
    { grade: 4, label: 'Proliferative DR', prob: 0.013, color: '#991B1B' }
  ],
  onSelectGrade = null,
  interactive = false
}) {
  const stages = [
    { grade: 0, title: 'Grade 0: No DR', desc: 'No microaneurysms or lesions present', color: '#10B981', ringColor: 'ring-emerald-500' },
    { grade: 1, title: 'Grade 1: Mild NPDR', desc: 'Microaneurysms only', color: '#EAB308', ringColor: 'ring-yellow-500' },
    { grade: 2, title: 'Grade 2: Moderate NPDR', desc: 'More than microaneurysms, less than severe NPDR', color: '#F97316', ringColor: 'ring-orange-500' },
    { grade: 3, title: 'Grade 3: Severe NPDR', desc: '4-2-1 International Clinical DR Rule met', color: '#EF4444', ringColor: 'ring-red-500' },
    { grade: 4, title: 'Grade 4: Proliferative DR', desc: 'Neovascularization / Preretinal hemorrhage', color: '#991B1B', ringColor: 'ring-rose-800' }
  ];

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-5">
      {/* Header Banner */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-wider text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
            ICDR Standard Classification
          </span>
          <h3 className="text-base font-bold text-slate-900 mt-1">DR Severity Studio</h3>
        </div>
        <div className={`px-2.5 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
          referable ? 'bg-rose-100 text-rose-800 border border-rose-300' : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
        }`}>
          {referable ? <AlertTriangle className="w-3.5 h-3.5 text-rose-600" /> : <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
          <span>{referable ? 'Referable DR (Priority)' : 'Non-Referable DR'}</span>
        </div>
      </div>

      {/* Radial Wheel / Segment Visualizer */}
      <div className="flex flex-col items-center py-2">
        <div className="relative w-48 h-48 flex items-center justify-center">
          {/* Circular Track */}
          <svg viewBox="0 0 100 100" className="w-full h-full -rotate-90 transform">
            {/* 5 Distinct Arcs */}
            <circle cx="50" cy="50" r="40" fill="none" stroke="#E2E8F0" strokeWidth="12" />
            
            {/* Arc 0 (0-20%): Emerald */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke="#10B981"
              strokeWidth="12"
              strokeDasharray="48 251"
              strokeDashoffset="0"
              className="opacity-40"
            />
            {/* Arc 1 (20-40%): Yellow */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke="#EAB308"
              strokeWidth="12"
              strokeDasharray="48 251"
              strokeDashoffset="-50"
              className="opacity-40"
            />
            {/* Arc 2 (40-60%): Orange (Active) */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke="#F97316"
              strokeWidth="15"
              strokeDasharray="48 251"
              strokeDashoffset="-100"
              className="drop-shadow-md"
            />
            {/* Arc 3 (60-80%): Red */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke="#EF4444"
              strokeWidth="12"
              strokeDasharray="48 251"
              strokeDashoffset="-150"
              className="opacity-40"
            />
            {/* Arc 4 (80-100%): Crimson */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke="#991B1B"
              strokeWidth="12"
              strokeDasharray="48 251"
              strokeDashoffset="-200"
              className="opacity-40"
            />
          </svg>

          {/* Center Hub Indicator */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase">Primary Grade</span>
            <span className="text-3xl font-black text-slate-900 leading-none mt-0.5">
              {currentGrade}
            </span>
            <span className="text-xs font-bold text-orange-600 mt-0.5">
              Moderate NPDR
            </span>
            <span className="text-[10px] font-mono text-slate-500 mt-1">
              Conf: {(confidence * 100).toFixed(1)}%
            </span>
          </div>
        </div>
      </div>

      {/* 5 Stage Selectable Stepper / Cards */}
      <div className="space-y-1.5">
        <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
          Ensemble Softmax Probability Distribution
        </div>
        {distribution.map((item) => {
          const isSelected = item.grade === currentGrade;
          return (
            <div
              key={item.grade}
              onClick={() => interactive && onSelectGrade && onSelectGrade(item.grade)}
              className={`p-2 rounded-xl border transition flex items-center justify-between text-xs ${
                isSelected
                  ? 'bg-orange-50/80 border-orange-300 shadow-xs'
                  : 'bg-slate-50/60 border-slate-200/80 hover:bg-slate-100/70'
              } ${interactive ? 'cursor-pointer' : ''}`}
            >
              <div className="flex items-center gap-2.5">
                <span
                  className="w-3 h-3 rounded-full flex-shrink-0"
                  style={{ backgroundColor: item.color }}
                />
                <div>
                  <span className="font-semibold text-slate-800">
                    Grade {item.grade}: {item.label}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {/* Horizontal mini bar */}
                <div className="w-20 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${item.prob * 100}%`,
                      backgroundColor: item.color
                    }}
                  />
                </div>
                <span className="font-mono text-[11px] font-bold text-slate-700 min-w-[42px] text-right">
                  {(item.prob * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Clinical Guidance Footnote */}
      <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 leading-relaxed">
        <span className="font-bold text-slate-800">Clinical Protocol: </span>
        Patients with Grade 2 Moderate NPDR + Macular Edema risk &gt; 0.70 qualify for prompt comprehensive tele-retina review within 72 hours under National Health Mission guidelines.
      </div>
    </div>
  );
}

