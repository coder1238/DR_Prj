import React from 'react';
import { useRetinaCare } from '../../context/RetinaCareContext';
import { Printer, X, ShieldCheck, QrCode, Phone, MapPin, AlertTriangle } from 'lucide-react';

export default function PrintableReferralModal() {
  const {
    printModalOpen,
    setPrintModalOpen,
    selectedReferral,
    currentPatient,
    currentUser
  } = useRetinaCare();

  if (!printModalOpen) return null;

  const referral = selectedReferral || {
    patientToken: 'ABDM-MHOW-REF-9941',
    createdDate: '19 Sep 2026, 09:40 AM',
    scheduledDate: '20 Sep 2026, 10:30 AM',
    destinationHub: 'M.Y. Hospital, Indore (Retina Specialty OPD 4)',
    drStage: 'Moderate NPDR with Clinically Significant DME',
    icdrGrade: 2,
    clinicalIndication: 'Perifoveal circinate hard exudates encroaching Foveal Avascular Zone. Rapid anti-VEGF / focal laser evaluation required to prevent irreversible visual loss.'
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-300 shadow-2xl overflow-hidden print:border-none print:shadow-none print:w-full">
        {/* Action Header - hidden in print */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-purple-400" />
            <span className="font-bold text-sm">Official ABDM Tele-Ophthalmology Referral Slip</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 font-semibold text-xs text-white transition flex items-center gap-1.5 shadow-sm"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={() => setPrintModalOpen(false)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Document Body */}
        <div className="p-8 space-y-6 text-slate-800 text-xs">
          {/* Government / Health Mission Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex items-center justify-between">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500">
                GOVERNMENT OF MADHYA PRADESH • DEPARTMENT OF PUBLIC HEALTH
              </div>
              <h1 className="text-xl font-black text-slate-900 tracking-tight mt-0.5">
                राष्ट्रीय स्वास्थ्य मिशन (NHM) • आयुष्मान भारत डिजिटल मिशन
              </h1>
              <p className="text-xs text-purple-900 font-bold">
                RetinaCare AI District Tele-Ophthalmology Network • Priority Referral Pass
              </p>
            </div>
            <div className="text-right">
              <div className="inline-block p-2 border border-slate-300 rounded bg-slate-50 text-center">
                <QrCode className="w-12 h-12 text-slate-900 mx-auto" />
                <span className="text-[9px] font-mono font-bold block mt-1">
                  {referral.patientToken}
                </span>
              </div>
            </div>
          </div>

          {/* Bilingual Patient Demographics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-purple-50/60 p-4 rounded-xl border border-purple-200/80">
            <div>
              <div className="text-[10px] text-slate-500 uppercase font-semibold">मरीज़ का नाम / Patient</div>
              <div className="font-bold text-sm text-slate-900">{referral.patientName || currentPatient.name}</div>
              <div className="text-[11px] text-slate-600">{referral.age || currentPatient.age} Yrs / {referral.gender || currentPatient.gender}</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase font-semibold">ABHA पता / ABHA ID</div>
              <div className="font-mono font-bold text-purple-900">{referral.abhaId || currentPatient.abhaId}</div>
              <div className="text-[11px] text-slate-600">Ph: {referral.phone || currentPatient.phone}</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase font-semibold">मूल स्वास्थ्य केंद्र / Origin PHC</div>
              <div className="font-bold text-slate-900">{referral.originPhc || currentPatient.registrationPhc}</div>
              <div className="text-[11px] text-slate-600">Source: Rural Screening Node</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-500 uppercase font-semibold">प्राथमिकता / Urgency</div>
              <div className="font-black text-rose-700 uppercase tracking-wide">
                {referral.referralUrgency || '72h High-Risk Fast Track'}
              </div>
              <div className="text-[11px] text-slate-600">Priority OPD Counter 04</div>
            </div>
          </div>

          {/* Clinical Findings & AI Analysis Summary */}
          <div className="space-y-3">
            <h3 className="font-bold text-sm border-b border-slate-200 pb-1 text-slate-900 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              नैदानिक निष्कर्ष / Clinical Triage & Indication
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase">Confirmed ICDR Grade</div>
                <div className="font-bold text-purple-950 text-sm">{referral.drStage}</div>
                <div className="text-[11px] text-slate-600">
                  ICDR Grade {referral.icdrGrade ?? 2} • DME Risk: 88.7% (Clinically Significant)
                </div>
              </div>
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                <div className="text-[10px] font-bold text-slate-500 uppercase">Destination Specialty Hub</div>
                <div className="font-bold text-slate-900">{referral.destinationHub}</div>
                <div className="text-[11px] text-slate-600">
                  Appt: <span className="font-bold text-slate-900">{referral.scheduledDate}</span>
                </div>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700 leading-relaxed">
              <span className="font-bold text-slate-900">Clinical Recommendation: </span>
              {referral.clinicalIndication}
            </div>
          </div>

          {/* Transport & Community Health Escort */}
          <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <div className="font-bold text-emerald-950 text-xs flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-emerald-700" />
                सरकारी यात्रा सहायता / Government Transit Token
              </div>
              <span className="text-[10px] font-mono font-bold bg-emerald-200/80 text-emerald-900 px-2 py-0.5 rounded">
                {referral.transportVoucher || 'Govt 108 Transit Authorized'}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-emerald-900">
              <div>
                <span className="text-emerald-700">Designated ASHA Facilitator:</span>{' '}
                <span className="font-bold">{referral.notifications?.ashaName || currentPatient.ashaWorker}</span>
              </div>
              <div>
                <span className="text-emerald-700">Distance to Hub:</span>{' '}
                <span className="font-bold">{referral.distanceKm || 46.2} Km</span>
              </div>
            </div>
            <div className="text-[10px] text-emerald-800 italic">
              मरीज़ को जिला अस्पताल तक निःशुल्क परिवहन एवं विशेष ओपीडी में कतार-रहित प्रवेश की सुविधा मान्य है।
            </div>
          </div>

          {/* Clinician Signature & Timestamp */}
          <div className="pt-4 border-t border-slate-200 flex items-end justify-between">
            <div className="space-y-0.5">
              <div className="text-[10px] text-slate-500">Authorized Tele-Ophthalmologist:</div>
              <div className="font-bold text-slate-900">{currentUser.name}</div>
              <div className="text-[10px] text-slate-500 font-mono">Reg: {currentUser.mciRegNo}</div>
              <div className="text-[10px] text-slate-500">Date: {referral.createdDate}</div>
            </div>

            <div className="text-right space-y-1">
              <div className="w-32 border-b border-slate-400 pb-1 font-signature text-sm font-serif italic text-purple-900">
                A. Sharma
              </div>
              <div className="text-[10px] font-semibold text-slate-600">Digital Signature Validated</div>
              <div className="text-[9px] text-slate-400 font-mono">SHA-256: 7f8a9...b14c</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

